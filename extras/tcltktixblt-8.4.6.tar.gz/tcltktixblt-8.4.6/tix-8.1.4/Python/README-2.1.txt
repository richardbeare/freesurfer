# -*-mode: python; fill-column: 75; tab-width: 8; coding: iso-latin-1-unix -*-
#
# $Id: README-2.1.txt,v 1.1.2.2 2002/05/18 22:03:27 idiscovery Exp $
#

About Tix.py
-----------

As of version 2.1, Tix.py is a part of the standard Python library.
However, the Tix shipped with Python 2.1 is broken.

You should replace Tix.py in the Lib/lib-tk directory, and demos in the Demo/tix
directory with the files found here.


