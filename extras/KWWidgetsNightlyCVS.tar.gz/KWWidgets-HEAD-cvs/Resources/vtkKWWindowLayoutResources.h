/* 
 * Resource generated for file:
 *    KWWindowLayout1x1.png (zlib, base64) (image file)
 */
static const unsigned int  image_KWWindowLayout1x1_width          = 19;
static const unsigned int  image_KWWindowLayout1x1_height         = 19;
static const unsigned int  image_KWWindowLayout1x1_pixel_size     = 3;
static const unsigned long image_KWWindowLayout1x1_length         = 40;
static const unsigned long image_KWWindowLayout1x1_decoded_length = 1083;

static const unsigned char image_KWWindowLayout1x1[] = 
  "eNpjYCAfPH1wg1Q0qnFU46jGwaaRPAAAa7/zXA==";

/* 
 * Resource generated for file:
 *    KWWindowLayout1x2.png (zlib, base64) (image file)
 */
static const unsigned int  image_KWWindowLayout1x2_width          = 19;
static const unsigned int  image_KWWindowLayout1x2_height         = 19;
static const unsigned int  image_KWWindowLayout1x2_pixel_size     = 3;
static const unsigned long image_KWWindowLayout1x2_length         = 40;
static const unsigned long image_KWWindowLayout1x2_decoded_length = 1083;

static const unsigned char image_KWWindowLayout1x2[] = 
  "eNpjYCAfPH1wg1Q0qnEQahxNAKMJgAwAAFaaxu8=";

/* 
 * Resource generated for file:
 *    KWWindowLayout2x1.png (zlib, base64) (image file)
 */
static const unsigned int  image_KWWindowLayout2x1_width          = 19;
static const unsigned int  image_KWWindowLayout2x1_height         = 19;
static const unsigned int  image_KWWindowLayout2x1_pixel_size     = 3;
static const unsigned long image_KWWindowLayout2x1_length         = 40;
static const unsigned long image_KWWindowLayout2x1_decoded_length = 1083;

static const unsigned char image_KWWindowLayout2x1[] = 
  "eNpjYCAfPH1wAyvCLzWqcVTjqMZBpZE8AABWmsbv";

/* 
 * Resource generated for file:
 *    KWWindowLayout2x2.png (zlib, base64) (image file)
 */
static const unsigned int  image_KWWindowLayout2x2_width          = 19;
static const unsigned int  image_KWWindowLayout2x2_height         = 19;
static const unsigned int  image_KWWindowLayout2x2_pixel_size     = 3;
static const unsigned long image_KWWindowLayout2x2_length         = 44;
static const unsigned long image_KWWindowLayout2x2_decoded_length = 1083;

static const unsigned char image_KWWindowLayout2x2[] = 
  "eNpjYCAfPH1wAyvCLzWqcbBpHE0AowmADAAAyjOdHw==";

/* 
 * Resource generated for file:
 *    KWWindowLayout2x3.png (zlib, base64) (image file)
 */
static const unsigned int  image_KWWindowLayout2x3_width          = 19;
static const unsigned int  image_KWWindowLayout2x3_height         = 19;
static const unsigned int  image_KWWindowLayout2x3_pixel_size     = 3;
static const unsigned long image_KWWindowLayout2x3_length         = 40;
static const unsigned long image_KWWindowLayout2x3_decoded_length = 1083;

static const unsigned char image_KWWindowLayout2x3[] = 
  "eNpjYCAfPH1wAyvCLzVCNI6G6mioDu9QBQA923NP";

/* 
 * Resource generated for file:
 *    KWWindowLayout3x2.png (zlib, base64) (image file)
 */
static const unsigned int  image_KWWindowLayout3x2_width          = 19;
static const unsigned int  image_KWWindowLayout3x2_height         = 19;
static const unsigned int  image_KWWindowLayout3x2_pixel_size     = 3;
static const unsigned long image_KWWindowLayout3x2_length         = 44;
static const unsigned long image_KWWindowLayout3x2_decoded_length = 1083;

static const unsigned char image_KWWindowLayout3x2[] = 
  "eNpjYCAfPH1wAxkRKTKqcbBpHE0AowmADAAAPdtzTw==";

/* 
 * Resource generated for file:
 *    KWWindowLayout3x3.png (zlib, base64) (image file)
 */
static const unsigned int  image_KWWindowLayout3x3_width          = 19;
static const unsigned int  image_KWWindowLayout3x3_height         = 19;
static const unsigned int  image_KWWindowLayout3x3_pixel_size     = 3;
static const unsigned long image_KWWindowLayout3x3_length         = 40;
static const unsigned long image_KWWindowLayout3x3_decoded_length = 1083;

static const unsigned char image_KWWindowLayout3x3[] = 
  "eNpjYCAfPH1wAxkRKTJCNI6G6mioDu9QBQA6QUwc";

