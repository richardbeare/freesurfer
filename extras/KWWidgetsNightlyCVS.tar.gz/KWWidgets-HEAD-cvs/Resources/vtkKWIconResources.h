/* 
 * Resource generated for file:
 *    angle_tool.png (zlib, base64) (image file)
 */
static const unsigned int  image_angle_tool_width          = 16;
static const unsigned int  image_angle_tool_height         = 16;
static const unsigned int  image_angle_tool_pixel_size     = 4;
static const unsigned long image_angle_tool_length         = 288;
static const unsigned long image_angle_tool_decoded_length = 1024;

static const unsigned char image_angle_tool[] = 
  "eNpjYMAArEC8CIgVGEgHIL3Lgfg/ENuQodcLiCcA8S0gjmUgD2wF4mCoWaQCPiD+CKXJAR"
  "FAvIGBfLAGiJ8B8RwgDiJRLyfU7RZAnAzEa4G4G4jFCehjhtL+QLwTTbwEagYxAJRmsrGY"
  "vZYIv4Di/g0OtyZDwwPmR2zADYgP45DTAOLrSPakAXEbWvqcAvUrtvRgDsR/oHpA8XMGmr"
  "6/QcMMBF5A9YPwTKiaN9D4uAIVq4SmS0eoOQpIdmyFppsJUPeB4lAYh3/0oP4gBjATUgAA"
  "SAgovg==";

/* 
 * Resource generated for file:
 *    bidimensional_tool.png (zlib, base64) (image file)
 */
static const unsigned int  image_bidimensional_tool_width          = 16;
static const unsigned int  image_bidimensional_tool_height         = 16;
static const unsigned int  image_bidimensional_tool_pixel_size     = 4;
static const unsigned long image_bidimensional_tool_length         = 144;
static const unsigned long image_bidimensional_tool_decoded_length = 1024;

static const unsigned char image_bidimensional_tool[] = 
  "eNr7//8/w38SMBAo/CdRD5JeCyB+A8SqOORliNBrg0NeFSpvQapeJHU26GYQqxebGaTqxW"
  "IGyXrR3Iw1PIjUa4MtPIjViy9MSY1fQmYQE864zAACViC+Skw4Q82YiUWcldw8MdAYAF0B"
  "WnU=";

/* 
 * Resource generated for file:
 *    bounding_box.png (zlib, base64) (image file)
 */
static const unsigned int  image_bounding_box_width          = 16;
static const unsigned int  image_bounding_box_height         = 16;
static const unsigned int  image_bounding_box_pixel_size     = 4;
static const unsigned long image_bounding_box_length         = 96;
static const unsigned long image_bounding_box_decoded_length = 1024;

static const unsigned char image_bounding_box[] = 
  "eNr7//8/w380DAT/icW49P7HYi4hdTA+If3Y1OFi49KLzz5c+rGpo0VYkSI2XPWTG66kxB"
  "2l6YbSNEtpfqE0r4IwAEZDQds=";

/* 
 * Resource generated for file:
 *    browserback.png (zlib, base64) (image file)
 */
static const unsigned int  image_browserback_width          = 16;
static const unsigned int  image_browserback_height         = 16;
static const unsigned int  image_browserback_pixel_size     = 4;
static const unsigned long image_browserback_length         = 992;
static const unsigned long image_browserback_decoded_length = 1024;

static const unsigned char image_browserback[] = 
  "eNqNk39MjHEcx28ebq7k1sNV7rl+PF2lu6vcKelIhYpyaPHEzYwYo8iSa1kKw/zIzholmh"
  "9/iYZ+nqs0paunpvNjNpKy4lJ/+KM/lET19txtbq0Yn+393/f1eX8/n70/PN70EqvEamGk"
  "kCHCCYYfzmfcIkWMVOWp5v1HKc4oSqMqIyw7zVrsat+MJFMU4utDoLzpb1mWqy79GxeXtU"
  "afYN4AfddZVHy6jRudubjwaicyWyNx0KTC3sZARJVL4HPcnRWQAslUPrY1GgXdebj3IR+F"
  "bzNw+jmDWx1ZuPhqOw40LbJrbZk35Lk+7G+OpEiJvEDGnnujQ3HHMY5LQnZbDNiBhxifGM"
  "O7wTZksivsfCqniDsUNh7V2GahVlGMpmklLr3ej5xnGui4t496r9pYa5V0nUKaabGd3fM0"
  "ANp6PwSd8rdIAzzVhJpgEp8okd4ShsPNYXbfsYmfMPWX4rQ50aaT5gRkt69HcpMKCfU0lh"
  "ZL4aYUMQIrX+drYw2TfK38l5E+9A932/R5uAt9Q13IebEdMXUSyK7NB38hnxGEcnyNzzR+"
  "dPw7Br71wjL0Hh859Q51oudrJzLMWxFmdIHXFScQNMEQwQSjqaZt803+/8jYMO5+0COtLR"
  "b72Ggkt6zEtuYIRNTRCDQ4wzvPBcKFQkYUSjLR9/1tfEpTEFJNIXjQc9nW48f4KHJf7kJU"
  "rQRLjCIEGUj4Vc2FR4UD6BR3i1gqVluz4K5zZXfUy5DcKIf2iR+0DQrU9JVwOxjD68F2aB"
  "pUkFcLIa1ygrhCALKQD8VGf3sWQzcFpwdfpxFf7Yl1jz0RXUth9WNv5HecgJ6T0iiGpNIB"
  "onI+5hQRUOoCMDV/siRfvSKfwvJKN6iNrlAZ5kHGedJVjpznbDiXzYRj0Qz4HfLGmi2x+j"
  "/dQNiG4PQFu+ezcq6PuMgBrtc4rmAWHM8T8DpCgY7zYP91f9Z9iOQkQ9A8u3huPIaSUwxJ"
  "ktPu5hdA/sg8";

/* 
 * Resource generated for file:
 *    browserforward.png (zlib, base64) (image file)
 */
static const unsigned int  image_browserforward_width          = 16;
static const unsigned int  image_browserforward_height         = 16;
static const unsigned int  image_browserforward_pixel_size     = 4;
static const unsigned long image_browserforward_length         = 1008;
static const unsigned long image_browserforward_decoded_length = 1024;

static const unsigned char image_browserforward[] = 
  "eNqNk2tIk1EYx92rSzR15txc7W1Xnc6Jzuucta7O0ghMOnQhSrAMLSu74AWDyBVYElFWWo"
  "Ra2WWUmmZaaZmXJalJZaGuyFr4pQ/1obTL6t+7F4JmGT3wwPlwfv/zP8/FxeXPUETK9cJF"
  "QsI1cAmVQBFfA49IwiV6l/+IhBK9WVcfZ9v0KB0b+1ZhTbcRKW0xiK4Ktmny1eapOK6QS2"
  "tOh1p2Dubg2utKVFsP4ujTLBT2JGF7ZzSyO8KR2qzE/KvRSM5JOjKZDz2lthQ824na0dM4"
  "M1SEA/2rcWJwK8oZvW2dUdjaEcEmaQ7C/JpIOHk+qDdn9BJUjuxHycAGFPQkIv/BAgy/f4"
  "gv38fR9PqUs0ZTEKIKIyz8AD9aoZXrdVeibYefZKG4nyC3S4ecDi3r+bLVBEc4NGpG9rEa"
  "mffDkN6uxoKqCAQmKIlgnj9JaY3FHouBybkw9aU5ZeeYGfYf31iN66NlWHdPjbQ2BaKq/U"
  "GpOMRN50YSb8pZX2VMvcY+vXDKdxNvWd4Rn+3jKHueh5Q7Mmgv8MFVU4SKoYixUfpX/u0n"
  "K8bGXzFvT7C8/YcdZ62lWHhbjuBqHrghzGzE88jiehXL7+6ew3ou7luBot7lyHu4DBdflm"
  "LC/pFlG201MNySIqLJD3S5JygZh4g1Yr32WKAt+344tjA9dtRnfXsI1jL/LHm8GV+/f2HZ"
  "CushxLfQCL7Bg6xhOuQmEQQh/sTRP0kmbU5tUCKjXYO1d1VY2cacuwwY+jDAsrVvziOmZR"
  "aCGn1AX/eA4JI7RKkCi4+fN/1rBmZu97EY62ZjeasMxts0lraqUDZsQunzvdA2iyBp8ERA"
  "vTt459wwa5cAhuS5ub/PkFIvJ7HH1YgzCzGnRYSom3xomnyhbPSCmHmTXzcN3hdcMXOHAK"
  "GL1Uem2gNFptQSViqH+IQHRBUe8DvJcEcZbi8fgiV8iy4xNvdf+zdDMIOmtWJCSTnEVcEh"
  "lJxDOGIXwlfwiZevFz35/k/Y9cb9";

/* 
 * Resource generated for file:
 *    browserup.png (zlib, base64) (image file)
 */
static const unsigned int  image_browserup_width          = 16;
static const unsigned int  image_browserup_height         = 16;
static const unsigned int  image_browserup_pixel_size     = 4;
static const unsigned long image_browserup_length         = 460;
static const unsigned long image_browserup_decoded_length = 1024;

static const unsigned char image_browserup[] = 
  "eNq906FywzAMBuA+gh+gQHAwZYNGw4YdC9wVGQx0zLDQMNCw0LAwcDCw0LDQTxBNshJnzT"
  "ay2613P2n9Rb+V62bzPx9l1O63dvu6PTShwebcPK1/s63ZxbPHdfj7aj3Zvvgvz+Cz+RZx"
  "zJLMSfSM4JE6v4EDrP5CkR7P1Qc5u04Qj7AHhCOIY99JD2fbw+zH3K8y9bkFikd4IR/Fxd"
  "5g7lv2yD5Uv/Qfs7gxcZzMj9I9XTQOHSy+c9/OnG2+WoQTSHeanyi9V7zfO7/MDdWOZF3Q"
  "5c7gAa2f/Elhaybv3f3sT9afNYKFMl9TBu4fAKNTaLSuvry/2lusOTZl/2pPs+j+mbuz78"
  "Trx6Z4f5r9YvNAeW9pz7Rr2lee7s12oLsH3ucDTJ7OplBMuhhMUc4O1LOn873neXPEer4T"
  "qOrd0aKl99HSTo3RpRs/n8+A+jl/8b/8AHiyzLc=";

/* 
 * Resource generated for file:
 *    bug_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_bug_mini_width          = 16;
static const unsigned int  image_bug_mini_height         = 16;
static const unsigned int  image_bug_mini_pixel_size     = 4;
static const unsigned long image_bug_mini_length         = 152;
static const unsigned long image_bug_mini_decoded_length = 1024;

static const unsigned char image_bug_mini[] = 
  "eNqtklkKwDAIRHtzz5nTTJsPi0ynLpCAkASfjguAC4ftOcje3RhuE87MEFm3/d9hM76KEf"
  "R+2KoW93HW87EepYF69d7XWrIWpUP5/PHVvKY89yjjQ59KDYrPZscamM9yq/2LfGf/OM7m"
  "p9zUbnvlSyA=";

/* 
 * Resource generated for file:
 *    calculator.png (zlib, base64) (image file)
 */
static const unsigned int  image_calculator_width          = 32;
static const unsigned int  image_calculator_height         = 32;
static const unsigned int  image_calculator_pixel_size     = 4;
static const unsigned long image_calculator_length         = 3100;
static const unsigned long image_calculator_decoded_length = 4096;

static const unsigned char image_calculator[] = 
  "eNqVl3lUk9kZxker7YxOazu2nemZzj/+MTOd9vR0Pz2n7cyp0057Wp1pZ6sdl7rNuFTFhU"
  "ERUUC2LKyGkAijARISliRAWEKAIIQAYQ8kLIPiggg4KoKgIMvT5wvxaDeJ3znPST748vzu"
  "+973vfd+Tz318ALgEa9F1GJqKfU09Qy1/BE9u2rVqhVpGdpX9fnlb+XkV2/VGOzHUzKrFc"
  "kZVWq5ukYv19hNikxbbkSU9Hd8/lten8WPMP7reoS95Jyt9Y00vUOh1Nqz5Zn2wiRtvVWm"
  "ddQnahucibrm7sSslsvJ+Z0DZ8v7vtDVD4/ldYxNll6ambEOAlXXAftNoIaKVVl7vvvSS7"
  "+h5wvUVwT/BfiLC0rb9iiN7ovOUaBjDGih2saB9ruA6x7gnuTnA/G+g393TvCZO3yWv2ka"
  "oW4BjTcAQ+2l8f3+wUn0/RH1tQc5+D+XEPuXY5WVVvfALO7NAaPTQA+9XRyDk76tgu8XQP"
  "0QUHuNMV4FbFeA6svUJeoi772y895YfXlq997DufQV5uF575wuegx/WYi0sLHIPoFRMjsG"
  "gPLzQFnvI/p8XkWuGWjto1AUD0KiO4+ws24Ep3YhUNGFKE0vbH3kV12c2rRlp4G+a6kXF+"
  "ALNbf8WHRea1bZHdzg/DkuAOZuoJQ6md4Lv8RO7JS6sU3Uic3RPdgo7seH4hG8I5rCGjGw"
  "RgSs5ee6mHFEq3ugr+ybXPfRZiH+t33kPxsUbWzVlt7BsJBngd8FBKV04V3RHayVAG9Tf5"
  "EC78UBH8QDH1LrEoANMmCTHNicDGxTAoHJLmSauyc/+NvGLPqu8ZV/QpxXn1E8hsFhoI65"
  "L2ifwc6Ybmyk9z/ovUUBfJwC7EgFdp0B9qiA/RnAIQ0QkEmuDjiWA4R+5kZ6oeveX99bp6"
  "Hvn6jv+DD/y0Ol+XaVaRT97KVazreubhwHlf3wp/dheh/N9vobgfB8ILIAEBUCMSVAggVI"
  "Kud9Vj/Sy4eRlt9+d/Wbf0il7x+9Pbh0gfpfflxsrEs13sIl1p6ddVbYMYcgRQfiSoHEMk"
  "BWASjPAanVQMq5WZwqGoVI149wVRei0zshynDjjHkAVv72M0PrxOrVb52m7++pbwtry0L8"
  "4GijQ6m/iQvsq5oe8l30KbuO8LPtEKnJoL+gKLIkmd1QFg0gq3YMJa45lHYCFtZLGeu1gl"
  "JkNU68/sZqBX3f9K6DC/JPiI01yTk30MP+tZFv6niowkdU5JpXsVclbqpxCCaNFOayapRx"
  "HHJtw/hr3/9BLH1/S32T+tJC/DCpsTJJN4wuriHV3UL9PVS2467n00QZmu5DltUOmcGNtI"
  "phFDmnYVbtx2yjCg2qQJhrPodM7Rh/9XuvxdD3deo5X/ihUkNlomYQHaz9asaQ7xS4U5Bp"
  "W6DjAifJaEVe2xzk2S703pxBC/tUwTEU5Opw3RQG5IkxoYlCvjoZsWdsd1555VUxfYU94B"
  "s+rL/Lj4v0triMAThZP1Wcz7w21pzOhfM3ZlDHNdfSPsL6GkSius2TYyH38ZmdMKjkuBX3"
  "MRvgIHpEu2EqskGaWn1n5cqVJ+n7K+rrvvBDxPrKmLR+NDP3lZxTYysQl94GC+fc0AxorG"
  "OQ511FcEItFAWTkBmnECxrhd5+A9mH16Jy/xrkRO+FieOWpFSNLVmyJJi+v6RW+MIPjzWY"
  "JWevoKFznm9oYb8n1EDCMcXqJhAQ04isuvsQpbVjX2gJ9kdYcbb8Nox8Lsd+G0kZlfz/FP"
  "I57gi5dYyeR6lf+Lj/CfwSUepF1DGvFZSeMadZR7AvrBB+4RbGexX6Jnj0Wckg4nN6yJv2"
  "3J/KZJ7cNxGraUWOYxrhSRWjXv7Pqa/6wg+V5JZHnb6AGtZ4ecc8J5dKYZ8nZHdCUTiA3E"
  "bWnLEPFc7raLo+jXhtBxR5V1DpvAUr972Chtucm0FEyitG6BlI/ewJ+JYIRS+qOH9lHEMO"
  "WancY82OAbh5vki39DEfY5Bp2jx7fBnXiBi1G+GnW6C1jiOda6M4ox+ni0dwMtEi8I88CT"
  "8q3ph3Ut4NK+fTIvReg5DXDjT3s9ZZ7wXN95CQcxnhyU1It84hlevyMZkT8vxr8Auz4GBU"
  "A/zF9ciqB0LizQL/8BPwl0UnGA2hsk5UMOcW5iDLwb0mqQHpZTMeVmjKBSiKRvCp5Bzrrx"
  "z7Ttog0VyGtg6ecYUomqGxzUJXC4QlmG96+T/1lR8eqzedSHTBwrjNrGEd44g40469IWb4"
  "kRWYwDzTO9MORKd1Iy77kue7oHi1E1k8jIlUHEMN448rvkHPAOonwt7uW/3rTcHxTpTUz6"
  "GkRdh/4eEl5Q8hUtWJ9KppD0tpGsJZUxeMjkHEaXsgy72Mirb5+lOXDyHZNIJgiUngf/ok"
  "fFGiITsotgWFtXMobp5nq6xTSFC3wOKa7y1V5RTXPyeauB5WnBfqrwvhKe3IrbmPtErGre"
  "yFsvgujscUXqenP/VjH/nLxIkG7VFpEwpq5lDUNJ/XOO637mszqGBsha0TiM26gkhlCzJt"
  "wBmeN4JkHZyLXhyMrMIhUSsOiRuRxj4IlhQM0/OQl7/cF35UvD7niNiBvOpZmNh7wjxGnm"
  "6DkXWQwTOHSD0EqW4IByKtCBA5cCCqCeFn+pgT1lsKz8BJTp6JZ1kXY/APSb9Cz33UD738"
  "RQvxI+NyjQHRtTDwbFPAGlQzxsC4WhxhTx2J64ZfhN0T22nzPQRI7Tzv9DPXs8zJKI7Le/"
  "FJYAk2/lM5uXVP/M133//ISM9N1Mved7AF+aIEvfZQhA051hnkO+ZjVlXOkWVjX9cgxTxN"
  "3jRidLdx7FQ3Pj5swoZd8smNO8SjW3eFXdu+K6jn/Q/Wl3LfiabfTu/e/8KDs+cC/Gckp/"
  "Rp+9nXuvJpGFn7Kp73FEX3IdXe8vC2BxSQJyNPNLplVyh5Rz28pUuXSvn7Y5QftZn6s7fv"
  "X/S+wz72/dPLfzpJofr7jgNJ1/xD8xDEmLf552L9jsTJDZ9EjW7ZGXJt++6g7v/B2+J9x/"
  "i1913vZS93hfe9c/GD2Bd4/xRy9HxoRKxop99J1/bdJ/o+2X2s8/0P15sf4e17DO85b589"
  "7fX6N+5/8v8FiV3tDg==";

/* 
 * Resource generated for file:
 *    camera.png (zlib, base64) (image file)
 */
static const unsigned int  image_camera_width          = 16;
static const unsigned int  image_camera_height         = 16;
static const unsigned int  image_camera_pixel_size     = 4;
static const unsigned long image_camera_length         = 172;
static const unsigned long image_camera_decoded_length = 1024;

static const unsigned char image_camera[] = 
  "eNrNk0EKgDAMBP1eftXnVfAtfiEmh5V2SWMEDxbm0LrTLKKquunPsKURVVfPPWR1xzTDcq"
  "21aa7v4XMXnrfqHuXgi8gNsofFAM44h55+X+99crH4Ds8h++RHHao+U/HH9x65/jzzxw4R"
  "yGQ+9+C57GffawZc4Ps3fPWvXZXsaIA=";

/* 
 * Resource generated for file:
 *    camera_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_camera_mini_width          = 16;
static const unsigned int  image_camera_mini_height         = 16;
static const unsigned int  image_camera_mini_pixel_size     = 4;
static const unsigned long image_camera_mini_length         = 488;
static const unsigned long image_camera_mini_decoded_length = 1024;

static const unsigned char image_camera_mini[] = 
  "eNrtkr1qAkEURncxhXaCYBERwUYbC63trBbttFACIhYSBEFEUQIWgiAuwRCQEFkRUriFbR"
  "CDKazS+QKSPqSyUzZNTmYnpHHzBCEDHzN3uOf+zQAK/1I6nY4uRLvdlmq1WjSbTRqNBtVq"
  "FdunVCqRzWb5jbf9jscj6/Ua0zSJRCLi+hnezuU5n8/LmJVKhXg8/nrK9/t9FosFlmXxs3"
  "a7Hd1ul+12K+Pquk6v1yMUCn2c8pPJhMPhwNULnN1+6/IJyRUKBVarFel0GrtHv9/v6GE+"
  "n8ucrmthjIQE77qHzWZDKpWStSWTSWq1Gl6v18GPx2P2+z2qLowboTtQDTAMg0QiwXQ6JR"
  "aLUS6X8Xg8Dt6ezXK55MK0ZG5F5NYe3ikWi3J+o9GIcDgse3G73Q7efhd7xoPBgNlsxnA4"
  "JJfLEY1GyWQy1Ot1aWuahqIoDl74jQOBwGcwGETs+Hw+WaeqqtL/RI9/5d9/ARF/tQ8=";

/* 
 * Resource generated for file:
 *    cdrom.png (zlib, base64) (image file)
 */
static const unsigned int  image_cdrom_width          = 16;
static const unsigned int  image_cdrom_height         = 16;
static const unsigned int  image_cdrom_pixel_size     = 4;
static const unsigned long image_cdrom_length         = 900;
static const unsigned long image_cdrom_decoded_length = 1024;

static const unsigned char image_cdrom[] = 
  "eNqNk19Ik2EYxQXDHBQNoi4kWATd7MrAEAokCiIyqIscuGwIA0dEkKbEzFgI0zGlCU5DNC"
  "YubK5uUmfh2h+0qUM33ZaaIuocM3UGoY6hEafzzRFCK3rh8I1v5/e8z3Pe98vI+HOVlZXd"
  "6u62vnO5xoY7Ol7bZDLZDb7OyviPZTQaTZubm9jZAWIxIBIBPJ4VFBXJdfz72L/Ympqah/"
  "F4HMLa3t5n5+eBYBCw2eYgkUju0Xbkb7zV+nE5hePnOpAgG1kEJieBmRmgpETpoy2Xykwz"
  "8+m+vjlMTACrK4DXNfGjsuJZLP59f3+hj6qq2q+03knXg1KpvBwMxpO+9SjQ+8aZUJQowr"
  "vMQagpSKF4sEzrI0qcpv0su30yyX8Ocf459v+Fg+wBu7usyXny8y8G6FNRR9PN39z86kMg"
  "APj9wOwssLREfG8/D6vVmhCJRL20FVKig3MPDg5WTE1N9Y6Pj6Onx/ObXVsDhDx9Ph/zt6"
  "GlpWVVq9U+l0qlF4geEniLxeIOh8PY2trime+QW8LAgBMjI0E4nSMwmTpht9uZ/wy4R/K3"
  "Wv0ExcUKF/ETZrP509DQEL1O9u1HNBrFxsYGhJoejwdutzv5bG19gbq6Ruh0rdAZ9bgmu7"
  "JG/r5Go7E5HA6eUTDp4yzJWv39/TAYDKivr8fjx0/JNcHhGGa+CwgwpNJS1TfytcJZ5OXl"
  "NanV6ojX68X09DSEZ3V1NRoaGtHZ2YXR0TGEQiF0dVmg0egSBQXXF5nle7KVqRhPUpfEYr"
  "FOLpfP6vX6PZVKhbY2E9rbX0KrbUJh4e2YRHLGT99bykCVUtKD508dp85lZ2eX5+TkuMrL"
  "1bHc3PML3MvB92ZKTV2lTqXuYGaaa5CZ+s7OUjdTPd5N3Xuh/uGD5l9u39DK";

/* 
 * Resource generated for file:
 *    color_bar_annotation.png (zlib, base64) (image file)
 */
static const unsigned int  image_color_bar_annotation_width          = 16;
static const unsigned int  image_color_bar_annotation_height         = 16;
static const unsigned int  image_color_bar_annotation_pixel_size     = 3;
static const unsigned long image_color_bar_annotation_length         = 124;
static const unsigned long image_color_bar_annotation_decoded_length = 768;

static const unsigned char image_color_bar_annotation[] = 
  "eNpjYCAZPH1wg0hEUD2ascSo//8HhEhQfw2ESFA/D4RIUB/P8D+OFPVqIESCejAiXv0tBm"
  "kgIl79YgZnICJefRpDPhARr16fYboBw3Ti1ZOUHvBoJxIAAF0xm54=";

/* 
 * Resource generated for file:
 *    color_squares.png (zlib, base64) (image file)
 */
static const unsigned int  image_color_squares_width          = 16;
static const unsigned int  image_color_squares_height         = 16;
static const unsigned int  image_color_squares_pixel_size     = 4;
static const unsigned long image_color_squares_length         = 112;
static const unsigned long image_color_squares_decoded_length = 1024;

static const unsigned char image_color_squares[] = 
  "eNpjYGD4z0AGBgIQwQBmNzSg4G1AMWTMcMYYFQPFGkBqh4v+/w0oGM04YEDNRMXDTH8Dmg"
  "n/GxhQMEgtMh5u+snBMP0gjG4+sRimnxIMAMWCXb0=";

/* 
 * Resource generated for file:
 *    color_alpha_squares.png (zlib, base64) (image file)
 */
static const unsigned int  image_color_alpha_squares_width          = 16;
static const unsigned int  image_color_alpha_squares_height         = 16;
static const unsigned int  image_color_alpha_squares_pixel_size     = 4;
static const unsigned long image_color_alpha_squares_length         = 100;
static const unsigned long image_color_alpha_squares_decoded_length = 1024;

static const unsigned char image_color_alpha_squares[] = 
  "eNpjYGD4z0AGBgIQwQBmNzSg4G1AMWQMU4uspwGkdrjoR5NHMw4oOBMVDzP9IBYyxjSv4T"
  "8yHm76ycEw/djMJxaju5McDACbV22d";

/* 
 * Resource generated for file:
 *    columns.png (zlib, base64) (image file)
 */
static const unsigned int  image_columns_width          = 16;
static const unsigned int  image_columns_height         = 16;
static const unsigned int  image_columns_pixel_size     = 3;
static const unsigned long image_columns_length         = 40;
static const unsigned long image_columns_decoded_length = 768;

static const unsigned char image_columns[] = 
  "eNpjYCAZ/AeD+8/fAxF+9qj6UfX0V08SAABmPjIz";

/* 
 * Resource generated for file:
 *    compress.png (zlib, base64) (image file)
 */
static const unsigned int  image_compress_width          = 16;
static const unsigned int  image_compress_height         = 16;
static const unsigned int  image_compress_pixel_size     = 4;
static const unsigned long image_compress_length         = 160;
static const unsigned long image_compress_decoded_length = 1024;

static const unsigned char image_compress[] = 
  "eNrFklEKwDAIQz16j+bN3CwIwcXq9rNCKC2+2EpUVbTQWsuYuto43zuViFhm/d5s328Pr6"
  "mEHplFD1TUM75byEe/Jy/0Hb5P+IrFeXzrbz/37///VjlDLCOn/LEMZp3y17GVF85hysX8"
  "MdPTN+AcmIfXXEM0ahM=";

/* 
 * Resource generated for file:
 *    connection.png (zlib, base64) (image file)
 */
static const unsigned int  image_connection_width          = 16;
static const unsigned int  image_connection_height         = 16;
static const unsigned int  image_connection_pixel_size     = 4;
static const unsigned long image_connection_length         = 160;
static const unsigned long image_connection_decoded_length = 1024;

static const unsigned char image_connection[] = 
  "eNq9kgEOgDAIA3mgj+Jp/Axlc0nDcAxjjLlE2brUtapKzKwRqgfldH17uWnfRL/qPahf/Z"
  "PNRGQCz8A9/qzu/XqYHj2g3mYGro9ZhF9H3/t3NPOl/k1/vL6af0Ufecr8e32U/8ix0h+f"
  "5U5/ovyx/1l/VpyvmjtU";

/* 
 * Resource generated for file:
 *    contour_segment.png (zlib, base64) (image file)
 */
static const unsigned int  image_contour_segment_width          = 16;
static const unsigned int  image_contour_segment_height         = 16;
static const unsigned int  image_contour_segment_pixel_size     = 4;
static const unsigned long image_contour_segment_length         = 400;
static const unsigned long image_contour_segment_decoded_length = 1024;

static const unsigned char image_contour_segment[] = 
  "eNr7//8/w38smEEOuzgxGKSXQeYtkP5Nnn4GhnIzU2MQA4TfMLgF/keRR+Nj0f+vobbi/+"
  "nj+/+npST+B6kHij0FYiVC+oHgWkiQ//+nD27AMUh9SlIczD2PwObJYdXrAlKzad0KDP0g"
  "vG/XFjibQeYDRhgDwc/83EwUvchmwGhNDXWg/o/oeleAwgybXmQ3QMMCNTzl/oH0/58ysQ"
  "enfpgZnW1NIP0/UeJa+gUDPrvBeoGqIXaDHXsU1f7fYPsf3rmCVz9IHqIfgtH8/3tiXyd2"
  "e6FYXFwMRR8qm2Gnva01XN/+3VvAasNDg/6rqapAzJC8BNYDizcMN0icZHBytP/Py8MDTS"
  "tgRTeBuBmmFqf94DzzDohfg9xiglctFv/jyrO41MIwAEe7fPw=";

/* 
 * Resource generated for file:
 *    contour_tool.png (zlib, base64) (image file)
 */
static const unsigned int  image_contour_tool_width          = 16;
static const unsigned int  image_contour_tool_height         = 16;
static const unsigned int  image_contour_tool_pixel_size     = 4;
static const unsigned long image_contour_tool_length         = 428;
static const unsigned long image_contour_tool_decoded_length = 1024;

static const unsigned char image_contour_tool[] = 
  "eNr7//8/w38smEHu/5H/OOQIYZBeBpm3lxnkfh8nSz8DgyqD+NF/QPoNEFcCMSeJ+nc21F"
  "b8P318//+0lMT/UHPyiTEHCGJDgvz/P31wA44P7dv+PyUpDiT5AoizgZgVW/gAgTBIzaZ1"
  "K1D0w/C+XVv+J8RF/2eQOPmTQebDBXQzgGBmfm4mVr3IWFND/T+DzMfzaHptzEyNCeo9cW"
  "QvSPF91Pj6dxQodnXKxB6C+jvbmkD6Z6LEtfSL64IaVwjqBWF3V2eQfn9U+38fB4r9engH"
  "vxkgeZA6bPEIBIsm9nXi1Hvl/In/C+fO+M8gefE9jnh3s7e1hqvfv3vL/77utv/hoUH/1V"
  "RVIGlI8tI7BpnXV3HlDVC8Ojna/+fl4QGpvwrE84A4EYi1COUrSJ55dwlsPgMDH7n5jlQ9"
  "APFsqHM=";

/* 
 * Resource generated for file:
 *    contrast.png (zlib, base64) (image file)
 */
static const unsigned int  image_contrast_width          = 16;
static const unsigned int  image_contrast_height         = 16;
static const unsigned int  image_contrast_pixel_size     = 4;
static const unsigned long image_contrast_length         = 740;
static const unsigned long image_contrast_decoded_length = 1024;

static const unsigned char image_contrast[] = 
  "eNql0r1LqmEYBvD3D3AK+hP8zo8SdWw6cMAiTSNw0aFBIRAEFSEOCG5G4NAaRGo6iIOji1"
  "OQi/+BlaXmt+BX0qHr3PcDishparjwhdef1/3cjwAk/DAHBwciNpuNs03PcUqVnkeHh4eL"
  "o6OjKiVut9u3jo+PpZubG+n29vZ/3kWfY4/Hg/PzcwSDQYTDYQQCAZydncHhcIzJO77xv0"
  "5PT+H3+xEKhUC92N3dhU6ng9PpxMXFhfi9q6srkN/f8DJKzefzCSuXy6FUKqFWq6HVaqHX"
  "62E0GlEqlTAajZDP5+vkZUtPXTGv14tIJAKFQgGVSgWNRoOdnR1h9/b2kEgk8PT0hNlshl"
  "qtBvJ/lp5288hnpPOJTnY8N3eyvby8xPPzM+r1OgaDAabTKVKp1MOaRzQaFbOyNRgMwnH4"
  "vC8vL3h9fUWj0cD7+zu+vr7Y/116uhexn/VOs9ksLHe+vb2h2WwK2+v1hE+n0ytPd/LIe3"
  "O73TCZTLBYLEgmk6vOVquFdruNbreLyWSCj48PZDKZ1fx0PzG+t1gsBqvVKix3suNOtv1+"
  "X+Tz81PMlMvlVvtzuVyyk5OTGs9QLpfFrMvOTqcjZua9cS/3F4vFejabla15if47v6+vr8"
  "X7xWKB8XgszHA4xHw+F718d5VKhbv3yUsbXrq7u3MVCoUJz8eG98ThXt4F9U7IOijSN16i"
  "vW5T4vf391XKmL43olTJxClbbDf9T/IPBBiT+Q==";

/* 
 * Resource generated for file:
 *    corner_annotation.png (zlib, base64) (image file)
 */
static const unsigned int  image_corner_annotation_width          = 16;
static const unsigned int  image_corner_annotation_height         = 16;
static const unsigned int  image_corner_annotation_pixel_size     = 3;
static const unsigned long image_corner_annotation_length         = 52;
static const unsigned long image_corner_annotation_decoded_length = 768;

static const unsigned char image_corner_annotation[] = 
  "eNpjYCAZPH1wg0gEV49LO5o42epJdc+oeuqqH1TxSxIAAOVLrKQ=";

/* 
 * Resource generated for file:
 *    crop_tool.png (zlib, base64) (image file)
 */
static const unsigned int  image_crop_tool_width          = 16;
static const unsigned int  image_crop_tool_height         = 16;
static const unsigned int  image_crop_tool_pixel_size     = 4;
static const unsigned long image_crop_tool_length         = 112;
static const unsigned long image_crop_tool_decoded_length = 1024;

static const unsigned char image_crop_tool[] = 
  "eNr7//8/w38oBgIQ8f8/khgpmBT92NQRqx9ZDUwPKRibneTqJ9b9lOiHiZGjH1tYEasfV1"
  "gRo5+c+CUURqToH+i0QI77r1w48Z9a+YtY/QDakT5N";

/* 
 * Resource generated for file:
 *    distance_tool.png (zlib, base64) (image file)
 */
static const unsigned int  image_distance_tool_width          = 16;
static const unsigned int  image_distance_tool_height         = 16;
static const unsigned int  image_distance_tool_pixel_size     = 4;
static const unsigned long image_distance_tool_length         = 144;
static const unsigned long image_distance_tool_decoded_length = 1024;

static const unsigned char image_distance_tool[] = 
  "eNr7//8/w38SMBAo/CdRD5JeCyD+BsSJZOp9A8RpQPwYiN3I0GsD5RsD8S0gFidVL5I4Jw"
  "l6QdiCTP/aQPFMcv1Lrr0U6KWGf7fSyc2s0PQUTEG6zgfiq8SkJyLM4KTADD1S9QAAY/tv"
  "XQ==";

/* 
 * Resource generated for file:
 *    document.png (zlib, base64) (image file)
 */
static const unsigned int  image_document_width          = 16;
static const unsigned int  image_document_height         = 16;
static const unsigned int  image_document_pixel_size     = 4;
static const unsigned long image_document_length         = 92;
static const unsigned long image_document_decoded_length = 1024;

static const unsigned char image_document[] = 
  "eNr7//8/w38qYCD4jwsTqx8bINYMfPqRaLL1EzKDkPsJhQcu/djMa2ho+D+qf/DpJxZj0w"
  "/CIHFi8X8q5VsAYJzrzQ==";

/* 
 * Resource generated for file:
 *    document_rgb_color.png (zlib, base64) (image file)
 */
static const unsigned int  image_document_rgb_color_width          = 16;
static const unsigned int  image_document_rgb_color_height         = 16;
static const unsigned int  image_document_rgb_color_pixel_size     = 4;
static const unsigned long image_document_rgb_color_length         = 104;
static const unsigned long image_document_rgb_color_decoded_length = 1024;

static const unsigned char image_document_rgb_color[] = 
  "eNrVk0EKACAIBHu6P5/qEBSoLdShjLlYg4oEFC7QApXIZ2I5y1XBzHjRVwnrC/Gbfzr/nI"
  "9cxc9cpf/M3e1/5w76Ow8u/VGPCpnZm5w=";

/* 
 * Resource generated for file:
 *    document_volume_property.png (zlib, base64) (image file)
 */
static const unsigned int  image_document_volume_property_width          = 16;
static const unsigned int  image_document_volume_property_height         = 16;
static const unsigned int  image_document_volume_property_pixel_size     = 4;
static const unsigned long image_document_volume_property_length         = 148;
static const unsigned long image_document_volume_property_decoded_length = 1024;

static const unsigned char image_document_volume_property[] = 
  "eNrV00EKgCAQQNEOFrWJoBDvELXpFp4r6BQd6GdB0MLRoWzRwN+IDxQRKMiQH7RJvpqhZm"
  "OkZKXxyy0sHUw9GAPWnt45x5d+eOi1SV4zf/Nv739fl6zGx6zm/DGbev+UvTr2hSLTHw21"
  "A2IWsiM=";

/* 
 * Resource generated for file:
 *    document_window_level.png (zlib, base64) (image file)
 */
static const unsigned int  image_document_window_level_width          = 16;
static const unsigned int  image_document_window_level_height         = 16;
static const unsigned int  image_document_window_level_pixel_size     = 4;
static const unsigned long image_document_window_level_length         = 164;
static const unsigned long image_document_window_level_decoded_length = 1024;

static const unsigned char image_document_window_level[] = 
  "eNrV09EJgCAUQNGmyT1cJDfxbeIkNoctkSPcjAr6yHxQfSTcH3kHFBHoeKGy0FbzxhistT"
  "g34MUTQiDGkTQl8pxhG0RE+MT3mx+cw3vZfSSl4nPba6t5zfqbf3r/837Navyd1Zz/zrbe"
  "v2WP1rmreOmPXrUAL4Wxcg==";

/* 
 * Resource generated for file:
 *    edit_contrast.png (zlib, base64) (image file)
 */
static const unsigned int  image_edit_contrast_width          = 22;
static const unsigned int  image_edit_contrast_height         = 22;
static const unsigned int  image_edit_contrast_pixel_size     = 4;
static const unsigned long image_edit_contrast_length         = 1008;
static const unsigned long image_edit_contrast_decoded_length = 1936;

static const unsigned char image_edit_contrast[] = 
  "eNqt1MlLW1EUBvCkf4GgK5FaWhxjEgccFlWrDSqYmMk0IoouxEYUBMEh1Y3riODCTRcBcY"
  "oLceHSjS5Kg4pDWxVbGjVOiTPEKQh+PeeCrYLxKTXwkbd47/e+e89NtFqtTEspLi7mvKBr"
  "DcVF116dThfQ6/UuisZgMMhNJpPM6XTK+vr6ZAAejPafG0XfvqqqKjQ0NKCpqQktLS1obG"
  "xETU0NjEajj9zIJ7rhVqsVdXV1aG5uBvVESkoKlEolzGYzOjo6xHu6u7tBbtgjXTllymaz"
  "CTMmJgZxcXFISEiAQqGASqVCcnIyJiYmcHJygtHRUTe5cimXuuVVV1ejtbUVsbGxiI+PR2"
  "JiIpKSkoSZmpoKh8OBtbU1nJ+fw+PxgNwcKZdm4uQ9pP0THdnj9XNHNru6urC+vg6v14uj"
  "oyOcnZ1hYGDg8yNc2O12sWY21Wq18Di8nxsbG9jc3MT29jZ8Ph+ur6/ZDUq5dH7EXG53TE"
  "9PFyZ33Nraws7OjjAPDg6EOzg4KOnS2XHyvMrLy5GWloaMjAz09PT87bi7uwu/34/9/X2c"
  "np7i8vISQ0NDkvtA5yiPz1dnZycyMzOFyR3Z445sHh4eilxdXYk1jIyMSM6ttLRUbrFYpr"
  "jz5OSkWPNNx729PbF2nhf35L7j4+Nul8t17zlra/uNj7afKCtbBrky+k1E9Pb2iueCwSAC"
  "gYCwjo+PcXFxIXryGZuenuauYeTe27G2dhVW6zKKihZvXFl/f3/U2NiYn9fJFs+Hwz15r6"
  "mnn8xIiiyUa7EsoaDgG7Ky5m67MprzC4pmeHjYRfHR816KiywNRc5mKNdsXoLUnj81RtPz"
  "mwbDj2c3S0r+33Q4vGhv96C+/hcqKlag036XNCsrV6Cnd7/LXQh57ye7B7c/2dnzki6/Oy"
  "d3nv7LZ5Gft3An7/MXodEswmZbveOqlDOS7lt6t1o9izev3SHv/WBduuO+inY/y7wKC+m8"
  "Z85BkTiD6JdfER7x5UH3Dy53Jlw=";

/* 
 * Resource generated for file:
 *    edit_volume_properties.png (zlib, base64) (image file)
 */
static const unsigned int  image_edit_volume_properties_width          = 22;
static const unsigned int  image_edit_volume_properties_height         = 22;
static const unsigned int  image_edit_volume_properties_pixel_size     = 4;
static const unsigned long image_edit_volume_properties_length         = 1372;
static const unsigned long image_edit_volume_properties_decoded_length = 1936;

static const unsigned char image_edit_volume_properties[] = 
  "eNqtlG1MU2cUx58OC24flmyaOWLjC06RVVrLy+iSCSgosKnjZQw0kGyaIAbjwuISN8iyzb"
  "F9YNNQoBTErhOqDqFlYDsl02YvTFxZKYVSXtYKWN2cEKlMNsHmv3O9WUaT3ZFsu8k/OTnn"
  "3N8597nnOWztScYiGhmLMzCW+gVj8cYlorjG4ieT9H2yjM8m5ZlNt5cn6lxB0upStk61jI"
  "WrGNtQzVhMHWPRtQzA34r9yY1tCWJJpgPRBzpRYXSj/6oPt6buYcJ3D66xKWgMg1DmtYKt"
  "rXiDRVSKWezxhbnhDYuClIbje2uGMeKbg9AzNj2Lg5U2hMjVbUxaJWYKjTD3qU9JDYUvHB"
  "mAdQJw+wDvNOD7HZi5D/xGukP2jV8Bzx3APgXklveCrVe9zWRqkRBXtEL7uHhrB9LMs+gY"
  "Ba54gcFbxCb+TWL9QvISb4hqWq8Dl8aA7It+BKefA5NWSoS4wWt0hyQlI1htAMqvABc9wH"
  "fXAMfPgGuCl+Mm0EVMC8WquoF1lCspcyNEoT4mxH3s2ea+6IZpRFLujjbg4++BFhdw3k01"
  "rvLibMMQUGEFMtoBWQsQdeYulm5tHBfihqZfmNzcOovUc0COCSj8EnivE1D/AJyw8eLs98"
  "m3n2K5ZiCNchM+9yM0y3hbiLt8t2Uy0zyHvA6g+BLw7rfU82ViUd8aKy/OPtpF9Sj2ugXI"
  "p9z0835IXjL6hLhP7LK4XjHP4ODXwBF6T00cLfX4iR3QOXhxNufT0NmWUd+vfQPsuTCD0D"
  "T9DSHuou2m0mytF2X0rVXUl7aHZzX0A/oBXpzN+bTEr6acDyknXzeKxYoazXzW4cNu7Csc"
  "Rm7uAFhi87INBRaobHPQ9lJvpEYncGYQODvMi7M5n45iXE6Nw4/ovWZuhsPmcwsKhpCTM4"
  "DUVJrvZCMTRdUfevWYHc00R6doFk5Rj03Eo+sMo4dncz49xVpoPoo0ToillR+xyMB7kZ3t"
  "xLZtDiiVNrCE04zJ68SPbKxp26/qgcFzHyY6tXaaYdN1Xm00TaafgNZRP4rr+vFobO1XxA"
  "xhMX/th6wsJwLucVQtY8/U0+6pEj8UoSpV7mnHO00/4qzrLkzX/A/UPDiDMmo8fp+J6/MD"
  "tr4yeP7eycgMZD7gxlA8tp7ffeEVjHahZLFMfXRVSuO4YpfRF7Xb6At7Xu99eGONhmKraZ"
  "+J5u/J9PR+CM3Ev9XOnf+dWV4+jpISD4qKRpCX58KO7X0LMvPzXXiRaicm2AVz33rTE7CL"
  "N23qWZDL1Y5P6IFC0Y0tm+0BStrSi+TkXhQWDgVwZZHWBbnPUW25vBtrwroEc1/OcQZwV6"
  "3s+l/+V0oKzXucDdKnrVi54jKWLO38R+4ffbM5Bw==";

/* 
 * Resource generated for file:
 *    empty_16x16.png (zlib, base64) (image file)
 */
static const unsigned int  image_empty_16x16_width          = 16;
static const unsigned int  image_empty_16x16_height         = 16;
static const unsigned int  image_empty_16x16_pixel_size     = 4;
static const unsigned long image_empty_16x16_length         = 28;
static const unsigned long image_empty_16x16_decoded_length = 1024;

static const unsigned char image_empty_16x16[] = 
  "eNr7//8/w/9RPIpH8YjEAFrT/R8=";

/* 
 * Resource generated for file:
 *    empty_1x1.png (zlib, base64) (image file)
 */
static const unsigned int  image_empty_1x1_width          = 16;
static const unsigned int  image_empty_1x1_height         = 16;
static const unsigned int  image_empty_1x1_pixel_size     = 4;
static const unsigned long image_empty_1x1_length         = 28;
static const unsigned long image_empty_1x1_decoded_length = 1024;

static const unsigned char image_empty_1x1[] = 
  "eNr7//8/w/9RPIpH8YjEAFrT/R8=";

/* 
 * Resource generated for file:
 *    error.png (zlib, base64) (image file)
 */
static const unsigned int  image_error_width          = 32;
static const unsigned int  image_error_height         = 32;
static const unsigned int  image_error_pixel_size     = 4;
static const unsigned long image_error_length         = 900;
static const unsigned long image_error_decoded_length = 4096;

static const unsigned char image_error[] = 
  "eNr7//8/w38icFTpWlUgTgDiKUB8AIgfAvEPKH4IFZsCVaP6n0hzibDXAYgnAfEDIP5PJH"
  "4A1eNAgb1KQNwGxM9JsBcdP4eaoUSi3c5AvIUCe9ExyCxnIu32A+LTVLQbhkFm+hHhb1rY"
  "jewGZzzxjRHmqXWb/u89ce//iYtPwGxi7AGpA6kH6cOiZwu29ABNJxhmLd96+T8M3Hv8nq"
  "AbQPIgdTAA0o9FXRuWPIY1nc9Zc+4/Mrh04xle+5HtBoEJUxb8D81bhC1fOCDZPwmfmXsP"
  "nkYxc/fRW9jVAcMbGWxYt+6/IA/PfwuXJGzqJyGVa3jLFq/w8v/nz6GGA3q4IscTCIDUK8"
  "rI4LP/AVKZSjBNmdv6/3//HjVsQXGDLY5A6mB2a+o74TMXVp4TtB8Uh76+YVjdgG63o60t"
  "2G4FRR1scY+MYXXJf2LdkJKU8h8fSIiNBdstJixOyO7/SPUY0WWId0Lv/+LCEqx2F+Tmwu"
  "0GqSPCPFgdSlI55h/XgBEPID7IbhB2Cion1qwf5NiPns9gYMG8ef9tvXNJMesHqeG/af9N"
  "vPEPkifBvIekpD/0tH7//v3/hjo6YBpbviQCHyA2/7XNOowzn4Fo9PQAUk+EuVOIKX+qJ+"
  "79/+XbLxTzA3x9wXZLSyn+D0if8T8iPAZF/tPnr2B9BMxOIFT+guqzl2+/EMxn2PLls5fv"
  "8NWXD2DtVHz1z+VbL1Hrs74+eD5zj2xCUQvig+RR6oGrD3HZP4mY+hc9f8HsxpXPQOIgdc"
  "iAUP1LTPvjwL59cLuNbcPxxqujVxJYPSyuVDTM8bY/8LW/QBhmLwjrmfkQlbdA6pD1EWp/"
  "4Wt/gupvkBlY/IG3rgKpR4ur04Ta4QPZ/h4M/Y/B0P8aDP1PevW/AR1plE8=";

/* 
 * Resource generated for file:
 *    error_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_error_mini_width          = 16;
static const unsigned int  image_error_mini_height         = 16;
static const unsigned int  image_error_mini_pixel_size     = 4;
static const unsigned long image_error_mini_length         = 196;
static const unsigned long image_error_mini_decoded_length = 1024;

static const unsigned char image_error_mini[] = 
  "eNqNkgEKgDAMA33a9rJtL49ECIRQq4XA1F6WrQK4EBpjIIWi740752Dv/Yhr6suH39TvXG"
  "rOiY5lqdd9WHrOHOK9nPfiO/avtSDW86VHspnBs1ceVR7xzOD33eX44v/s7xLPebh/d37P"
  "kHdYsW9nEZszkEc3/5yflOeo1tXe3f+f5+1YSTNJievY9ElVfTdYlrtJ";

/* 
 * Resource generated for file:
 *    error_red_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_error_red_mini_width          = 16;
static const unsigned int  image_error_red_mini_height         = 16;
static const unsigned int  image_error_red_mini_pixel_size     = 4;
static const unsigned long image_error_red_mini_length         = 160;
static const unsigned long image_error_red_mini_decoded_length = 1024;

static const unsigned char image_error_red_mini[] = 
  "eNqlklEOwCAIQz06N+8WIwupBcdm0h/lFawCGCDZGGBB1GUchE4+Gad8SnaeCjbss4fFGl"
  "/Mhv15FzPIudkj8fQZLJuVl8rzniHNrWCP/J/+jftvGTbzl2/w8v2d/fL/Yu/u/8/Yx2Nl"
  "umlxFbv5kFTdBXgpgFA=";

/* 
 * Resource generated for file:
 *    expand.png (zlib, base64) (image file)
 */
static const unsigned int  image_expand_width          = 10;
static const unsigned int  image_expand_height         = 10;
static const unsigned int  image_expand_pixel_size     = 4;
static const unsigned long image_expand_length         = 80;
static const unsigned long image_expand_decoded_length = 400;

static const unsigned char image_expand[] = 
  "eNr7//8/w/8BwkCQDcTbgfg4GgaJZaOpnQ3Er4H4NxSD2LNxmDsfiN9D8XwCbpgOwv8HMB"
  "yQMQCeof29";

/* 
 * Resource generated for file:
 *    expand_left_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_expand_left_mini_width          = 3;
static const unsigned int  image_expand_left_mini_height         = 5;
static const unsigned int  image_expand_left_mini_pixel_size     = 4;
static const unsigned long image_expand_left_mini_length         = 36;
static const unsigned long image_expand_left_mini_decoded_length = 60;

static const unsigned char image_expand_left_mini[] = 
  "eNr7//8/w38gBoL/MBodI4v/R1IPAFAWGuY=";

/* 
 * Resource generated for file:
 *    expand_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_expand_mini_width          = 5;
static const unsigned int  image_expand_mini_height         = 3;
static const unsigned int  image_expand_mini_pixel_size     = 4;
static const unsigned long image_expand_mini_length         = 32;
static const unsigned long image_expand_mini_decoded_length = 60;

static const unsigned char image_expand_mini[] = 
  "eNpjYGD4z4CGgYABnQ/DyHwAkMca5g==";

/* 
 * Resource generated for file:
 *    expand_right_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_expand_right_mini_width          = 3;
static const unsigned int  image_expand_right_mini_height         = 5;
static const unsigned int  image_expand_right_mini_pixel_size     = 4;
static const unsigned long image_expand_right_mini_length         = 40;
static const unsigned long image_expand_right_mini_decoded_length = 60;

static const unsigned char image_expand_right_mini[] = 
  "eNpjYGD4DwQgggEIQMR/ZDYyhonD1AMAEFYa5g==";

/* 
 * Resource generated for file:
 *    expand_up_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_expand_up_mini_width          = 5;
static const unsigned int  image_expand_up_mini_height         = 3;
static const unsigned int  image_expand_up_mini_pixel_size     = 4;
static const unsigned long image_expand_up_mini_length         = 36;
static const unsigned long image_expand_up_mini_decoded_length = 60;

static const unsigned char image_expand_up_mini[] = 
  "eNr7//8/w38gBoL//6FsGB+G0fkwDADPlhrm";

/* 
 * Resource generated for file:
 *    eye.png (zlib, base64) (image file)
 */
static const unsigned int  image_eye_width          = 11;
static const unsigned int  image_eye_height         = 10;
static const unsigned int  image_eye_pixel_size     = 4;
static const unsigned long image_eye_length         = 88;
static const unsigned long image_eye_decoded_length = 440;

static const unsigned char image_eye[] = 
  "eNr7//8/w38oBoL/6Pg/kjyyGlzihOSQ5ZH52OzGpQdNL4Y6dDfA1GFTi66eWPuJ8RuxYY"
  "Yujs9cGAYAX4LcJA==";

/* 
 * Resource generated for file:
 *    favorites.png (zlib, base64) (image file)
 */
static const unsigned int  image_favorites_width          = 16;
static const unsigned int  image_favorites_height         = 16;
static const unsigned int  image_favorites_pixel_size     = 4;
static const unsigned long image_favorites_length         = 1120;
static const unsigned long image_favorites_decoded_length = 1024;

static const unsigned char image_favorites[] = 
  "eNqVU2tsVEUYbUtRrARCSUsfhC1t9967d/Y+Zu7uvd1rH7e2SJooVM1KGkF8INGYYDUktk"
  "Ras4KRH9aSEiUBgqYrBVtgeTTBLLQYtemPIlSaQrWVQg1qKpuVkCqy5ThbICHRH3qSL5P5"
  "JmfOfOf7JiXl39H9nlp/qkXrDddnF6T8Txxo0jb3t68ejZ8tR/3T7uFHS9hLVRYtDAYCD/"
  "4XfkejvG/861ZgREDnFvpXCWWtfl1XayzrYX6cxiP1vvgHwm8J31wfCQPfZeLEtkUghEW8"
  "Xq3SpjS3VFHmVRvGXMchGTXFxQ9E3hH2fNYonAo3iD3tDULP3o3y0f2bPJfxWxtwZhYGww"
  "sQelG+9nad68CH6/L3ta3P+3Tnq7mRuiqPVWqQnNOtvt7YpQhiEycxNtCBgaPNGOrdAYwu"
  "B84+hKmLy2dyv4xGERs/jqmfj2DqSgs217n6ygzd4f4+PxxOBy47QILXHFsP/OgHvp0NDL"
  "uAX1fdyf++ARijiPek4dg28XaFSfpspjUk6339hdrDB7d6b05GM4ArlcCFwpm341IAuP4m"
  "MN2GxE9P4quPFmJtTdGNHBc7XySyzgBVn0nybUMvNTT28ooKz5dDhyqAwSzgPI+rK4Gb7w"
  "M3GvF50xK4RS2W5WJniEx3Ch76mKZphUl+leXN5P0RQmuW7L7avx0YSAV+UIB4A9fmXkw+"
  "h2hLNvKWGhcEkW6SJK1MUZT8R0QxI8k3DCPdtu3Mzi1WNyY2cv15SIxXY6R7Hdc/BEwsw2"
  "R0Dp6o8IwVC/RZ5mVuh5CMu7OQEgwG0zas8Cwd/CIEnMtCYqgQ4Sb5tm2Q+OndtdOY3D7T"
  "i/0h3y2q6iGd6HKy//fPz8ev5DUnrh1DvDcdnzSX3VrkYt+LEjtZaSkd0TZ1GvEu9O11wz"
  "GV4yphtmlK84N39ZPY9VpO14l3F2NVtXAxt8Dol2XaLkn6U16ZLSs31TciH1T90bXV/lOS"
  "9W5DZY/7/WSh4ziz7vH93EufqjcuLmJ7dEVvJoSWG4pSwL3JYQrzqKpRq6jmDrfkazF0vc"
  "Q0zfnJuu/xKaULOEcQRV2TZU3k+yzOnRMkZDZf5/oVfz7RfERSLH6XlR248xdT/wa6XoLC";

/* 
 * Resource generated for file:
 *    file_open.png (zlib, base64) (image file)
 */
static const unsigned int  image_file_open_width          = 16;
static const unsigned int  image_file_open_height         = 13;
static const unsigned int  image_file_open_pixel_size     = 4;
static const unsigned long image_file_open_length         = 116;
static const unsigned long image_file_open_decoded_length = 832;

static const unsigned char image_file_open[] = 
  "eNqdUoEJACAM6vj9bVEEJrGWgbgo3dYC0FDAWNhAUcPa297x0nqc+vTu4hlP5nNF0t/hce"
  "Nc//b4yZ/1UOk/4g2Zo6Xl/I6W5+lo9T9U3ovRAZBf4XI=";

/* 
 * Resource generated for file:
 *    filedelete.png (zlib, base64) (image file)
 */
static const unsigned int  image_filedelete_width          = 16;
static const unsigned int  image_filedelete_height         = 16;
static const unsigned int  image_filedelete_pixel_size     = 4;
static const unsigned long image_filedelete_length         = 540;
static const unsigned long image_filedelete_decoded_length = 1024;

static const unsigned char image_filedelete[] = 
  "eNqlU00og3EcfjSmzWfZMFvD2tve7UKJgzgouVhxdOciX7k4cLBakqSluPjIiovT4oKT4r"
  "ApNx+T7zhwEQ7yceH5aW+tZWx566n39/z+z9Pvff6/F/j/cwX34xnUg24UOVhmpKs/h/uG"
  "Hp8bcByz9KTrsQJ7UxjKvXjMwbZFypZkTp+cGYellqUurpVZA0OL5jEBywI5c5yukNi+gP"
  "t5BCXTpIYIZ4KHvhE59REod+IxCPMouQK+V1/CfR2FGvUif4qcn/ASxh9G1GkePP8WQsUy"
  "tU97UHasyBpjf5hoIHJ/iePb4wTqq8yxCcchuUmiP5at/q88+Z1B0R7D9X4E10cz8hZJK6"
  "ncC3VLol1HZcSEzNAunA/i0wtTJ9uGFLVhlvNEXxUMrVoev3lQFxDtPpRblkGih7AnZvqT"
  "B3Xtoj2F+qIie42Uj3AkZir7KedWUT4jd6s1qfMLPwtrlOUcUZewG4jVngDKQjIH3zvidk"
  "Dus42Q3eoiCpNEJPlbY9oBojiuJx6lRF4Kv4xR034BAU6DZQ==";

/* 
 * Resource generated for file:
 *    floppy.png (zlib, base64) (image file)
 */
static const unsigned int  image_floppy_width          = 16;
static const unsigned int  image_floppy_height         = 16;
static const unsigned int  image_floppy_pixel_size     = 4;
static const unsigned long image_floppy_length         = 92;
static const unsigned long image_floppy_decoded_length = 1024;

static const unsigned char image_floppy[] = 
  "eNpjZGRkYKQQA8F/cjCy/oYGiNiBAwfwYpgaSvRTaj9M7XDTDxPHh5HVYdNPLCbXfnLdT6"
  "n/aamf3DzESIW8CwAU7WTE";

/* 
 * Resource generated for file:
 *    floppydrive.png (zlib, base64) (image file)
 */
static const unsigned int  image_floppydrive_width          = 16;
static const unsigned int  image_floppydrive_height         = 16;
static const unsigned int  image_floppydrive_pixel_size     = 4;
static const unsigned long image_floppydrive_length         = 816;
static const unsigned long image_floppydrive_decoded_length = 1024;

static const unsigned char image_floppydrive[] = 
  "eNqtkk9I2mEYxxvIxmSImuy0BhmBzMuQsVNrO8iOxcaIhRAJKey0GqKjQwqBrCwa2cEoS5"
  "eZQpEjJ7NMyfyDojNcirA/4MHEamtBMm/fPb+fddukw1748IP39/08z8v7vE1N/3/NzqYe"
  "uVw7o6VSyRiPxzeOj4938/l8UasNQCKRPKXI1Ub+ysrRTm+vE7FYjMXv92N/fx/MXnNz8x"
  "pF7jeqsbhYjjDZQCCAhYUF+Hw+FAoF1hcIBGGKdDTy5+frvsfjQSiUwtLSNgyGDfT3+y/l"
  "WyzlCJPt6ZnH8PAahoZMUKsNl+5vNtf7h8NfMDf3AalU/QyX8RUKxV2L5fAzkx0d9WFmJo"
  "5arUZ1vH/11Wo132azPdna2npHd1Q8OTmB2/0LF77b/RXFYhHj41aoVNOQy+V5LpfbReo1"
  "xqc7Ch0cHODs7AzVahWnp6d01p+sH41Gsbm5STXcSCaTcDqdMBqN0OleY3BQs0463263R4"
  "LBIJvN5XKoVCrY3t6F1+tlZ37haLVaTEy8hV4/hr6RZ1C+VJXJ19C/SDgcRiaTAfNl+iUS"
  "CaTTaZhMJsobMDCgQltbO/V8BbG4neaag0Yz/oP8aalU2trd3e1xOBzVvb09ZLNZ9iw6nQ"
  "5TU9OQye6BzxeAx+PRHEewvByDUqkpt7S0RsgfI64QYuK5TCbz6/X6Q5fLRfNWY3XVR3Xe"
  "wGp9T+/H/Luj4/F3DofzkbI2Yoh4eD42pgaXuE10CYVCS2dn57fJSQvd44sjkUj0ifZXiS"
  "mij7jD3N0/3sB14ibxgNAT6+fnZGZ2i7hx3o9dfwA3bIHs";

/* 
 * Resource generated for file:
 *    folder.png (zlib, base64) (image file)
 */
static const unsigned int  image_folder_width          = 15;
static const unsigned int  image_folder_height         = 13;
static const unsigned int  image_folder_pixel_size     = 4;
static const unsigned long image_folder_length         = 104;
static const unsigned long image_folder_decoded_length = 780;

static const unsigned char image_folder[] = 
  "eNrtj9sJACAMAzN6R+tm0YhiEXx+KxxB9BolCWbMjCOsZyt0z93LNubOn3nRn72p5tWSA4"
  "DdxbI/5uieeu0fv/e+9wW5GqR8IQFckCHj";

/* 
 * Resource generated for file:
 *    folder32.png (zlib, base64) (image file)
 */
static const unsigned int  image_folder32_width          = 32;
static const unsigned int  image_folder32_height         = 32;
static const unsigned int  image_folder32_pixel_size     = 4;
static const unsigned long image_folder32_length         = 1660;
static const unsigned long image_folder32_decoded_length = 4096;

static const unsigned char image_folder32[] = 
  "eNrtl3tQVFUcx+9dCseazMZXOhZDD0jNR0qg4ww6obPY5DQx/NOISmMjTWEvHySiKDUFMs"
  "lDSXHGVyKibBAwGuq6iCzgKmqxunh1Y2HJaxCmXmUMW/32vevVsZHd1TbrH8/MZy5z7+F8"
  "zvmd33msIDwsD4vHIqrUrRGCD2QLUypXCvr0ucLTfPeI9u2BFMtaIc1aEmk+VRF1yVn3Me"
  "SG5eiUNkGRq9CwffyZyFHCq6z2mJc+iD1wT0Udq8M0E7jeSVqBG4dvgjI+LejqsCB3/sA9"
  "rDqS9LozPgdzhEWmLCHj2LaXam3l0046THGwV07HineEN1jvCaLz5W/YNGir60obfQUk/2"
  "5cTei0rcXBrXrJWqo/JR9ejPYf06E4d6HrVzO/2911cL2O/d0NZ20sMt8TTYUpwsbcD4Uo"
  "Knp76oc6DtmyEPizoWe3m4383kjocNWQ/YxJDpSzSzlP0+GomgCpIgSNhYMhlU+i/yO+T0"
  "V7YxZ2pAoHqBmtzd1dRY2h0ryTfTd48efD1Z3l9tgMz7sdjqpZdCzFhWYD+2HkuP+4Ca4A"
  "nQeArma+34fl8eJRnU43g6oBPeWEmt/Kz4XAtSKO6xuP2PeMhnxkCft5mR7myY3f6JKJOm"
  "+tf0feCijHOf4MzHldtNA/25N/d7oQrZzZzG5vYZ+z3HR3LIPiSIR8KBoOYwRsxUPhNL/P"
  "fpxn+yeJ1TvyBvoPMz4LoQ8XjfTHUNW3p/irftmcANc5xnfPONh2hkAqmwjZkoTOk3nMsQ"
  "rGhmN1tbDtelLrGzmP/hrGTI/QZ3WGgICAqVQ93pN/U5IwTK55F+31CXDn4TXGz/UT43yE"
  "MVbb49xi7/0hZ9O/nzkZDo59PTURJNDD8guUq+OhorR8x/83+I+cQX8ljDl9rnLsa+gY4W"
  "Uf0MnVM6GitBTfXGv+IqfRX45tKcJ5+tPpeNHbvunYFQV7WQRzbjtjvs5/zqZCkVKQnSi2"
  "Mf7JdAR580uGEVBxXdzH+V/jP21L6U9CcpzYRP88OoZ485/YMaZJKh7GNVh7ew36ResSyF"
  "V6xE4WzfTPoqO/N7+1aOwhaWco56wauJTpP82f0T8F0eHiXvrfpONJb+f9iaIx9cc39AYu"
  "cq11fuk/9kWQCodg4FO6Aubfa572/lt+82qhXt13cJ751/65/5xe4PbTnc/2w7S7i1e/VD"
  "oW6PjWnTt+c+pTlKQJl+nPYfvDfdxFRJ5Bq6TSV4BzXLstyf8I5Vgc5P2RkIqDwPauLp4h"
  "SvSnsP1gX37j10KmVDKGfee+fWahT7qtCbhQ/xacP4TBVjjIPdYv5oiO2EliHff7UnrXkR"
  "Va7vXz5TetElY6TTHMG85d0yd30XUkjke6Ho6yEWjc0gcFS4TfOb7TU8PEKjo207WapPLv"
  "uXyq967x2p7X38fc3/bLNTMAaRnQmAilNgby7gjYedcwrup1df0CoX1ejGiNGC5W0rFBnV"
  "d1XyPx2tk2ijxH1Htyn1t3xHu9b/MMTpRKRkIqCnLHMusD8Zf4aPFoyDO679UcJl/RNZ+8"
  "zfqTycvanjpAO1cD7vfOe2fJmSeMTJ0tpg3uF5BLVx5JoytRuzdMIKFkqDaXt+6S4r/4e0"
  "CNVzC9E/kcR17Q9uy+d8RSfMC/eQK1ferR/8D3v5a/ALG+JX4=";

/* 
 * Resource generated for file:
 *    folder_open.png (zlib, base64) (image file)
 */
static const unsigned int  image_folder_open_width          = 16;
static const unsigned int  image_folder_open_height         = 13;
static const unsigned int  image_folder_open_pixel_size     = 4;
static const unsigned long image_folder_open_length         = 140;
static const unsigned long image_folder_open_decoded_length = 832;

static const unsigned char image_folder_open[] = 
  "eNqdkAEOwCAIA3k6T+NnXVwkYx0qjKQhQa9UAQimVBUshPOd5t1PVTycNbN79O5Aliv6Pr"
  "tl6ZHlEhGc9+fd+VW2nYZH5KvlDO/vZI+Z/7w/7mW++nfMdz2cZb4j5od81tEF64k9/Q==";

/* 
 * Resource generated for file:
 *    foldernew.png (zlib, base64) (image file)
 */
static const unsigned int  image_foldernew_width          = 16;
static const unsigned int  image_foldernew_height         = 16;
static const unsigned int  image_foldernew_pixel_size     = 4;
static const unsigned long image_foldernew_length         = 1052;
static const unsigned long image_foldernew_decoded_length = 1024;

static const unsigned char image_foldernew[] = 
  "eNqNk3tIU1Ecx2/TTFPMsuzB5tzu3X1tu3k3UodFoyIqiCQyWvbAMFN6KZX0QiZZURAUBG"
  "EPMikprPaPRYal9rLF6LHMkiJJcjUaqVezrNm3c3tSFHTgw4Hf73zOOb8f51DU/w/YqQRC"
  "1p/x7GxKM5thomZKUkx6OhObmckNdzi0w5xOZ4Sayzabh/bYIrZ6pdjlZH5QISSVe6W4ki"
  "UGg171yxZHi3uXRRXtzxt68PjGqEOlOfErZJkxZsrcmLQ0foSDZZPe2zRP3q6KDCg7Irrf"
  "Z2k+VouJJ1w0vbQin0poPDJNUTprALQTnuPGqdwPa+eNPLVvZcyJ02WWpkBa5P2QiwJ8hG"
  "ep6D2qGWyZGNNdKY6uqVxLFb17c5N4FT8J9zdhoOsKMEjig43E2wB4FgLXiO9PxMvdUYOF"
  "YnJwGWOsr95AufHhd/8HoY7t8NfNhc+TBTiHY2BPFsJbUgBXKqrtCX3TaO4Yub8bb+uB0K"
  "6fBHz5aKtfCP+FArJPHyEEKG3AvdNA/hR0ddQhO0MbyqCFk8QvUvylpK4SeKumorXejUCr"
  "B+9CTd/70fgL5TLBj6tVrs9JOvmRzPE7iO9USH3tZ2dCCXrJulpC9d9RzmBAqcXy2eP6xx"
  "vsDQxjmaP6Pd41uHPYRnrVCnw8+G96DsNHztEapXaWtxxiRUlW/cDV9bh7Po+Ueh7o3vtP"
  "wq/LULxINzA62XbLwFkW0WazTvV9xxwItnmAV7uBgPuvKC258FUJMHHiC4aTqgyCJZ3n+R"
  "HET/G4E4DeFuDppq+EH69D1+35aK2ZhIYDeuwvjAnnzRnT77DRnUn61DqONS/lOE6v1TqG"
  "qe+3ocKJYHMx7h0XcLE8Hjtz4z65po/tS7cxQa3R+jhRJzfraOkSJ4hHzYJYwLKsaLVa44"
  "mqUf3ynOhzOTPGPpSt7JNROtvdxGT5ut5krWV58QjHC5tp1rwghbU6BUGwWSwmQxq5t91u"
  "jyTqENUndQiiwG8TBH6XiTWvJmfO0pssk03qeo4zkfwEWpJG2e3GuG//kor44X4BHTMJKw"
  "==";

/* 
 * Resource generated for file:
 *    folderxp.png (zlib, base64) (image file)
 */
static const unsigned int  image_folderxp_width          = 16;
static const unsigned int  image_folderxp_height         = 16;
static const unsigned int  image_folderxp_pixel_size     = 4;
static const unsigned long image_folderxp_length         = 476;
static const unsigned long image_folderxp_decoded_length = 1024;

static const unsigned char image_folderxp[] = 
  "eNpjYKAqYETDRIMzM43/n55h9P/kNIP/x6fo/QcKKQIxF7F60cGhfk2QGRZQMxhxuQ2hdy"
  "Ya/v9/b5fK/13tiv+3t8j939ok839zg9T/DbXiMLdxgvSD3Pz/+8T//7/0YWIsYF216H9m"
  "ZuZSoFYlkDtA/v3/uvX//2cN/49O0sGKD/Sq/9/Tqfx/R6v8/y2N0mB3gDDIHaCw+v+gCq"
  "yOKAC0BwQWF3CB3QHWdyXvPyQcZhLEP47Gg+kFuewg/VNA4fz/TBo47sBqQGGBB7/fEwZW"
  "Ny+bFaR/KshvIP0Q98+EhAUe/GyzL1jdnExmsH5QHIH07+9Rg+gHhgU+fGelM1jdrHRGsH"
  "5Q/IL0g8IWrB8YFvjw5QVWYHUz0xjA/gfFAXLaAMXv6gqh/ytK+f8vLeIBhzMorED+BbkZ"
  "ZC9ILxMT01ag/jpo+rQAsUHuIQHXQdM3A9QMUJrUIgGD8xcAOVbrJQ==";

/* 
 * Resource generated for file:
 *    grayscale_squares.png (zlib, base64) (image file)
 */
static const unsigned int  image_grayscale_squares_width          = 16;
static const unsigned int  image_grayscale_squares_height         = 16;
static const unsigned int  image_grayscale_squares_pixel_size     = 4;
static const unsigned long image_grayscale_squares_length         = 272;
static const unsigned long image_grayscale_squares_decoded_length = 1024;

static const unsigned char image_grayscale_squares[] = 
  "eNqljssNg0AMRLdOoBgKgC74noCG4AxUABwmGUteWSuINgnSwz7sm7FzDu4H3h9/jnvXdZ"
  "62bZEkiSdNU0zThGEYBO508jyH9fu+F5e7eiTLMozj6N0nX13mqG/77Q2hT1fR/vB+mxH6"
  "13UJ53niOA6UZYmiKDzLsgjzPAuhT4c+JzPoMENz1FfufJvxqf/J19vJt/37vmPbNqzrKr"
  "OqKjRNg7quZfKt5c6nS7hbn8T4msFJlzCHxPqK7Y/xf0F9EubHov4/vADtIJCe";

/* 
 * Resource generated for file:
 *    grid_linear.png (zlib, base64) (image file)
 */
static const unsigned int  image_grid_linear_width          = 16;
static const unsigned int  image_grid_linear_height         = 16;
static const unsigned int  image_grid_linear_pixel_size     = 4;
static const unsigned long image_grid_linear_length         = 44;
static const unsigned long image_grid_linear_decoded_length = 1024;

static const unsigned char image_grid_linear[] = 
  "eNpjYGD4z0AhBgIQwUAOmxr6R90/6v5R95OHATizxkg=";

/* 
 * Resource generated for file:
 *    grid_log.png (zlib, base64) (image file)
 */
static const unsigned int  image_grid_log_width          = 16;
static const unsigned int  image_grid_log_height         = 16;
static const unsigned int  image_grid_log_pixel_size     = 4;
static const unsigned long image_grid_log_length         = 52;
static const unsigned long image_grid_log_decoded_length = 1024;

static const unsigned char image_grid_log[] = 
  "eNpjYGD4z0AhBgIGdIwujsyHsRmoYDc17B/p7h/1/8gNfwDY0fAe";

/* 
 * Resource generated for file:
 *    harddisk.png (zlib, base64) (image file)
 */
static const unsigned int  image_harddisk_width          = 16;
static const unsigned int  image_harddisk_height         = 16;
static const unsigned int  image_harddisk_pixel_size     = 4;
static const unsigned long image_harddisk_length         = 624;
static const unsigned long image_harddisk_decoded_length = 1024;

static const unsigned char image_harddisk[] = 
  "eNpjYBgFMBAbG6uwYMGCpA0bNmy6dOnSh2fPnv3ft2/f0SVLllSZm5tbAJWwoOvp6elxOH"
  "HixKTVq1dfrKio+J+dnf1/x44d/z99+vT/z58//9+8efP//v37/79///7/yJEjz6ZPnz4r"
  "PT09EqiVHaR/8eLFBy9fvvz/3r17/48fP/7/4cOHYPXY9L969e7/mTP3/nd19f/PzS2+AN"
  "Qu2dTUdGTOnDn/t27dCtcPcveFCxf+37hx4//Fixf/Hz58+P/MmbP+l5fX/Hdycv3f0DD5"
  "f0ZGxUug/ubS0tJl69at+z9jxoz/QLP+A/36f+fOnWB9fX19/2F+amxs/J+YmPjf2NgYqH"
  "b7/5ycxrdA/VOBmF9dXb2nsrLy0cmTJ/8D/fO/vr4ebFZ1dc1/X1/f/wUFBf9rampAbv4f"
  "H5//3dDQ4iYrK+tGoN5WaDCKArGDgIBAR1RU1PWurq5fS5cu/Z+fX/Lf2truv7OzB9Dd3q"
  "9lZORPAdWtAuI+II4AYhWkqGADYmEgNuTg4Ci0tLQ8WlnZ8trAwPQOJyfnXlBQA3E5yB4g"
  "lgZiLiBmxJIMmEF+AmJ1IA4F4jJQ0gBiA6j5bEQmJ0aoHUJAzAM1d9ABAGhVAKs=";

/* 
 * Resource generated for file:
 *    header_annotation.png (zlib, base64) (image file)
 */
static const unsigned int  image_header_annotation_width          = 16;
static const unsigned int  image_header_annotation_height         = 16;
static const unsigned int  image_header_annotation_pixel_size     = 3;
static const unsigned long image_header_annotation_length         = 44;
static const unsigned long image_header_annotation_decoded_length = 768;

static const unsigned char image_header_annotation[] = 
  "eNpjYCAZPH1wg0iEqR6/aZSrJ9U9o+qHn3qSAAADH+Do";

/* 
 * Resource generated for file:
 *    helpbubble.png (zlib, base64) (image file)
 */
static const unsigned int  image_helpbubble_width          = 16;
static const unsigned int  image_helpbubble_height         = 16;
static const unsigned int  image_helpbubble_pixel_size     = 4;
static const unsigned long image_helpbubble_length         = 180;
static const unsigned long image_helpbubble_decoded_length = 1024;

static const unsigned char image_helpbubble[] = 
  "eNqVk10OwCAIgz06R/NmzAbJkDktJn1Q+drgj6q23nsbQ1mhHtLBQlhbx3nuHl+e80G9iO"
  "hfvvUjGjXzLrz7G4N59GLzUTv3kx+XH/tF3evH5Xuds7H3Sn7uo5p/un82P55bPb9R+bf3"
  "Hzln4/v1/4D1ncxjZXf8SfnvVXn3yPwDgkCsMw==";

/* 
 * Resource generated for file:
 *    hsv_diagram.png (zlib, base64) (image file)
 */
static const unsigned int  image_hsv_diagram_width          = 16;
static const unsigned int  image_hsv_diagram_height         = 16;
static const unsigned int  image_hsv_diagram_pixel_size     = 3;
static const unsigned long image_hsv_diagram_length         = 896;
static const unsigned long image_hsv_diagram_decoded_length = 768;

static const unsigned char image_hsv_diagram[] = 
  "eNpFx/9LlAccwPF/ou0Y+zV62AKfDcunRj9FelnRF9j5hBMiSU/qB4s6L1dkXZ1PccTpZ3"
  "nP+mGuRfg0WmOj8jEyKiGfrWwNKh87zFwyH215dua39J7nHYzG4PXLK7luldSqrafUmKib"
  "pehzKSmS7ao0qcdE/Uo+02RjkexXpUVNiVqXXFXWtq4YM+S/CnUT2sGSj1E+oDHE49BTPj"
  "zCR59SuYTOEIuhSULftRWXyYY1fK/4E8odlD0sXU7JMhIKrjLIspN8spqapXQrFJTXKBdk"
  "zSbZupYOzc9pvWgNrPyC0hJSGlltiJIWVq9n3wruaBS0PNolWbtNIuVcDvuT4XuEj1K6gS"
  "/LOBPmWXiYsrOUV3C4lLthCuEpwr9KuS6VW7iqB3n9IXqKSCXVFbTrPNdHqDjP9hqMCPd0"
  "Cvo0epdsqZIdEW5Eg6noI6IZanazrxYryovoKLWXqDvANzU8jFKIzhC9JZGdsquKnngwHR"
  "8g/gOxRo428Euc0fg4DVc4mKA9xpM4fnyWeK9U1cruan43ghljEOMnmk+Rbua6wbjxD83d"
  "nGzlxyRZA9+Yw+iT6j1SX8efZjBr/oVpkzlLe4Yek1dmjsxdvj3HtQxDJr45j/lI6vbKgX"
  "pcK5iz/sbqoeMilzvos8hZr7H+4OLP3O5gxMK33mJlpT4mjTGe28Fb+yX2Azq76LZ5YpO3"
  "32D303WT+52M2QT2AvawxL6WpkOMOsGCM4kzQO9v3HcYcph2ZnGGcfpwe5lwCJxFHE8ONc"
  "mJBBMuBfcN7gj9A2Rdxlzm3HnccdwsL/qZcgncAm5OEifaTqeY9vC9ebwcnseYR95jwVvE"
  "y+ONM+Ex54Hn4820pU4njyekJS2t6VZJp9/77y3/X/59MnH8HegGDZQ=";

/* 
 * Resource generated for file:
 *    info_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_info_mini_width          = 16;
static const unsigned int  image_info_mini_height         = 16;
static const unsigned int  image_info_mini_pixel_size     = 4;
static const unsigned long image_info_mini_length         = 176;
static const unsigned long image_info_mini_decoded_length = 1024;

static const unsigned char image_info_mini[] = 
  "eNqtk1EOgDAIQzn6jrabYaZrrKxszkjSH8eDQtDdzUmlFM/kIVdxszCzU4odc29x1FqHGo"
  "pv3xQPH5hn5VkFe1j1Vv3ZQ9Z/5v9vvs2zw2P+bIc8e6zBbO9rlx2TPrK+6h5xX7EOuBkL"
  "cS7qiF3ZG/UbeexqV+z7Cx/+zeHtAEpHBL0=";

/* 
 * Resource generated for file:
 *    interpolation_bilinear.png (zlib, base64) (image file)
 */
static const unsigned int  image_interpolation_bilinear_width          = 16;
static const unsigned int  image_interpolation_bilinear_height         = 16;
static const unsigned int  image_interpolation_bilinear_pixel_size     = 3;
static const unsigned long image_interpolation_bilinear_length         = 116;
static const unsigned long image_interpolation_bilinear_decoded_length = 768;

static const unsigned char image_interpolation_bilinear[] = 
  "eNp7/RoEtiGBV0gAU/w1iep3gIEXGHiCwQ4kABGByCKLk6oeIu4IBnORAEQElznEqEf2L0"
  "RNPRKAiEBkXyOBwaOe1uFD6/jFla4wxSH+JVU9APWd2fg=";

/* 
 * Resource generated for file:
 *    interpolation_nearest.png (zlib, base64) (image file)
 */
static const unsigned int  image_interpolation_nearest_width          = 16;
static const unsigned int  image_interpolation_nearest_height         = 16;
static const unsigned int  image_interpolation_nearest_pixel_size     = 4;
static const unsigned long image_interpolation_nearest_length         = 64;
static const unsigned long image_interpolation_nearest_decoded_length = 1024;

static const unsigned char image_interpolation_nearest[] = 
  "eNr7//8/w/9BgIHgPzL+9+8fCkaXH2760dVPnjwZBaPLDzf9Iz3+BwoDAE7+uE8=";

/* 
 * Resource generated for file:
 *    lock.png (zlib, base64) (image file)
 */
static const unsigned int  image_lock_width          = 14;
static const unsigned int  image_lock_height         = 14;
static const unsigned int  image_lock_pixel_size     = 4;
static const unsigned long image_lock_length         = 140;
static const unsigned long image_lock_decoded_length = 784;

static const unsigned char image_lock[] = 
  "eNrVkjEOgDAIRZm9dK/GWbyFE8rwmyeJlsTJJm8o8EpLGhHm7pMxRpjZJPfMJ3E5AU91XD"
  "rnycu8HPaTy770VKOegvGOx7vX+FeP71lRvWPflmDeN4/zqLx5f+jXhR7/WYd0TrUDvkA=";

/* 
 * Resource generated for file:
 *    mag_glass.png (zlib, base64) (image file)
 */
static const unsigned int  image_mag_glass_width          = 16;
static const unsigned int  image_mag_glass_height         = 16;
static const unsigned int  image_mag_glass_pixel_size     = 4;
static const unsigned long image_mag_glass_length         = 152;
static const unsigned long image_mag_glass_decoded_length = 1024;

static const unsigned char image_mag_glass[] = 
  "eNrFk9EJADEIQ2//DdwmA7hT7zwIhFJU/KkQKNXXWGkBPEj0xVKhqKfM7K9396URe5FDw5"
  "cR9aHuGeqrHCNy2V3ofWI7PWjvU36f26n/agaVd+ZPaR/q22H5Bva9Lss6ridsR7dY/ScT"
  "Vs+Ysi/t7mza";

/* 
 * Resource generated for file:
 *    minus.png (zlib, base64) (image file)
 */
static const unsigned int  image_minus_width          = 12;
static const unsigned int  image_minus_height         = 12;
static const unsigned int  image_minus_pixel_size     = 4;
static const unsigned long image_minus_length         = 152;
static const unsigned long image_minus_decoded_length = 576;

static const unsigned char image_minus[] = 
  "eNr7//8/w38gBgJZIC4A4u1A/AqKt0PFZP9D1UHVWgLxBiDuB2IPIBaFYg+oGEjOEslcEN"
  "8f2Qw08/yhamBu6MelFklPP5J7PYhQ74HkN1Go2H9sGConihQOpKgn1T2k+pek8CQ1vv6T"
  "mB4APezfsQ==";

/* 
 * Resource generated for file:
 *    small_counter_blue_1.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_1_width          = 11;
static const unsigned int  image_small_counter_blue_1_height         = 13;
static const unsigned int  image_small_counter_blue_1_pixel_size     = 4;
static const unsigned long image_small_counter_blue_1_length         = 108;
static const unsigned long image_small_counter_blue_1_decoded_length = 572;

static const unsigned char image_small_counter_blue_1[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbEIYl9pbt18QpRYE3r37QrS5Q0ktMi"
  "DGXFzh6+5d+p+YOAapA8UziCaEQeoA1RmIJw==";

/* 
 * Resource generated for file:
 *    small_counter_blue_2.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_2_width          = 11;
static const unsigned int  image_small_counter_blue_2_height         = 13;
static const unsigned int  image_small_counter_blue_2_pixel_size     = 4;
static const unsigned long image_small_counter_blue_2_length         = 144;
static const unsigned long image_small_counter_blue_2_decoded_length = 572;

static const unsigned char image_small_counter_blue_2[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbEIYXe2mLRf+w8Dxk3fxqkXG7959IV"
  "rtrdsviFI7d8ERotyATR02tbjUYVMLUocMQHqJ8Rs2c929S/8TE8cgdaB4BtGEMEgdAL3e"
  "ikU=";

/* 
 * Resource generated for file:
 *    small_counter_blue_3.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_3_width          = 11;
static const unsigned int  image_small_counter_blue_3_height         = 13;
static const unsigned int  image_small_counter_blue_3_pixel_size     = 4;
static const unsigned long image_small_counter_blue_3_length         = 144;
static const unsigned long image_small_counter_blue_3_decoded_length = 572;

static const unsigned char image_small_counter_blue_3[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbEIYXe2mLRf+w8Dxk3fxqkXGt26/IF"
  "rtu3dfCKqdu+AI2A0g9xBrLsi9IH3EuhefWpBZ5IQDtvB19y79T0wcg9SB4hlEE8IgdQB7"
  "+Yqq";

/* 
 * Resource generated for file:
 *    small_counter_blue_4.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_4_width          = 11;
static const unsigned int  image_small_counter_blue_4_height         = 13;
static const unsigned int  image_small_counter_blue_4_pixel_size     = 4;
static const unsigned long image_small_counter_blue_4_length         = 132;
static const unsigned long image_small_counter_blue_4_decoded_length = 572;

static const unsigned char image_small_counter_blue_4[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbEIYl9q5C478v3X7BVFq3737QpRakD"
  "pizEWWJ6QWZCYyOH7yLkH3EmMuuWqxha+7d+l/YuIYpA4UzyCaEAapAwBwkItj";

/* 
 * Resource generated for file:
 *    small_counter_blue_5.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_5_width          = 11;
static const unsigned int  image_small_counter_blue_5_height         = 13;
static const unsigned int  image_small_counter_blue_5_pixel_size     = 4;
static const unsigned long image_small_counter_blue_5_length         = 144;
static const unsigned long image_small_counter_blue_5_decoded_length = 572;

static const unsigned char image_small_counter_blue_5[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbEIYXe3cBUf+IwMQH5/aTVsuEG0uKW"
  "ph4NbtF3jVIuPjJ+/idS8yBpmLTy3ILBgAsYl1Aza/uXuX/icmjkHqQPEMoglhkDoA7hqM"
  "kw==";

/* 
 * Resource generated for file:
 *    small_counter_blue_6.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_6_width          = 11;
static const unsigned int  image_small_counter_blue_6_height         = 13;
static const unsigned int  image_small_counter_blue_6_pixel_size     = 4;
static const unsigned long image_small_counter_blue_6_length         = 156;
static const unsigned long image_small_counter_blue_6_decoded_length = 572;

static const unsigned char image_small_counter_blue_6[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbEIYm9pNWy6A7Pv/7t0XvGrnLjiCoQ"
  "aX2uMn74LVE6P21u0X/2GAkBtAapHdDcK41CLLE1ILwiC7QQDZDnLC19279D8xcQxSB4pn"
  "EE0Ig9QBAJKbjag=";

/* 
 * Resource generated for file:
 *    small_counter_blue_7.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_7_width          = 11;
static const unsigned int  image_small_counter_blue_7_height         = 13;
static const unsigned int  image_small_counter_blue_7_pixel_size     = 4;
static const unsigned long image_small_counter_blue_7_length         = 140;
static const unsigned long image_small_counter_blue_7_decoded_length = 572;

static const unsigned char image_small_counter_blue_7[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbEIYXe3xk3f/I4NNWy7gVIuMQfrmLj"
  "hClNpbt1/gdQMuM/GpRTcTl1psZuJSi81McsLX3bv0PzFxDFIHimcQTQiD1AEALp+HaQ==";

/* 
 * Resource generated for file:
 *    small_counter_blue_8.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_8_width          = 11;
static const unsigned int  image_small_counter_blue_8_height         = 13;
static const unsigned int  image_small_counter_blue_8_pixel_size     = 4;
static const unsigned long image_small_counter_blue_8_length         = 140;
static const unsigned long image_small_counter_blue_8_decoded_length = 572;

static const unsigned char image_small_counter_blue_8[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbEIYm1oYuHX7BV61x0/e/T93wREMNj"
  "a1m7ZcAKuBqSXWDYTUIrsRpBZkDz61xLqXlHAgFL7u3qX/iYljkDpQPINoQhikDgCebo8V";

/* 
 * Resource generated for file:
 *    small_counter_blue_9.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_9_width          = 11;
static const unsigned int  image_small_counter_blue_9_height         = 13;
static const unsigned int  image_small_counter_blue_9_pixel_size     = 4;
static const unsigned long image_small_counter_blue_9_length         = 152;
static const unsigned long image_small_counter_blue_9_decoded_length = 572;

static const unsigned char image_small_counter_blue_9[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbEIYm1oYOH7yLl61t26/+D93wREwG6"
  "QWxiakdtOWC2CMSy1IHTLApxYZE3IDMn737gtevyG7gZgwwxe+7t6l/4mJY5A6UDyDaEIY"
  "pA4AITmN4g==";

/* 
 * Resource generated for file:
 *    small_counter_blue_9plus.png (zlib, base64) (image file)
 */
static const unsigned int  image_small_counter_blue_9plus_width          = 11;
static const unsigned int  image_small_counter_blue_9plus_height         = 13;
static const unsigned int  image_small_counter_blue_9plus_pixel_size     = 4;
static const unsigned long image_small_counter_blue_9plus_length         = 164;
static const unsigned long image_small_counter_blue_9plus_decoded_length = 572;

static const unsigned char image_small_counter_blue_9plus[] = 
  "eNr7//8/Q1nVmv+E8H+ouoaWTf+3br+EE4PkYXpAbFz4+Mm7WNXCAEweRMP4yGpv3X7xf+"
  "6CI3A1yGx0c5HVbtpyAYyR3YKsFqQOGeBTi+4fmB2E1L579wVDDJcbsIUdMeGLrNbdu/Q/"
  "MXEMUgeKZxBNCIPUAQD62pIF";

/* 
 * Resource generated for file:
 *    move.png (zlib, base64) (image file)
 */
static const unsigned int  image_move_width          = 9;
static const unsigned int  image_move_height         = 9;
static const unsigned int  image_move_pixel_size     = 4;
static const unsigned long image_move_length         = 56;
static const unsigned long image_move_decoded_length = 324;

static const unsigned char image_move[] = 
  "eNr7//8/w38kDAT//6OJocvDMCF1hMSxsZHNx4WJMec/Hf0FAD65wEA=";

/* 
 * Resource generated for file:
 *    move_h.png (zlib, base64) (image file)
 */
static const unsigned int  image_move_h_width          = 9;
static const unsigned int  image_move_h_height         = 9;
static const unsigned int  image_move_h_pixel_size     = 4;
static const unsigned long image_move_h_length         = 40;
static const unsigned long image_move_h_decoded_length = 324;

static const unsigned char image_move_h[] = 
  "eNr7//8/w386YiD4j08cRBPCxJhDTwwAkDrYKA==";

/* 
 * Resource generated for file:
 *    move_v.png (zlib, base64) (image file)
 */
static const unsigned int  image_move_v_width          = 9;
static const unsigned int  image_move_v_height         = 9;
static const unsigned int  image_move_v_pixel_size     = 4;
static const unsigned long image_move_v_length         = 48;
static const unsigned long image_move_v_decoded_length = 324;

static const unsigned char image_move_v[] = 
  "eNr7//8/w38kDAT//6OJocvDMCF1+OQHmxpK/AUAkDrYKA==";

/* 
 * Resource generated for file:
 *    netdrive.png (zlib, base64) (image file)
 */
static const unsigned int  image_netdrive_width          = 16;
static const unsigned int  image_netdrive_height         = 16;
static const unsigned int  image_netdrive_pixel_size     = 4;
static const unsigned long image_netdrive_length         = 808;
static const unsigned long image_netdrive_decoded_length = 1024;

static const unsigned char image_netdrive[] = 
  "eNqtklFIk1EYhmc1N7pp0IQkoS5KIy907mKCEFMLJBje1kDEbiaoTKm1maO5RRBjzCjETY"
  "SsOVeacwbWRrSSLbeFwTaLZhdbRo2aU2sQgxDevrM2kTHopgMPh/PzPt//ff9/OJz/tzo6"
  "Oo5PTk5ecrlcT6LR6I9kMgmv1/t6amrqmkQiaaTIgWLHZDJJg8HgndnZ2YhGo0FPTw/cbj"
  "cymQx2dnaQTqeRSCSQzWbh9/uTY2Nj4wqF4iKpPObbbLal1dVVxONxBAIBrK+v5/Kl/FRq"
  "CysrcRiNI+jruxwmvdJgMPgnJiawuLi467O+w+EwYrEYIpEIfD4frNZxqNVatLScw/DwXX"
  "R3a76Tf0OlUk07nU5YLBZQLdCs8Hg8Oc9sNqMwk16vR1dXF8RiMWWfobdXv0n+KHGopqbG"
  "NDg4+DkUCoHmgU6ny9UaGtJCJpOhv78fWq2W9YzOTmVWJGpc43K5C+TezH/GCkIqEAhuye"
  "XyD0aj8bfdbodSeQVNTWfQ2tqG5ubzm1VVx95QboYwExeIE3t+RTlxmBDx+fyB9vZ26A1m"
  "1NWJwePxvtHzx4SavYc4Shwkykpcg/1sJtb/6P0ZCIVC0DlAtObrl//rHkUdJxFbkCLqas"
  "PyvVoEp8+yGg2lslarFcXEnsqwvfERbP3aegfv7QqUypF+hO2Jn8jxKc/7uQZsf30OZN8i"
  "82UeL0YqdzMFqqurme9gezFrcxXYWKpFwn0aqVenMH+di1I58l+yHogRVqvAo6tlsA385a"
  "FqHx4oywpZRwk4+Rp7qS+umT/XF2f/ACu4pr4=";

/* 
 * Resource generated for file:
 *    oblique_probe.png (zlib, base64) (image file)
 */
static const unsigned int  image_oblique_probe_width          = 16;
static const unsigned int  image_oblique_probe_height         = 16;
static const unsigned int  image_oblique_probe_pixel_size     = 4;
static const unsigned long image_oblique_probe_length         = 364;
static const unsigned long image_oblique_probe_decoded_length = 1024;

static const unsigned char image_oblique_probe[] = 
  "eNqtkz0KhDAQhdNZ2W0leAIL67SewcLazsLaxmLBQkHBnwvZehMLzxCy88KsiBgWdAMPxJ"
  "ePSWZetNZCPxCvF0nf0Ma8JK348H1fFkWxiot18naGVh6G4TyOo6iqKifNJHEh43VdJ+I4"
  "zombmX9HUaT7vtfk/xT2YT845pckSdK2bVFjIaWW+sabpkkEQbAQlzKPe8gsy0Rd1yvtkR"
  "Z+HYZBep63M8wrkluWJfYokmvhVdM0ruM4O8NS+AeP+SvWeKjxZY5zwJlwNpzRwkvcDXc8"
  "zS5FL9AT7tti4Y2HHqPX6PmfZjcjC8gE5ya31DceMoasIXPH2eED2URGr7J78o6z226+Hb"
  "y5R28X+gDQIXmI";

/* 
 * Resource generated for file:
 *    orientation_cube_annotation.png (zlib, base64) (image file)
 */
static const unsigned int  image_orientation_cube_annotation_width          = 16;
static const unsigned int  image_orientation_cube_annotation_height         = 16;
static const unsigned int  image_orientation_cube_annotation_pixel_size     = 3;
static const unsigned long image_orientation_cube_annotation_length         = 76;
static const unsigned long image_orientation_cube_annotation_decoded_length = 768;

static const unsigned char image_orientation_cube_annotation[] = 
  "eNpjYCAZPH1wg0g0qh5TFjkY8agHiv9/dxKCCKpHMxmiBb96ZMNprR6uhkj3Uxj+JAEAGi"
  "K4jw==";

/* 
 * Resource generated for file:
 *    pan_hand.png (zlib, base64) (image file)
 */
static const unsigned int  image_pan_hand_width          = 16;
static const unsigned int  image_pan_hand_height         = 16;
static const unsigned int  image_pan_hand_pixel_size     = 4;
static const unsigned long image_pan_hand_length         = 536;
static const unsigned long image_pan_hand_decoded_length = 1024;

static const unsigned char image_pan_hand[] = 
  "eNqNk83LAVEUxt8/ykLyD/hM9hZSahZjY2OFLLAwk0IpC9mqsbOxmqE0CyvZWCjJBgtp5J"
  "tH5/QSGR+3TvfM9Pyee+6ZMwD+8CZyuRzy+TzwQfMYsiyjWq2yvl6v047FYoFyuYxGowHy"
  "e8dKksT6/X4PRVGQTCb5+Xw+QxAEzofDIcLhsKnH7TxaqqoiGo3eeZ/Px7lhGPD7/cwXCo"
  "UXn36/z7rL5XLT4Xg8wul0cr5cLuH1etHpdDAYDBAIBJ48Wq3WvYZKpcL7breDw+HgOubz"
  "OTweDzabDWazGdxuN/N0v0gkwnmv12NuMplwHaSl/lEdo9EI2WwW6/Ua0+kULpcL8Xic9a"
  "SzWq3IZDL3e59OJxwOB4zHY66Dzux2u1itVmg2m1xXKpViLS3yTCQSzJGegnzNIp1O43FO"
  "6N0v3C3sdvtT74rFIrbb7VeOolQqwWKxPPG1Wo379Av//z1fZigWi0HX9Y8szTj1+d0ci6"
  "IITdNM2Xa7DZvN9vV/Ig/SmvGhUOgrHwwGf+av6ElAfg==";

/* 
 * Resource generated for file:
 *    parallel_projection.png (zlib, base64) (image file)
 */
static const unsigned int  image_parallel_projection_width          = 16;
static const unsigned int  image_parallel_projection_height         = 16;
static const unsigned int  image_parallel_projection_pixel_size     = 4;
static const unsigned long image_parallel_projection_length         = 120;
static const unsigned long image_parallel_projection_decoded_length = 1024;

static const unsigned char image_parallel_projection[] = 
  "eNpjYCAKMAOxHIjx//9/FEyk3tVAPBNZkEj9ML0gzIbNHSTqxXAHiXox3EGmXlzuIFYvjD"
  "/U9YKAHwV6SXEHIeBHjl4saZAke7Ho9yPBzaTmRQwAAGn7Tvc=";

/* 
 * Resource generated for file:
 *    perspective_projection.png (zlib, base64) (image file)
 */
static const unsigned int  image_perspective_projection_width          = 16;
static const unsigned int  image_perspective_projection_height         = 16;
static const unsigned int  image_perspective_projection_pixel_size     = 4;
static const unsigned long image_perspective_projection_length         = 292;
static const unsigned long image_perspective_projection_decoded_length = 1024;

static const unsigned char image_perspective_projection[] = 
  "eNpjYCAa+AFxF4jx//9/OCYC2ADxMSA+D8QeMEEi9OsC8RYgvg3EUVAxZiCWI2CfIhDPB+"
  "JXQJwJxGxIelcD8Uwkd7Eh6RMC4slQfXVAzIMkB9O7GqpHGog/QGkeqPq3QDwBag4DHr0g"
  "MAeIe6HsV1D3YvMXNr3qULuEkMKJgUi9DFB+NYEwxKXXGIifI4cNljjEpRcE9kLjhAGHfn"
  "x6XaFpgQ2Hfnx6QeAMUjrCpt8Pj94QaPplxqMfX1iC3O2NTZII/WlAfACXJHJexJEvLwGx"
  "JS79AFviW0g=";

/* 
 * Resource generated for file:
 *    plus.png (zlib, base64) (image file)
 */
static const unsigned int  image_plus_width          = 12;
static const unsigned int  image_plus_height         = 12;
static const unsigned int  image_plus_pixel_size     = 4;
static const unsigned long image_plus_length         = 152;
static const unsigned long image_plus_decoded_length = 576;

static const unsigned char image_plus[] = 
  "eNqVktEJwDAIRLtEPjNINvAvq3QTV+lfduoS1wtcQPyqgRdQj0NNAFwgPJ3cZJFXLOU6pJ"
  "N2kIc4MdKEKbdrI/jueEaP5DelOT14qu8LKeehX/uhtzBbi7qMai3soaKv9lOdt7TP6nuh"
  "+B8+Lv7PwQ==";

/* 
 * Resource generated for file:
 *    point_finger.png (zlib, base64) (image file)
 */
static const unsigned int  image_point_finger_width          = 14;
static const unsigned int  image_point_finger_height         = 8;
static const unsigned int  image_point_finger_pixel_size     = 4;
static const unsigned long image_point_finger_length         = 96;
static const unsigned long image_point_finger_decoded_length = 448;

static const unsigned char image_point_finger[] = 
  "eNp90FEKACAIA1CP7s1XEcFaW8J+tBcigIJkFlz2rLHiTKrtX3fM395OTbLsklHLe8ob+4"
  "e7C/fCzubebftkK2UAQlwdeA==";

/* 
 * Resource generated for file:
 *    preset_add.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_add_width          = 16;
static const unsigned int  image_preset_add_height         = 16;
static const unsigned int  image_preset_add_pixel_size     = 4;
static const unsigned long image_preset_add_length         = 96;
static const unsigned long image_preset_add_decoded_length = 1024;

static const unsigned char image_preset_add[] = 
  "eNr7//8/w/9RPOQxEPxHxuTo///uJBiToh/FTiT9xLoDWR86BslFR4bsp7V+fO4npB9X+I"
  "H0wTA58UesPnRMqr0A73jHmw==";

/* 
 * Resource generated for file:
 *    preset_apply.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_apply_width          = 16;
static const unsigned int  image_preset_apply_height         = 16;
static const unsigned int  image_preset_apply_pixel_size     = 4;
static const unsigned long image_preset_apply_length         = 88;
static const unsigned long image_preset_apply_decoded_length = 1024;

static const unsigned char image_preset_apply[] = 
  "eNr7//8/w/9RPCwxEICI/+Tq/f/uJFh/dGTIfnL0EqMf3Y3IeonVD1NHql5s9pGil1w3Uz"
  "u8kc0gVS8AOoLXQQ==";

/* 
 * Resource generated for file:
 *    preset_delete.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_delete_width          = 16;
static const unsigned int  image_preset_delete_height         = 16;
static const unsigned int  image_preset_delete_pixel_size     = 4;
static const unsigned long image_preset_delete_length         = 92;
static const unsigned long image_preset_delete_decoded_length = 1024;

static const unsigned char image_preset_delete[] = 
  "eNr7//8/w/9RPCgwEPyHYXL04MKE9P9/dxInBslHR4bsp8R+fPqR3YCNBumlVD8xYTjQ+s"
  "kNOxiGhRM2jE8fALPynPk=";

/* 
 * Resource generated for file:
 *    preset_email.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_email_width          = 16;
static const unsigned int  image_preset_email_height         = 16;
static const unsigned int  image_preset_email_pixel_size     = 4;
static const unsigned long image_preset_email_length         = 104;
static const unsigned long image_preset_email_decoded_length = 1024;

static const unsigned char image_preset_email[] = 
  "eNr7//8/w/9RPGQxEPwnFuPT///dSZwYpiY6MmQ/Nv0wNbj0wmh8+rGZgS5HjP34aFz68d"
  "lLrP8JYUL2E4Ox6QdhkDixGF0vAMmCpyk=";

/* 
 * Resource generated for file:
 *    preset_load.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_load_width          = 16;
static const unsigned int  image_preset_load_height         = 16;
static const unsigned int  image_preset_load_pixel_size     = 4;
static const unsigned long image_preset_load_length         = 100;
static const unsigned long image_preset_load_decoded_length = 1024;

static const unsigned char image_preset_load[] = 
  "eNr7//8/w/9RPKAYCP4jY1L1/n93EgWjm4fPTGz6sWFcZsD0Y7OTGHfAxYl0Q3RkyP7Bpp"
  "8UvbjsJwaj64VhmLnEYHS9AFFOstM=";

/* 
 * Resource generated for file:
 *    preset_locate.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_locate_width          = 16;
static const unsigned int  image_preset_locate_height         = 16;
static const unsigned int  image_preset_locate_pixel_size     = 4;
static const unsigned long image_preset_locate_length         = 76;
static const unsigned long image_preset_locate_decoded_length = 1024;

static const unsigned char image_preset_locate[] = 
  "eNr7//8/w/9RPOQxEPyHYXL0/n93cj8Mk2IGul5SzRho/bj839DQsJ/c8AfpJccMZEwvMw"
  "Br4Nvr";

/* 
 * Resource generated for file:
 *    preset_next.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_next_width          = 16;
static const unsigned int  image_preset_next_height         = 16;
static const unsigned int  image_preset_next_pixel_size     = 4;
static const unsigned long image_preset_next_length         = 96;
static const unsigned long image_preset_next_decoded_length = 1024;

static const unsigned char image_preset_next[] = 
  "eNr7//8/w/9RPGIxEICI/6TKIav5/+4khjpk8ejIkP2E9CObgS5GrH64GWh8fPqxmUGKXn"
  "zuIFYvqWFGyAxS9AIAeUPX6Q==";

/* 
 * Resource generated for file:
 *    preset_previous.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_previous_width          = 16;
static const unsigned int  image_preset_previous_height         = 16;
static const unsigned int  image_preset_previous_pixel_size     = 4;
static const unsigned long image_preset_previous_length         = 96;
static const unsigned long image_preset_previous_decoded_length = 1024;

static const unsigned char image_preset_previous[] = 
  "eNr7//8/w/9RPIqhGAj+R0eG7CdX7/93J/+TYwZMLwyTYga6XlLMwGYvKWYgqwezsYgRox"
  "+ml9SwBMmj60WXw6cfAIh71rM=";

/* 
 * Resource generated for file:
 *    preset_rewind.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_rewind_width          = 16;
static const unsigned int  image_preset_rewind_height         = 16;
static const unsigned int  image_preset_rewind_pixel_size     = 4;
static const unsigned long image_preset_rewind_length         = 108;
static const unsigned long image_preset_rewind_decoded_length = 1024;

static const unsigned char image_preset_rewind[] = 
  "eNr7//8/w/9RPGgwEICI/8SKo6v5/+4kWF1DQ8NWQuLY9KKrwyWOSy+yOlzi+PTC1OESp7"
  "b91PA/NcIfPZ6xhRMx+kEYpAabOmziAGiAvY8=";

/* 
 * Resource generated for file:
 *    preset_update.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_update_width          = 16;
static const unsigned int  image_preset_update_height         = 16;
static const unsigned int  image_preset_update_pixel_size     = 4;
static const unsigned long image_preset_update_length         = 92;
static const unsigned long image_preset_update_decoded_length = 1024;

static const unsigned char image_preset_update[] = 
  "eNr7//8/w/9RPGQxEPwnhIkx4/+7k1gxSC46MmQ/uWYQo58S+/HppYf9uMyA8YnVj2wGTA"
  "8s/ojVDzMDWT0h/QDpp9Jj";

/* 
 * Resource generated for file:
 *    preset_filter.png (zlib, base64) (image file)
 */
static const unsigned int  image_preset_filter_width          = 16;
static const unsigned int  image_preset_filter_height         = 16;
static const unsigned int  image_preset_filter_pixel_size     = 4;
static const unsigned long image_preset_filter_length         = 88;
static const unsigned long image_preset_filter_decoded_length = 1024;

static const unsigned char image_preset_filter[] = 
  "eNr7//8/w/9RPGAYCP4TwoT0/393EicGyUdHhuynlX58ZhCjF5cZpOhFN4McvYNFPwyTox"
  "+EQfpgmBj1AL8Mzfk=";

/* 
 * Resource generated for file:
 *    question.png (zlib, base64) (image file)
 */
static const unsigned int  image_question_width          = 32;
static const unsigned int  image_question_height         = 32;
static const unsigned int  image_question_pixel_size     = 4;
static const unsigned long image_question_length         = 828;
static const unsigned long image_question_decoded_length = 4096;

static const unsigned char image_question[] = 
  "eNrNl88rrFEYx+8fYHNTFDYmU1eJpLCZGndu3YVLNhKrScnGyOZ2b4p0y2uhK03vjZAfY2"
  "GDEGWDKRullGblLgylZKHp3ibJ5nGe03umN87znnNmhubUNzW9ns/58X2e8xwA+AAa6vm+"
  "4WcKM9lMcaZrpkdH185vtvONHzTjanCDTFGmKybQ1JXzP8EcuD4mi+nWgPtSt04MnyE7xL"
  "SbA/elMFZIk93OdJpHthDGbNdYtyd7aGIf1vYScHByCYm/dxntHF3AwvoZ9I3uqOYQ8jhv"
  "cs8xLnJU49//NMwubUPnYMzrLHwSvuXFTj88gcmIrcSg+UsvNQdLkmOkz3XWLRtjIyNQ2/"
  "iNyougix+l2NbcMWQ7UqkUfCwqovYh6qprZG1Bn8lGMpmEjrY2Hh//UqMlEICS4lKqRoma"
  "Snr27j4tjTsUiXB2eVklfO3+RZ6RmGNr+LcsvqjnJB9zCvPtjz0D8cNDLhyVFRU8bqA1wn"
  "OS8qf4DucoiS/uEmX9QA6eY0OgC6o+NXFh3B+TeyR7a3OTf4Mi8lHcY1nVNNwbio3eE2uv"
  "rvtMxRB3aFZsaqA30XfIRu951KLHbPheOYn+EOtGbxK+c/ON9//k/EbKXl5czJw3+sNj3e"
  "79j5vyqT0XbKLmUf6z88GfnprK7LlBLFtVf6jzR2FtEaqvqeF8zE+DWGFV/ZXdhYL/c3w1"
  "o4HheV5jOvpnTXpEv+r+0fX+WeKS8xV+f3X/6Ny/OnzMO+F7zb40qNt/vAHfMu2/8sjfpf"
  "pxnf4zR/6pqg/X7b/Ra6LeuOXBV/bfhfD+KIT3VyG8P9/r/f0MsXi9Bw==";

/* 
 * Resource generated for file:
 *    reload.png (zlib, base64) (image file)
 */
static const unsigned int  image_reload_width          = 14;
static const unsigned int  image_reload_height         = 14;
static const unsigned int  image_reload_pixel_size     = 4;
static const unsigned long image_reload_length         = 72;
static const unsigned long image_reload_decoded_length = 784;

static const unsigned char image_reload[] = 
  "eNr7//8/w38aYCD4j4zJ0YdPnlT78InjkifW7ejqhoo+YvQSE97kxiEuTKu0RQwGAB5r2j"
  "Q=";

/* 
 * Resource generated for file:
 *    reset_camera.png (zlib, base64) (image file)
 */
static const unsigned int  image_reset_camera_width          = 16;
static const unsigned int  image_reset_camera_height         = 16;
static const unsigned int  image_reset_camera_pixel_size     = 4;
static const unsigned long image_reset_camera_length         = 880;
static const unsigned long image_reset_camera_decoded_length = 1024;

static const unsigned char image_reset_camera[] = 
  "eNqNkm9PUlEcx3kF1vrzoLmaL8S30Hrc1uYT53zQVpmbK/+kK3mWRok6kPSaUoJuIKQIim"
  "AiAhXCDQpF4XK593K513sx3Rhz7BuXSWNsbj747uyc8/n8zm/nHAAqXISiqKZs6s8gE985"
  "ZvbWwf50gA3ZwQas4IL2Ey7mn2AYpgl1Ti00TXew+z9Oc6QTUswNPryChHseMcc0kq5pnO"
  "yaIH37hLx3tswnyb4GV82SHoikC3trBGwzozATehi/2EDM26EnlmE06OExDEF0jkFyaCBG"
  "N5cUN51OP2DjPoiRVWyaJ+ALxrGwLWPOI8PgkqBdOcaIVcCwmYfVLyPhnEN28TUKVjVo0t"
  "+eTZIkE1pCPLiB8/NzLAdOMLspQ++UcP32XVy71Yw3pjz65nOVka8yXHQbjLEXEV1PMRW0"
  "lnOZJIrFYnXPvF3ApEOExi7i2s1mNN24g5dzHJ4bGPRXRoVRWDEZxffRTmTThyVJknB2do"
  "ZSqQR3pFDpl4fazGHAyKBnJounehqd4xQ+uoQqo7CKc2gdK9PRrSM+/RuFQqG6nsz+hW6V"
  "Qy+RqZxJ4fFkCu0fjtA3m0H4QK4yCsvFQkgRL06pg9ij3O4S8pX7P2bTkGUZkX0exBqFnq"
  "l9PJtMQGtJIfArV/UkngUf+IrMeAd29EM65Q0SYb+OXp+C6DFAiLiPhCQZFrisTxAEby35"
  "fN7LxwJhzqYBVXGdI13h+j8Q8jp7fQtjxUPTMHj7W/AuPfK7FvB+C7gNArT1HbjPAwhpu8"
  "sqlaKg5SL/a/i0XSqbuuPe4qu2J5bBtpjCbb3vklf7H/JuTTcRNGnvK2u1NPqNaWBa6t26"
  "Glf2a7ms/0v81npXmV+l94u0XtJzrabqH0wi968=";

/* 
 * Resource generated for file:
 *    reset_contrast.png (zlib, base64) (image file)
 */
static const unsigned int  image_reset_contrast_width          = 16;
static const unsigned int  image_reset_contrast_height         = 16;
static const unsigned int  image_reset_contrast_pixel_size     = 4;
static const unsigned long image_reset_contrast_length         = 792;
static const unsigned long image_reset_contrast_decoded_length = 1024;

static const unsigned char image_reset_contrast[] = 
  "eNp9kstLYmEYxo/9BQMzq6FFs/CaecXcxEDgTkVNnaBNLlokCIJQIrhprQgu3LQQxEu2CB"
  "dugohsN64G/4Eumje0ELyUGD3zvR+c5hAzs3jwcM77+57ne14dDofgYLLb7aQl9mxjKrPn"
  "ptPpHLtcrjKTze12y7a2toRsNivkcjkBAJfjD7/Mfnu7u7sIhUKIRCI4PDxEOBzG3t4ePB"
  "5Pj/Ff/8F/3t7eRjAYxMHBAZgvjEYj1tbW4PV6EY/H+XmpVAqM//SBlzFd7+/vc1Yul0Op"
  "VEKtVmN1dRU6nQ4GgwEXFxcYjUY4Ozv7yXiZyDOvzUAggGg0CoVCAZVKBY1GA61Wy1mTyY"
  "REIoHb21vMZjPc3NyA8d9FnnWTpTuy+3FP4ig3eRKbTCZxd3eHZrOJp6cnTKdTFAqFYwmP"
  "WCzGsxKr1+s5R6L73t/fo9Vqod1uo9fr4e3tjfi5yLO98H6knhaLhbPk+fDwgE6nw9nhcM"
  "j5YrH4zrOdZKm3nZ0dmM1mrK+vI51Ov3t2u130+30MBgNMJhO8vLygVCq952f72aS9HR0d"
  "wWq1cpY8iSNPYh8fH7kWiwXPUq/XfzB2hXifzyfz+/3XlKFWq/HvxFJWYqgzEvlSd1dXV7"
  "8Egaw5v8J4gf13vmQyGZ5vPp9jPB7zXdMcceT7/PyMRqPB34mS8EI+n1+uVCp96oxmqSea"
  "ofOoi8vLy6GUFSXhBdbrEpPt5OSkXK1WB/T9/Py8enp6ant9ff0mZpbmF3v8i8S5DcksaU"
  "PCC//jxdmPkpwp/AYKGnKZ";

/* 
 * Resource generated for file:
 *    rotate.png (zlib, base64) (image file)
 */
static const unsigned int  image_rotate_width          = 14;
static const unsigned int  image_rotate_height         = 14;
static const unsigned int  image_rotate_pixel_size     = 4;
static const unsigned long image_rotate_length         = 100;
static const unsigned long image_rotate_decoded_length = 784;

static const unsigned char image_rotate[] = 
  "eNr7//8/w38KMBD8R8bk6qWWfYTEZ86cSVAenxg+N5GrD6aO3vrwhRc2Pdj04QtLXG5Cj0"
  "N0jG4XMobFHzb1hPwP049PPQCDS9XS";

/* 
 * Resource generated for file:
 *    rows.png (zlib, base64) (image file)
 */
static const unsigned int  image_rows_width          = 16;
static const unsigned int  image_rows_height         = 16;
static const unsigned int  image_rows_pixel_size     = 3;
static const unsigned long image_rows_length         = 44;
static const unsigned long image_rows_decoded_length = 768;

static const unsigned char image_rows[] = 
  "eNpjYCAZ/CcakKf+/vP3RCLy1I+6f3i7nyQAAGY+MjM=";

/* 
 * Resource generated for file:
 *    scale_bar_annotation.png (zlib, base64) (image file)
 */
static const unsigned int  image_scale_bar_annotation_width          = 16;
static const unsigned int  image_scale_bar_annotation_height         = 16;
static const unsigned int  image_scale_bar_annotation_pixel_size     = 3;
static const unsigned long image_scale_bar_annotation_length         = 52;
static const unsigned long image_scale_bar_annotation_decoded_length = 768;

static const unsigned char image_scale_bar_annotation[] = 
  "eNpjYCAZPH1wg0g0ktUja8TDRlOPi8SqnmAEjczwJwkAAKI609c=";

/* 
 * Resource generated for file:
 *    seed_tool.png (zlib, base64) (image file)
 */
static const unsigned int  image_seed_tool_width          = 16;
static const unsigned int  image_seed_tool_height         = 16;
static const unsigned int  image_seed_tool_pixel_size     = 4;
static const unsigned long image_seed_tool_length         = 64;
static const unsigned long image_seed_tool_decoded_length = 1024;

static const unsigned char image_seed_tool[] = 
  "eNpjYCAK/GegDAyE/v9IGBufVvb/H4T6qRVW/ym0fyD0D1Q6GIz6MQAA0yQj3Q==";

/* 
 * Resource generated for file:
 *    shrink.png (zlib, base64) (image file)
 */
static const unsigned int  image_shrink_width          = 10;
static const unsigned int  image_shrink_height         = 10;
static const unsigned int  image_shrink_pixel_size     = 4;
static const unsigned long image_shrink_length         = 56;
static const unsigned long image_shrink_decoded_length = 400;

static const unsigned char image_shrink[] = 
  "eNr7//8/w38iMRCAiP/EiKOL4dKLLIdPDTHmkGIeMe4jxb/UwgDCL/cJ";

/* 
 * Resource generated for file:
 *    side_annotation.png (zlib, base64) (image file)
 */
static const unsigned int  image_side_annotation_width          = 16;
static const unsigned int  image_side_annotation_height         = 16;
static const unsigned int  image_side_annotation_pixel_size     = 3;
static const unsigned long image_side_annotation_length         = 60;
static const unsigned long image_side_annotation_decoded_length = 768;

static const unsigned char image_side_annotation[] = 
  "eNpjYCAZPH1wg0iEVT0eo6iinlT30EI9LjejiZOtfrD5d1DFL0kAAOVLrKQ=";

/* 
 * Resource generated for file:
 *    spin_down.png (zlib, base64) (image file)
 */
static const unsigned int  image_spin_down_width          = 8;
static const unsigned int  image_spin_down_height         = 4;
static const unsigned int  image_spin_down_pixel_size     = 4;
static const unsigned long image_spin_down_length         = 80;
static const unsigned long image_spin_down_decoded_length = 128;

static const unsigned char image_spin_down[] = 
  "eNpjYGDIZmBg2A7Ex9EwSCz7////QIphNhC/BuLfUAxizwbJwTAQzAfi91A8H1kOSc10EE"
  "YWAwDjtzKJ";

/* 
 * Resource generated for file:
 *    spin_left.png (zlib, base64) (image file)
 */
static const unsigned int  image_spin_left_width          = 4;
static const unsigned int  image_spin_left_height         = 8;
static const unsigned int  image_spin_left_pixel_size     = 4;
static const unsigned long image_spin_left_length         = 64;
static const unsigned long image_spin_left_decoded_length = 128;

static const unsigned char image_spin_left[] = 
  "eNr7//8/w38oBoJsJPZsIN4OZc8H4tdAfByIpwPxeyD+jY2Prh6becj2AQATAzKJ";

/* 
 * Resource generated for file:
 *    spin_right.png (zlib, base64) (image file)
 */
static const unsigned int  image_spin_right_width          = 4;
static const unsigned int  image_spin_right_height         = 8;
static const unsigned int  image_spin_right_pixel_size     = 4;
static const unsigned long image_spin_right_length         = 64;
static const unsigned long image_spin_right_decoded_length = 128;

static const unsigned char image_spin_right[] = 
  "eNpjYGDI/v//PwMMA8F2IJ6NxD8OxK+BeD4S/zcQvwfi6Tj4yOrRzUOxDwBd1DKJ";

/* 
 * Resource generated for file:
 *    spin_up.png (zlib, base64) (image file)
 */
static const unsigned int  image_spin_up_width          = 8;
static const unsigned int  image_spin_up_height         = 4;
static const unsigned int  image_spin_up_pixel_size     = 4;
static const unsigned long image_spin_up_length         = 76;
static const unsigned long image_spin_up_decoded_length = 128;

static const unsigned char image_spin_up[] = 
  "eNr7//8/w38oBoLpIPwfSQxJbj4Qv4fi+Whys4H4NRD/hmIQezZULhuItwPxcTQMEssGAI"
  "0RMok=";

/* 
 * Resource generated for file:
 *    standard_view.png (zlib, base64) (image file)
 */
static const unsigned int  image_standard_view_width          = 16;
static const unsigned int  image_standard_view_height         = 16;
static const unsigned int  image_standard_view_pixel_size     = 4;
static const unsigned long image_standard_view_length         = 876;
static const unsigned long image_standard_view_decoded_length = 1024;

static const unsigned char image_standard_view[] = 
  "eNqlk91LU2Ecx3fXnUY1MaQg6CqiQPsfoqvoMgjsIiTI6I0QUstV7i5Lmi/suHTmRjoN59"
  "acm+4lN3UbNbe11XS6l7Nzzs7O2TmzjCG2vu0MAi/yJi9+fOF5Pt/v7+F5fo9MJvMAkMn+"
  "Uw9SUsbenHQ6XZNNfuuiYksFanUe9Gcr6IAZtM8Ixm/eYqLLAxRF1fwriyTJFnrt049cxA"
  "Yh6gAbtCDu0CFqHUbCPoytlQkIi2+Rd4+W2USkY2//ildJR1zgI3aszmlhGnkJg5aA/p0J"
  "Wp0ZhHYGeg0Bl0YB3qaCYO0FH3ZOSRmpVOoyHfOCD83CaRiA1x/DuEfEmEuExi6gz1JAj5"
  "FDt4GFcVlE3DaG7OQzFI1K1NfJ18+dPfOTCkwh5l/A7u4uZnxbGHWKIGwCDstPoPZYA55P"
  "5NGhy1WUrTJM2ANK346Quq2U9BvLuUwCpVKpumfwFDFo5dFr5lF7tAE1R47j0RiDBxoKnR"
  "WVGInlE2GcP1WPC02NvwVBwPb2NnZ2duAIFSvnZaE0MHisp9A2ksVdgsTN/jTe2LkqI7GS"
  "Z8OoKpPhj5ts6iuKxWJ1PZH9DvUsg3ZtptIzjdbBJG683kTHaAbBdbHKSCwTDaDxdMOvOr"
  "k8nluZQr5y/wU6BVEUEVpjoZ1Lo21oDfcG4+ibTsL3JVf1CSwN1vcBmf4WLBEKtfQG8eCy"
  "mpwfAu/SgAs5NrlEJMgxWS/Hce6/lc/n3WzUF2RMvUhXvLae+8G98xdw29q946rSxkQ3WP"
  "MLsHYCjEsH2qkDs6AFaXwFUt2KReX1sqX/6ch+M21StpycfNJ8Z7qrOWpRNHNzimuF2c6r"
  "7PuHV1S625ea9LcuHtpv/g/yj/5X/wCSWdmW";

/* 
 * Resource generated for file:
 *    stopwatch.png (zlib, base64) (image file)
 */
static const unsigned int  image_stopwatch_width          = 16;
static const unsigned int  image_stopwatch_height         = 16;
static const unsigned int  image_stopwatch_pixel_size     = 4;
static const unsigned long image_stopwatch_length         = 220;
static const unsigned long image_stopwatch_decoded_length = 1024;

static const unsigned char image_stopwatch[] = 
  "eNqlk90NgCAMhFnIhHEYwmmcgFe36GbVEk/PCip6SaPRfsfxJyJBXK1SXzFGlUpvjYOMgZ"
  "58wBVmGI6y7xsHH+/BY+o4alXUY/2eL/7M2vs2fkpJOR9n2MeepmoGZs9xguac9cKTT4sF"
  "j/8l+zxf+BbLc9h7wOP5oODWpVeY/ylDB8tn4AvP+9+ToXWG4XG3X2/uEfv4+2fr7fvN+k"
  "8tCF7Dnw==";

/* 
 * Resource generated for file:
 *    testtube.png (zlib, base64) (image file)
 */
static const unsigned int  image_testtube_width          = 16;
static const unsigned int  image_testtube_height         = 16;
static const unsigned int  image_testtube_pixel_size     = 3;
static const unsigned long image_testtube_length         = 672;
static const unsigned long image_testtube_decoded_length = 768;

static const unsigned char image_testtube[] = 
  "eNq7/OTJZbLQlSdPzty/P2f//rJly0qWLAGShYsW1a1evebUqUuPH2Oq33D2bFJXl5SaWk"
  "J2dnJubkpeXlJurmtgoIqNTe2qVSfv3r3+/DlE5bVnzzadO1e6dOmSgwdj09MTq6uXb9y4"
  "Zf/+A1evBkVEdMybN3XXruqVK4FaIOqBzqhYvnztqVMfv307d/WqY1LS1vPnv/78CUTFFR"
  "VA8tmHD71bt07Yvv0G2Iplx441rVv34uNHoNTVmzcx1QPRxYcPgd45dPMmUH3VypWrTp6E"
  "iAPVqzk6FkycCHTP3vPn0/LzIeKvP30Cmrn4yBGg+ux5884+eABXr2JnF19T0zxlSs+SJX"
  "D1n3/8WHL06LyDB4Hqs+bOvf70KVy9upNTSkND4+TJXQsXZhQUQMSBCBiwEPVAh22BORiX"
  "+vdfv07auXM+WP203bsnbt8ODBw86h+8eVO6bNm2ixeB6vdfu1a0ePHpe/dwqf/4/fvKEy"
  "eqVqy4+vQpUD2QnLF3b8PatdefPbuCoR5o787Ll4GxCXQzUAE0PTx+PGHHDqAJMzdtkre2"
  "tk1Lq+jtBaqPTE9feOhQ8ZIly48fR0s/QL3rT5/OmT1b2dLSIjraMj7eKznZLS+vdvXqA9"
  "evXwG7BEsqffp03cmThbW1QNQxezYkQpERAK4JK2s=";

/* 
 * Resource generated for file:
 *    time.png (zlib, base64) (image file)
 */
static const unsigned int  image_time_width          = 16;
static const unsigned int  image_time_height         = 16;
static const unsigned int  image_time_pixel_size     = 4;
static const unsigned long image_time_length         = 908;
static const unsigned long image_time_decoded_length = 1024;

static const unsigned char image_time[] = 
  "eNqtk91PknEUx/uT6qJaW1fddGW5tKVuudnabKUXKgqClFiYmSWYKEGKCqbg+3QiFr4gki"
  "iKgG8g8AiYbyA+gIA+pt8e2mheOK8823f77nf2OWe/s3MAXMMVaryz+p6h67V2fpC1vzjC"
  "oeaH2JReWbCjaSro7//KvnMZq1NVNlhHWcc++wz2tl0IhYIgyQA2N6yw6jsx8i33UFmbx7"
  "2InejkC52mRgT9Htg9QXSPEWjoWUadaglytRMLjh0QdgOGpS8g4z8vPs9q5FV3TYMMKrBL"
  "QGfeQu84AacvhEAoAn/oEHZvCPJRJ/om3Vgzq6F4mxGVVr68keR/tjKH1+n31Y19qLRuJC"
  "JIknD83kac9glFzgDxkBN6iwc/FEUQl2XKk/xYW/72lscGhWYdK3Tf6MkZItEoRM0y7NJ1"
  "wkdH6NGMQecg8bHDAtusElJOGpHkta158WBgE9XtFuzGKASPTnFMJ0rLeVD0DoD5hodRgx"
  "E2kkKhyAgvYUQzJz2W5EckufHAngs8mRneCEXXOIWPDONdzad/rM5shf8EMAUo5At+weOa"
  "RFNp2n++53O222VTQ6CyYHKdxBb9YV+YwvDENNz7Iez8AYgo0Ld0AI7UiEVdHUTFqd4k38"
  "LPlk0oWTBYHKhS2eGnZxWkgPApLdof0Lyf9my5HRrDHAbqMyBgpKuSfNP7V9fbKp7E1kxt"
  "aFfP44NqDWbiABF6FpEoBQvt+R2rEHdPYUFbgfqClLiQ8+zm+R2Q8HJY36seY2WmAeOzJl"
  "TKZlBSN40igR7lEj00+inMa7kQM++jlplVftEOisqeciWs1MhAYxbdhw/3igLu5RbMaTjo"
  "qnmI+sKUw9qSzIrLbkDEzbklLE7r+FL4wNPISIkllPACxiOlkJ19G1d8r38B3koL5g==";

/* 
 * Resource generated for file:
 *    transport_beginning.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_beginning_width          = 16;
static const unsigned int  image_transport_beginning_height         = 16;
static const unsigned int  image_transport_beginning_pixel_size     = 4;
static const unsigned long image_transport_beginning_length         = 188;
static const unsigned long image_transport_beginning_decoded_length = 1024;

static const unsigned char image_transport_beginning[] = 
  "eNrN00ENgDAMBdBZmAUsYAELWJiFWcBCPaFlFkq30KQpLesNlpTDz94nwEDEhB8PrX7Z0n"
  "MVJ19p6sQXJ++2TTxbnbPFFy+tzKX1vLaca2v5w7B4dzYj136nOZ37Q8D3fdno4OeHgE9G"
  "h3z/EPC6Q39/CHjZYZ0/UL7SLMa+7OTjPOAP/r0LX11aGw==";

/* 
 * Resource generated for file:
 *    transport_end.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_end_width          = 16;
static const unsigned int  image_transport_end_height         = 16;
static const unsigned int  image_transport_end_pixel_size     = 4;
static const unsigned long image_transport_end_length         = 184;
static const unsigned long image_transport_end_decoded_length = 1024;

static const unsigned char image_transport_end[] = 
  "eNrNk1sNgDAMRWcBC1jAAhawMAuzgIV6QgsWykbSpCn3bvxBk/vT7Jy9VTXpx6lVapb0rL"
  "Umk74G/gSOexxwIF6Bw/joYHx0eN47erx3RN4cI94cGfRb9he8kPmPmm3AC9l/Y6fB+oWc"
  "v7G98xNy/55lvJB3FlnEo7fbagas9Yv+4O9dh3laGw==";

/* 
 * Resource generated for file:
 *    transport_fast_forward.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_fast_forward_width          = 16;
static const unsigned int  image_transport_fast_forward_height         = 16;
static const unsigned int  image_transport_fast_forward_pixel_size     = 4;
static const unsigned long image_transport_fast_forward_length         = 168;
static const unsigned long image_transport_fast_forward_decoded_length = 1024;

static const unsigned char image_transport_fast_forward[] = 
  "eNrNk9ENwCAIBV2hs7gTs3SFzsIKztIVXkmjhhIofkrCz0vuoogACjZoqav4dUofNnR4BA"
  "6WbtYR8J6De/5x/PDWwSqfjoTXDjb561jg0WfHTt4W+Fu6Bjwl/GC981Nyf81anpL5W1bz"
  "lLy/xw6eFvavBvvr5tjk3z2gxJNI";

/* 
 * Resource generated for file:
 *    transport_fast_forward_to_key.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_fast_forward_to_key_width          = 16;
static const unsigned int  image_transport_fast_forward_to_key_height         = 16;
static const unsigned int  image_transport_fast_forward_to_key_pixel_size     = 4;
static const unsigned long image_transport_fast_forward_to_key_length         = 204;
static const unsigned long image_transport_fast_forward_to_key_decoded_length = 1024;

static const unsigned char image_transport_fast_forward_to_key[] = 
  "eNrFk9ENgCAMRF3BFVyBFZiFFVjBFZylKzCLK9RqijmbIho/JLmEXvIuhQIzD/yzZC2Dv2"
  "bRaE2H50YGiYrNaPBeBql/ybjhbQaBf2Z0eMwg4x8ZD3jWuyPHLw/4VRQafOrwlfX6T53z"
  "I2v5nZ1EERSAtyzySets+iHlPbbyCeoMDO5D4/1aP+sMo86YXv4Tt/8v2gD0ZHI2";

/* 
 * Resource generated for file:
 *    transport_loop.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_loop_width          = 16;
static const unsigned int  image_transport_loop_height         = 16;
static const unsigned int  image_transport_loop_pixel_size     = 4;
static const unsigned long image_transport_loop_length         = 212;
static const unsigned long image_transport_loop_decoded_length = 1024;

static const unsigned char image_transport_loop[] = 
  "eNrNk1ENwCAMRLGAhVnAAhZmYRZqYRawMAtYwMIszEJHk9tCSMuWfe2S+6H3CLTAzI5/4K"
  "pQTY2jG0jhRUlKMH3g5wd+QUbjffUBLhk8IeMVXmp7kw3G0SVDCp+rV/csyWSDpxc8Gbzc"
  "eXvBSyYp/NX7acBOyMzG/OQOBbPo5VHLg/lfmQN9ivCKtXtvg297VJq3VPre8k/+3QkrPX"
  "VE";

/* 
 * Resource generated for file:
 *    transport_pause.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_pause_width          = 16;
static const unsigned int  image_transport_pause_height         = 16;
static const unsigned int  image_transport_pause_pixel_size     = 4;
static const unsigned long image_transport_pause_length         = 80;
static const unsigned long image_transport_pause_decoded_length = 1024;

static const unsigned char image_transport_pause[] = 
  "eNr7//8/w/9BhIFAEIhdoBgGjKF8JSL0g9T9h2IY2A3ll4/qH9VPY/1KIHVQDANpUL7L/0"
  "GW3wCFUQ4g";

/* 
 * Resource generated for file:
 *    transport_play.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_play_width          = 16;
static const unsigned int  image_transport_play_height         = 16;
static const unsigned int  image_transport_play_pixel_size     = 4;
static const unsigned long image_transport_play_length         = 108;
static const unsigned long image_transport_play_decoded_length = 1024;

static const unsigned char image_transport_play[] = 
  "eNr7//8/w/9BhoFACYgFGbAAIvW7APEZbGaQoP8/NjNI1I9hBhn6UcwgUz/cDAr0g3AoBf"
  "rTKHB/GgXhl0ZB/KVRkH7SyE2/9MQARXskxQ==";

/* 
 * Resource generated for file:
 *    transport_play_backward.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_play_backward_width          = 16;
static const unsigned int  image_transport_play_backward_height         = 16;
static const unsigned int  image_transport_play_backward_pixel_size     = 4;
static const unsigned long image_transport_play_backward_length         = 120;
static const unsigned long image_transport_play_backward_decoded_length = 1024;

static const unsigned char image_transport_play_backward[] = 
  "eNrN0bEJAEEIRFF7slpbsAVrsQVbmI0W5G4TZzm4YML3EQQg+PmqCpkJ1qoqIgKsFZGx73"
  "bqn3biT3bi3f1lp/eb2ZU/NZj/9Qbje4P1u3Hjv9wCUhnK6w==";

/* 
 * Resource generated for file:
 *    transport_play_to_key.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_play_to_key_width          = 16;
static const unsigned int  image_transport_play_to_key_height         = 16;
static const unsigned int  image_transport_play_to_key_pixel_size     = 4;
static const unsigned long image_transport_play_to_key_length         = 152;
static const unsigned long image_transport_play_to_key_decoded_length = 1024;

static const unsigned char image_transport_play_to_key[] = 
  "eNr7//8/w/9BhIFACYgFGbAAIvW7APEZbGaQoP8/NjNI1I9hBhn6UcwgUz/cDAr0g3AoBf"
  "rTKHB/GjT4lKByMGxMhP40pOgrRzN3NwH9aWjJpxymB5mNQ38aluRbDo0HkPxMXPrxhAtR"
  "7icVAwABaPew";

/* 
 * Resource generated for file:
 *    transport_rewind.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_rewind_width          = 16;
static const unsigned int  image_transport_rewind_height         = 16;
static const unsigned int  image_transport_rewind_pixel_size     = 4;
static const unsigned long image_transport_rewind_length         = 172;
static const unsigned long image_transport_rewind_decoded_length = 1024;

static const unsigned char image_transport_rewind[] = 
  "eNrN09ENgCAMBFBWcBZ36iys0FlcwVlcoVZjTa1X4BOS+7nwGgMoIkUmCFiLpha8uOMvu2"
  "s2ZDXS8GYFeH76zHsbPbse+Wi959AjH635CnrkKfGr5hjwaIZ9/29G4/wpOb/PjM79U3J/"
  "74yB90fJ+7lnDHjbC3uZ5L87AbKWk0g=";

/* 
 * Resource generated for file:
 *    transport_rewind_to_key.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_rewind_to_key_width          = 16;
static const unsigned int  image_transport_rewind_to_key_height         = 16;
static const unsigned int  image_transport_rewind_to_key_pixel_size     = 4;
static const unsigned long image_transport_rewind_to_key_length         = 196;
static const unsigned long image_transport_rewind_to_key_decoded_length = 1024;

static const unsigned char image_transport_rewind_to_key[] = 
  "eNrN010NgDAMBGAsYAELs4CWWcACFqoFC2jBQilkI0e5Ak+EJpeQhq9r+FHVRn8SUq1lbH"
  "jJg9/sbJmYteiNr1aJl9KPPFrvBfrMe4teXJ95b6sfSZ/5HPhkWV54NqPuf5lRTGfpIcnN"
  "wOd3mlH8EJyXg/d3zAA/4TXcm4PvZ58BZi67S3AeqxTt/+U/twKGyXI2";

/* 
 * Resource generated for file:
 *    transport_stop.png (zlib, base64) (image file)
 */
static const unsigned int  image_transport_stop_width          = 16;
static const unsigned int  image_transport_stop_height         = 16;
static const unsigned int  image_transport_stop_pixel_size     = 4;
static const unsigned long image_transport_stop_length         = 64;
static const unsigned long image_transport_stop_decoded_length = 1024;

static const unsigned char image_transport_stop[] = 
  "eNr7//8/w/9hgoFACYhdCGAlPPrLgfg/AVw+qn/Y6k8D4t0EcNr/YZRnAMXDIoM=";

/* 
 * Resource generated for file:
 *    trashcan.png (zlib, base64) (image file)
 */
static const unsigned int  image_trashcan_width          = 9;
static const unsigned int  image_trashcan_height         = 10;
static const unsigned int  image_trashcan_pixel_size     = 4;
static const unsigned long image_trashcan_length         = 52;
static const unsigned long image_trashcan_decoded_length = 360;

static const unsigned char image_trashcan[] = 
  "eNr7//8/w38oBoL/MPwfhzg+jA+QYAYDzCwcNMNgVYPPTwBvR79B";

/* 
 * Resource generated for file:
 *    tree_close.png (zlib, base64) (image file)
 */
static const unsigned int  image_tree_close_width          = 16;
static const unsigned int  image_tree_close_height         = 16;
static const unsigned int  image_tree_close_pixel_size     = 4;
static const unsigned long image_tree_close_length         = 84;
static const unsigned long image_tree_close_decoded_length = 1024;

static const unsigned char image_tree_close[] = 
  "eNr7//8/g7u7+39cGAgYCGGoOgxAjn4GBgay9YP0wjBMP8wMXDQ17afE/5SEPxa3MNATj6"
  "afoZt+AD+9zuo=";

/* 
 * Resource generated for file:
 *    tree_open.png (zlib, base64) (image file)
 */
static const unsigned int  image_tree_open_width          = 16;
static const unsigned int  image_tree_open_height         = 16;
static const unsigned int  image_tree_open_pixel_size     = 4;
static const unsigned long image_tree_open_length         = 80;
static const unsigned long image_tree_open_decoded_length = 1024;

static const unsigned char image_tree_open[] = 
  "eNr7//8/g7u7+39cGAgYCGGoOgxAb/0MDAxwDNMPMwMXTW/34xKjJPwJmU+KPKV41P6hZT"
  "8Asfff0A==";

/* 
 * Resource generated for file:
 *    warning.png (zlib, base64) (image file)
 */
static const unsigned int  image_warning_width          = 32;
static const unsigned int  image_warning_height         = 32;
static const unsigned int  image_warning_pixel_size     = 4;
static const unsigned long image_warning_length         = 628;
static const unsigned long image_warning_decoded_length = 4096;

static const unsigned char image_warning[] = 
  "eNrNl79Lw0AUgP0Durh3sMGCg5uDLkIhglNLFxGdiiBOioviUpGCcZGioYI42sHJpVQQhB"
  "pwEQp16KRTOoUObg7dnnchF0J+vncJ2oNvadL35S55794BwAwg2D56LDJqjBbDYIwYE4eR"
  "81vLuacIyLgIb4mhM0wGIDGd/5RSeBWGxrAIXj+WE0MhulVGN4XXD4+lIt0VRj9Dt4DHrC"
  "DmHes+vHiGh6dhKPwa4hnUmPeduOba3RtEDX4N+S6UEL+GWcc4//7xJays7UB17zYpjhaS"
  "Y1Zaf7VchtlcDta3Gpi8KHn8OvY7ysjP0T11zfwHv+mpqeg84t941Cjk8xQ/eOo5KZejBn"
  "cT/WIvIfnH3z8B98dg4Po3Du6xscQ+RvIPv8YBv9HruX5CLLGHkvyd18+A/6rZtN1zhUVK"
  "rImMn9da/zir123//MIy1U9e/+v2e2TuLa1uUtef/P2F1QDh5/WXEMuQyb/d004WuQeefg"
  "1k1uDkvG3PW8xdwl+j1l/h5jRuXly/eAZij1ik7j9x9Y84d11m/03yI5/B8vfG2P4DU/8R"
  "MTTZ/isDfzeqH8f0nyn9/aQ+nNJ/C58f2f6bev4g+NHnj2k4f03D+fOvzt+/1KxzrQ==";

/* 
 * Resource generated for file:
 *    warning_mini.png (zlib, base64) (image file)
 */
static const unsigned int  image_warning_mini_width          = 16;
static const unsigned int  image_warning_mini_height         = 16;
static const unsigned int  image_warning_mini_pixel_size     = 4;
static const unsigned long image_warning_mini_length         = 148;
static const unsigned long image_warning_mini_decoded_length = 1024;

static const unsigned char image_warning_mini[] = 
  "eNqlkUEOACEIA3k6P++GGCMhFME99KAwUikAQSJVwRZIDwrWX4nM3sh4VcULO/Xg+cX0PU"
  "R2q+uhwzMP2c4iX3mIvJ3XvHsW9c7vWTCeyXtgrNVPH/fwh7fa1Dv7g8+rozX75LDPExn3"
  "AZ/Fj8c=";

/* 
 * Resource generated for file:
 *    window_level.png (zlib, base64) (image file)
 */
static const unsigned int  image_window_level_width          = 16;
static const unsigned int  image_window_level_height         = 16;
static const unsigned int  image_window_level_pixel_size     = 4;
static const unsigned long image_window_level_length         = 172;
static const unsigned long image_window_level_decoded_length = 1024;

static const unsigned char image_window_level[] = 
  "eNrl0cENhCAQQFFLwCakDxqRTrANTlSCdWATSwlfcT0YJcZZ9ybJv/GSmQzQcLPlsY8Htu"
  "S9R2LL/2MSK5n3LfbJXWr+l5mlN/1ntf3vVvOqVWitMcZgbY8bHCEEYhxJUyJ/Mhtcdz15"
  "1aK7r++txblh85GUFp+vvaTiZ84zZrU=";

