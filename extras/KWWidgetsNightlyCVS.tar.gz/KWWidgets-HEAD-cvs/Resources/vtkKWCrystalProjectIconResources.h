/* 
 * Resource generated for file:
 *    14_layer_deletelayer.png (zlib, base64) (image file)
 */
static const unsigned int  image_CrystalProject_16x16_actions_14_layer_deletelayer_width          = 16;
static const unsigned int  image_CrystalProject_16x16_actions_14_layer_deletelayer_height         = 16;
static const unsigned int  image_CrystalProject_16x16_actions_14_layer_deletelayer_pixel_size     = 4;
static const unsigned long image_CrystalProject_16x16_actions_14_layer_deletelayer_length         = 348;
static const unsigned long image_CrystalProject_16x16_actions_14_layer_deletelayer_decoded_length = 1024;

static const unsigned char image_CrystalProject_16x16_actions_14_layer_deletelayer[] = 
  "eNq1U7mOhDAU2//i+DTCLwA9BRQUUNFz9hTQc5TQ0kDnHUcKYrTDHNrdwoqS4Gf7vQDgC/"
  "8AwzCg6/odnn1v27awLAtCCInb/oA6O9/d6okzn9ymaTBNE9Z1lSv3ZVmirmtUVYU0TRFF"
  "EXzf/+GHdR95JkzTvFuv8rBG27bY9x3zPKPve6mdJAnCMITrulA6j3rAu67rsG2b5A/DIH"
  "0rvuM4b/GVPvlFUUh+EASSzz5dzeLsf1kWjOOIPM8Pfc/zpP67fObPsuxXfOVf8Tn7q/zM"
  "duYzP/3HcXzkf9U/8tl/pf9Jfno7z5/6Kj/1X82fYG1N0443pt4kV4W//E+/AbNc16Q=";

/* 
 * Resource generated for file:
 *    14_layer_novisible.png (zlib, base64) (image file)
 */
static const unsigned int  image_CrystalProject_16x16_actions_14_layer_novisible_width          = 16;
static const unsigned int  image_CrystalProject_16x16_actions_14_layer_novisible_height         = 16;
static const unsigned int  image_CrystalProject_16x16_actions_14_layer_novisible_pixel_size     = 4;
static const unsigned long image_CrystalProject_16x16_actions_14_layer_novisible_length         = 704;
static const unsigned long image_CrystalProject_16x16_actions_14_layer_novisible_decoded_length = 1024;

static const unsigned char image_CrystalProject_16x16_actions_14_layer_novisible[] = 
  "eNqNU8+rElEU7j9wH4SbaBWIif1AZDB5goq/CuG9RQkVgkiMUJvc3FYtCoJeT6HHe0kQuB"
  "GsRZtBcuFgiyK3RZqgD8uf4wyJAw/9une6wTC8V2/gY7j3O993DuecC+AUONLptJ1CpCAc"
  "Dpj4f4HGpigUClhQZ77/0cYs8X/z1/kd840do7VxvnRUHs4THpM6gi+Z75PJpEBBOARLb1"
  "pWD3oWuM6RSCS6Pp8PbrcbTqcTHo8HkUikS7mUqZa6ta+Uj4XDYZw778LNB0WUP/zA6Xuf"
  "cObGPuxXrhl+8Xi8TuNs3KPK/lxrD4VCCs2Dh297kL4egn1be11c3ddx9vEczvuS4REMBl"
  "smD8L1JBAIYDweY7cxx8F8hfrHLyCE4Lr4BBuvVrjwdIrP336C1WjycLCZML0kSdB1HcWG"
  "gtjrFTazBIIgwOVy4fabFS5uq5C/L9Hr9awerNe2fD7fmk6n6IyW8OxouPPsvaENxDaRqq"
  "5xaVvDUFlgNpuh3W7D7/ezflRN/TM8JpMJHklzbJUPkSkf4O67NYSXa9wqK1BVFYwfDAao"
  "1Wrwer2gOtE8h0wmQ2RZRlH+hY0XGi4/15CpaBirupF7OByi3++j0+kgm80iGo0S6z6xeR"
  "QKhVKj0VCWyyUWiz91j0Yjo/ZKpYJcLlcy79ZxUBRFoFqx2WzScRCR76btpG/yJPgNnaKA"
  "LQ==";

/* 
 * Resource generated for file:
 *    14_layer_visible.png (zlib, base64) (image file)
 */
static const unsigned int  image_CrystalProject_16x16_actions_14_layer_visible_width          = 16;
static const unsigned int  image_CrystalProject_16x16_actions_14_layer_visible_height         = 16;
static const unsigned int  image_CrystalProject_16x16_actions_14_layer_visible_pixel_size     = 4;
static const unsigned long image_CrystalProject_16x16_actions_14_layer_visible_length         = 640;
static const unsigned long image_CrystalProject_16x16_actions_14_layer_visible_decoded_length = 1024;

static const unsigned char image_CrystalProject_16x16_actions_14_layer_visible[] = 
  "eNqNU7uKKkEQvX/gJ+wPCCJiJDKIIKj4QozNBDFQjETE/gYDQxE1MRAWBRF84BMDHwwYq4"
  "sKgs9BQTQ72z30XoZh994dOAzTp86pmqpqAH/AEQqF3iiiFIRDBwX/L9DYIIVEARW6zPc/"
  "Wo8q/it/l58xX88PWg3n89/l4TzhMcFv+LzyPBAICBSEQ1D1RlR70G+B63Q+n+/DYrHAaD"
  "RCr9fDZDLB5XJ9UC6oqKWr7ivlPU6nE1qtFqlUCovFAplMBvF4HF9+Xq+3S+M03OOdvbn2"
  "zeFwSDQPms0m1us12FOr1dBqtVCpVJBOp2UPu90uKjwI1xObzYbT6YR+v4/H4wFRFEEIQS"
  "KRQK/XQy6Xw2azAatR4aFjM2F6lvf1emE2m8k1sLoFQYDBYMB0OkWhUJD9t9ut2oP1WpNM"
  "JsXL5QIGFsvAtH6/H5PJBMViEff7HdfrFcvlElarlfXjXdE/2eN8PmMwGKDRaKDdbsv/0e"
  "l0UK1WcbvdwPj9fi9zZrMZVBdVziEcDpPRaIT5fI5yuYxSqYR6vS73hOU+HA7Y7XZYrVaI"
  "RCJwu91EvU9sHtlsNj8cDqXn8/lXezwe5drZPGKxWF65Wz9BkiSBaqPj8ZiOg0T5bmp+ey"
  "d/g0/VfIbf";

/* 
 * Resource generated for file:
 *    jabber_online.png (zlib, base64) (image file)
 */
static const unsigned int  image_CrystalProject_16x16_actions_jabber_online_width          = 16;
static const unsigned int  image_CrystalProject_16x16_actions_jabber_online_height         = 16;
static const unsigned int  image_CrystalProject_16x16_actions_jabber_online_pixel_size     = 4;
static const unsigned long image_CrystalProject_16x16_actions_jabber_online_length         = 824;
static const unsigned long image_CrystalProject_16x16_actions_jabber_online_decoded_length = 1024;

static const unsigned char image_CrystalProject_16x16_actions_jabber_online[] = 
  "eNqN0n1IE2EcB/BzamwWTAqMUcrM3hyuTWcUErUREUmh/mFRC7ugEjEzKArXP4cUBVGSRA"
  "kaK0IoCiQKwYL2h1hEsJOypTBdjumpc7u93d5u89szIbClswe+HAe/z/c5nucAUFiS0FNK"
  "Gxuo6EvYWhAaLAf/TgJ/XxYfeU2ZhVeUEmnzS+PuoGjBchILyRASwneEZ56DsxRgamANpt"
  "7mwvtSgsAzil7Oeh5T+kD/CSyIHBJRO2L8G+I7EbCfgfuLHHND6zD9UQZ3bzZ4M6VP93Nd"
  "CjYZ/YlkzE5ek4j7+yG4LiEwUQN+pBgedsNiz/QHGea7syzpfrZXgai7B4mwFUnyDVFvF0"
  "KT1fDb1fCNFYK3KeAdLsDMJzk4cw7SPfdCCs+3QkTmGIjCe/JsRtBZhuDkVgQcxaSnCL7R"
  "TfBYN8JlXvuPdz3M5b0/FAg6diI8WwuBU0OYUZGUIjS1g3SRnvHt8NkqMX5Hxqf7X+0U7e"
  "rOI3Mliy7i2YUor0XES+LZj4i7DmHOCGfPNoxdWf4ORq9JLk8+kSMyr0Y8VIdE7DrJLYjh"
  "dnIeJow/UvHseQmd6R+wtubQI3dTHeUQ4wYkE/eJfQBbR6Vj8Gy2NpNNRVZC59cfOmy5ba"
  "pCa7MW9ad1OF6zB2r1AWY1m0rZwTY9O+JENBbH0GcrGltM2L3vGPKKai3/46tqb+q/Dk9A"
  "FEWwLAuGYWAwGCDbfCSj/7O2VF1VVjfcc1xovAij0QidTge5ogJZhXTH0rmVfGpJS84xbU"
  "wnmpqaoNFoIF1f+vfAKp7spcxXNbJHT91A6d6G1N7mlfxvhAaTqA==";

/* 
 * Resource generated for file:
 *    rotate.png (zlib, base64) (image file)
 */
static const unsigned int  image_CrystalProject_16x16_actions_rotate_width          = 16;
static const unsigned int  image_CrystalProject_16x16_actions_rotate_height         = 16;
static const unsigned int  image_CrystalProject_16x16_actions_rotate_pixel_size     = 4;
static const unsigned long image_CrystalProject_16x16_actions_rotate_length         = 1004;
static const unsigned long image_CrystalProject_16x16_actions_rotate_decoded_length = 1024;

static const unsigned char image_CrystalProject_16x16_actions_rotate[] = 
  "eNpdU11Ik2EU/izCzKDILroJw9CLIAiMAoWwCKJuuiizqK6ii6AboW3SnDq3b27+bG4O5z"
  "aULdyPLgciEmxC+XNRuU3EwjFturnpsItMvYisTs/5mBBdHL7zvu95nvOcn08URcFoNAqd"
  "nZ1CQ0ODYDabBVEUg7jbwd221WqVrK+vb1utVu/gLQW/2mQyFXR3d3OsAF/o6Og4X19fX8"
  "E+cL6ZmRlaX1+nTCYjfdPpNLlcLlIoFDa8lwF7jPE6nU7Q6/UXurq6tsCVxLnCbrff6e/v"
  "311eXqZsNkubm5u0tLREuCfkeQ1tNbDj+fyFsFA4HCY2cE2ghjJojc7Pz1Mul6NEIkHsx2"
  "IxMhgM39va2upYJ+MRV8O61tbWaHR0lID9CKsEj318fPxXKpUit9tNFotFqmFkZISQz93T"
  "01PCHA6HI8C1zs7OEri+aLVaBbCXYZdw/jo1NUWtra3ZxsbGN2NjY8Q1eTyeXWCvM97n8y"
  "Xi8ThNT0+TXC5/B+461HgRGopRY0wmk+2Bx6BSqSxDQ0O0sbFBg4ODrOEJ9B+Cn+D6WINS"
  "qXyLvNybk3grwPcp+jmh0WgeIl4/PDwszYPrAacMPT8B/300GpXwmH8Uuau5L2zQV4JZ3W"
  "xvb69CDcpAICD1wOv1/gTvS8SeBu9zv99PyWSSef8g1gTtBXk871Yh/EdOpzPHM5icnCRw"
  "foLOZ8CX4r0c+/VtYWGBIpEI9fb2EuajguZreK9B3APMPYdZ0OrqKu/AXlNTkx0xt6D/FL"
  "BFNputGTy0uLhIPC/uD9cYDAYlf25uTrofGBjg3B/A+wJ7cAW6ivMaz+D+FXT/CIVCtLKy"
  "IvWJd4+/3BvkIOSLAKtGzXeBOQv8gXydB7EP56BJRA/DyLPFs+J+o2e/keszZuMCVoG6Hv"
  "N8gTm832f+53A+Ag3l4K7FDulbWlqcqNOBsxW8zTxv2H1gK5H76D72PyvCWylmUAnMDcyo"
  "Fph7+N7G3VXW/G9etr/IwGJM";

/* 
 * Resource generated for file:
 *    cookie.png (zlib, base64) (image file)
 */
static const unsigned int  image_CrystalProject_16x16_apps_cookie_width          = 16;
static const unsigned int  image_CrystalProject_16x16_apps_cookie_height         = 16;
static const unsigned int  image_CrystalProject_16x16_apps_cookie_pixel_size     = 4;
static const unsigned long image_CrystalProject_16x16_apps_cookie_length         = 1144;
static const unsigned long image_CrystalProject_16x16_apps_cookie_decoded_length = 1024;

static const unsigned char image_CrystalProject_16x16_apps_cookie[] = 
  "eNqFk21MFHQcx1ub+EIhwtESlGF0eOQovEGBHsgdBwLj4Xg6ELg7K/AOedOwOeOZ4VIUWg"
  "PCB06TqSfKjOMhM0oESpyBQFBQViKmdW2hhIQo3n364yvm2Hrxe/X/fX4P3+//BzzHoshP"
  "3ag+YgjKNYRJgjv3R5nMOyKvV+uD6pLknv48k/tsNOWH1XHZCNdy4VIW9nYtIxVRTDemQm"
  "f2/MUy1WFf95UuS7ENefLC0cp429WyaOzdBuY+385cux56dsDX7/CgMRlbWybjx9RDwdJV"
  "XovZklTfHHoMPGzT8+B8Oo/bM7FdysbeZWCsOpne8niefJUl3nU8aU7ll0MxP2xwc3RdYL"
  "1dV7jePZFgpdso+mn5oyGNb0qTmPsyC9uVXK4WKmnWy7hvTmSmScOtoym0ZYdy2igzL/CG"
  "LR66+TatYHU8asng15o4zqQHcK9JC725zIod7p1U83OJjKkzSfx9NpMvcgL583C0PXy9s3"
  "+52ufg7WNaps+mMNWUweTJBGYt6fzbqmO+411mRc3+D+O4UqDi8QWhh9iJnhzmWzMpifYs"
  "LA5/td7ydpDokYjVFMNfx+OYFdpNndPwsCWTydNJDO2Lpq9MxSPB27uyn2pyrUiFSbf+1C"
  "dp3o1TYr775mTGygOZ/iyd28c1dOSFCS00zIgav5vU3KhUMGlOAeHNjEXLRG0kdWmSxiLl"
  "6iPW+hhu1UUxKviZFi0D5UpqQl9hqEyO9dN4JoX/gwUyfqqQc+fENsbrNdw9tJWiiLUHVZ"
  "4rk7/b7cdv1RFMHI3lxkdKblaruGOKZbw2gut7/LA2JDBYHEDfrtdoNYZQq5LS/8FG4ja4"
  "JDgte355gXxVx4DIa8lR0J33JjdrVE9rDZUG0p8vE/PH0V8qZ2TfFoYPhPPte69THev+/W"
  "onB6cFD72cHSQfR748YVK4cVnwIweU/FgVwUBhAGNVoQxXRWLWh9C9J0TsEMzFnT62TWtX"
  "KBb/QanLcllFpNtYl1FCn9hneO9m4VsMo5URDO4N4ZRaQqfBG0uW1Kbzf6loqRtY47jMQ/"
  "/Gi6b6xDX/WPQS9m/ywrLdh97dvlzY6cP7Svfmtzyctv7fHXo6O/gEr3PKUHg45sZKXXZt"
  "83Mt3rzuhdilcv8DDMJ7jA==";

/* 
 * Resource generated for file:
 *    tutorials.png (zlib, base64) (image file)
 */
static const unsigned int  image_CrystalProject_16x16_apps_tutorials_width          = 16;
static const unsigned int  image_CrystalProject_16x16_apps_tutorials_height         = 16;
static const unsigned int  image_CrystalProject_16x16_apps_tutorials_pixel_size     = 4;
static const unsigned long image_CrystalProject_16x16_apps_tutorials_length         = 876;
static const unsigned long image_CrystalProject_16x16_apps_tutorials_decoded_length = 1024;

static const unsigned char image_CrystalProject_16x16_apps_tutorials[] = 
  "eNqlk1tI02EYh4cYdFGZIHaiRVFRUa0LI63EspuILiQIi6TywiDMdNbcXJs7/nd0bittdl"
  "LQ1Jo4nUt33n9uTqfLYRbWjWmgF0o5iS6Sil+f5oIgyPCF5+b7nh8v38v7AWBgBSy3puim"
  "lE8DlozpcFvhbiZz+7/8adq8ZmawMysWecGei9gaZgesQ5M9zXOxcCvOHE/Li3sikSjhy6"
  "h902y0O2tu2FH0eai7fqavPTLma4pFnY/h7jSipV0DUzsFZacUw6FHEOSf08bz5nuS+tgr"
  "+/cRuhG03YTnHVrozRIorFJQDpLxqVEZ0kHfr4d2QA9v2IQm8XVXPK+8edkY6atDRbfkl9"
  "tL3LAeRoKhvwpVfZXQhbTkXANlSI1mch+s5U+Q6NqF/Pnso3njLxtR1a/7w9UG1dAEVVAF"
  "FAQKih45ZD0yGPxyvH4m/bYjNfnAQn7fts2HxlymH8ZeNZRBBZRLLkVcuV8KmV8CKS2GhF"
  "DhqyAIMWKT43TangtLT0iKPqWm6gJqiPzi367YJ4LIS3yvEEKvAFw3Dw8DWrx9Y8d7fzWK"
  "c45R8RlYqBu0xa8CzydYdAWeO+B7ysF3l4Pn4uK28xaKnCWoaeNhrOsB5kdpWA2cUDLpvZ"
  "CX5581BDxKlHq44LrKwHFywHaUosjBRomLA3VvJZrJjJRdfLQ8KcakWYyvQxZkH2Et7kFu"
  "Jutq1CZBoZONYtKL7+aihpbC5pUj6tTgQ4cO7xp4cKnyP0rzTvlz0ndVp+/cUMZY6r9/68"
  "a08VYhBl0URqwyBO+XzLfyL03IL57w5mbsvctiphSsX52YSdQthMS/rGsSLzfLfOXkwVoW"
  "M/UaEQ6Ts1RCAmP5tY6wivGfhRX+359XWO59";

