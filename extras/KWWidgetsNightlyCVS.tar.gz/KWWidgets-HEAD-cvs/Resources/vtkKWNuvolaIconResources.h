/* 
 * Resource generated for file:
 *    colorpicker.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_colorpicker_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_colorpicker_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_colorpicker_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_colorpicker_length         = 828;
static const unsigned long image_Nuvola_16x16_actions_colorpicker_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_colorpicker[] = 
  "eNqNk21IU2EUxzfnlI2W5pbLl7WZbu4dnCFOq4U4k0waVG5hZX2YGRIJYVZmLZy9QFAj0j"
  "DBwqQgooZkRVDM7GUKhQU1evGDpJASUkuNHPw7T6yg2FYXflzu85zfPeeeex4AnP+5hPaM"
  "MlWzIWDxrApKnYqbfP3CLFrmI4Yv2iyziKozawW2tEqtW/fp1HAjfB+uosW3EymO9H4KyY"
  "zmC6rSl2vc+TMlXVakuZQo6DaixmuC81Yx9twvg/6gdpbCiqP65eJ18lY9ynvWIsuVh5Q2"
  "FUxdOVhxUYGSa3os2Sgbp7DKGPXzEwoV3mWePBR2FCGtSYNkVy5yzhugaFAGOfHc0xRjje"
  "rLDvGtu4fu9Az2Qne2AGqPBtID2cg4oYOodPEIRTgIfTRfs/1d55dZYGoGONLng/HceuS0"
  "65DtyYXCpQpxhbxaliWSL6l4uf/9xDdMzgHXA4DLB2hLGz4mVaROyNxGCAqSWf6qSP1PXP"
  "ncPjASRDAE3HhN7hPAvKH3M4fDO0zbWzl8bjPdt7Des1R/+Ca/ufv21Ow8LfZR3lY/sKb+"
  "0Xd66xnatbHvJeQEm51UIuG3bxiSt1wYG6dn9L8F2sjd5B4FjyfuCddqIBYQPCKeiGPaT1"
  "/9eJG9JTDM3HujwDFyt3VMQyBQsRmrJvKJJIL7d6+Yb6l78eDrXAgPx4Dj9L3OK/MQS1b7"
  "abuGMBPiX/ki+bb6p89eTQMnqYJdXmCpascb2qojLIQ0XDMnmm9xDAxdujuJfZenoC06Ok"
  "HLe9lssf/D5jDWuWS+0tg0KBCqO3lxknYqs5GWy8I9TvzXuf4BvSgo8w==";

/* 
 * Resource generated for file:
 *    configure.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_configure_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_configure_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_configure_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_configure_length         = 952;
static const unsigned long image_Nuvola_16x16_actions_configure_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_configure[] = 
  "eNqVkl1Ik1EYx89sqLNwU5k2dTMhTYW1dB+mG9MZtOXHzLWpaZBpGswLh0QfoIKChF14ER"
  "gZQtBlXUzEmEiFhlGihpCKynQmus/Xd26ubWbwdN7RhQM1euDPOZyX33P+z/+8KtU1pFJd"
  "RWr19QcGwyNbT09foL39MVFWVvFCJpOmFhfLkUJRdKyUShVer6Cqquohk+kzrK25YWZmHU"
  "ymKWhouLsgkxVyT+Lxvfc1Gt0QvotfXV07Mjw8AbOz67C6aofJyW+Av79RKOSopKToSBkM"
  "D4nx8a+g09UOCwQXeZWVN0ZGRyfAbLaDzbYLnZ29LrFYeEEqLUSHhX2F1o6O3oDZ7IaRkQ"
  "koLS1/l5WV2TY4+BpcLh94PEHo73/uFQj4ColEjHAfJBLlIaEwD+XmXgpJrzeQ09NmmJtb"
  "A6PxAwwMvIKFBQu43Xvg9x9AX98zH4+XquVyUxGHk4Ti41mIyWQiquj0CCSXF700Gt/jeR"
  "04Owc4nT4gyT3w+fzYPwkWixVaW9s2OByONDn5LGKzE3CPeMyeQtHRkSg7O5NbUaH5Pjb2"
  "Bba3PdjzPmYP8J4IiaqdHS80N+tdiYns/ISEuDAez4YyMs6niUSSt3p9u627++luV9eT/a"
  "WlDThcLpcbmpruEdi7MC6OFcbn5OSgtDQeSknhZGB/itjY07fq6+9s2+1kWA+S9OB/osXB"
  "YDAKIiJoYXx6+rmQqD7UjDExDIlWW2e3Wl0h1u8PYv3CuXqhsbHFhuOTRkXRj+STktiIxY"
  "pFDEa0WKerJ7a2XDiDn7C56YRg8CCUbV3dbSIykn75OJ6akck8g2g0JFGrtYTZ7Aj1WF7+"
  "ASsrWxAI/IaampvkSTzlgcqJ8qrR1NosFif2QGDeCouLZpDLFVP/4rFH9LcK8Ds7bDYvzM"
  "+vAp8v+ITPOP/BUyVUKsuJ/HzpR4ql4eH+APdIkl4=";

/* 
 * Resource generated for file:
 *    decrypted.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_decrypted_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_decrypted_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_decrypted_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_decrypted_length         = 1052;
static const unsigned long image_Nuvola_16x16_actions_decrypted_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_decrypted[] = 
  "eNqFkX9MzGEcxx+ZtblimqZFbKWTfq7kqrsk2aVcXd1dv66Ek+6inM2vlT9IEyszbGmVXE"
  "d3O1IpTWoVJqQxnbt8rxQ1LawZ6jbaOt6e2J3GH/547fk8zz6vz+fzPA8AIhTusBEdnTJP"
  "JMpMP3HizFO1umFSo2meKi4+qxcIErJDQ0PteDwesQLqYo4fH7+dZGTsPa7V3kJraw/Kyj"
  "Q/yss13x8+7Ed7ezckkuRztMY/vki8+xdikSytrKx2RqNpQ5pU3pqaKguQSDK9xeIM3b27"
  "z9HY2GaJjNyUzuXO1uDa/MTkPCJKyiFp0lxlTu6xTum2vAr+liRXcYqCRMdLiX9QGEsuVz"
  "7S941Aocjr5HCCSQh3g80vSeeQozIRSUg9SGIScwhfuJsczhSQ89nh5PT2YLIrgUfC+eKT"
  "XfeNKCq+8MpnXZjbPoGfza9JXup8XeHhpcryXX05y8ejOsvfU6fwYjfuYbObcn3YDTleLt"
  "lxvOJrug4UFZ4Zzxd6brkidV1i9ZsPBT5jNJLpfrXQbKwRmI2qrWZDTZyZ0QopcXTPn9RX"
  "x37rr5PBoE37wVyNmb5dEGSw+ga1EJiuBT5VAhOngA8FwHs5Pj3eiI8P1gGvIwF9LPAkCu"
  "ilDIgxoBPA6r+o4lswUQq8LQTeKIHxneirdEeAK8FaZ4LuEgfgERvoWAO0ewDd3jCpN1qs"
  "vr4iwoKx/cCwAhhMAUb5uHNkMVYRguWUuqz5QJcj0LIIaGLROkvAVIf98cvDLRjJoHNJAC"
  "Odb5gD881lkDkRpDgSTFy0o8486lIaqdJuD+bS+jn9qT+aCDCbgf5gYIiNsUIW8u0JDiwg"
  "GFZSv2chcJfSYQ88dgSjCrH5fVWzfgTwMpD296Rv5YqvKge8K2FhvNQB5io6e+9S4JkzXZ"
  "1oDxcwau4cn8ZvV9O7L6d3cANMK4CRlfQdV/1mlDJIzwdX/s4ZcwdTG27583+09wyde9Ib"
  "+OJH8afxX3yx4ktzgzBQH2X7v5Z8f+NQc5TZVB/x2XTjf2z4PNS8aartWODgrPsTOjxkIw"
  "==";

/* 
 * Resource generated for file:
 *    editcopy.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_editcopy_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_editcopy_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_editcopy_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_editcopy_length         = 928;
static const unsigned long image_Nuvola_16x16_actions_editcopy_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_editcopy[] = 
  "eNqVkttLVFEUxrcQPvU3RCBEZZT12ksPPdRjF7tAlnnLMkUrEiIlsCRRmeyGM5pBDymBQe"
  "qkWJPXwJrMUfMy04xzc5yLc8ZzZuboHE+6+s7shyaQoAOLc/be3299a619WOYlxvZeZGxf"
  "7oEjZQZfRbNJvf60X9kqSrR4wt9lz03qoVzdV7Y7h7GdZ1n6/sKK9+Ne+p/nsXEynnawkL"
  "FdOSw960p515hrS93GJpH6i2hNJZLXiaQ1rLGv67ZILKuAscz8tG178oo7PztoA+K/YhMB"
  "7SqAGFgxQRSWscZe47sJafvh0uqdx+70Zhy/O13aZKRnnaOk6xhKRmP7ENW9+kRfZj2kbn"
  "JWgHcojlxYV7V/l67Vv014BZmcoShZ7H4am1sks9WXjPGffnozME332vpJjCdIVDjrjyEX"
  "+rnaapZqXn6I/mtG7nCM6l4PUnAlTkKCs4sS6kAvJeCrDH1Sql7d4DMSUWcMHhZvhGrQQ0"
  "CSKYSmvVC7RKKgwv1Tea1HGXOStBlBKyLP2IJAla0mWhJlCmBubrALK6gDmuIUXvNdXees"
  "ANaPPsOoYdQu0O0WE3nBL6J2B1ibgDqgKWr5wydSfANgPdj1w28Q4lsGEzkjMrmjnJ1bRg"
  "/QFBrMUnUL56MK99VYbT5ajR74fZwX6IbeRHZcukPk7I8gkR25CsCXNfUk+ZU1XrMX+y6w"
  "Vvg4cNI3K1B5s4msyzLZIkTTIaLJAM5xlq83S0UNXUkevwAtRfl8HBHuY0Me4wzn50MyWc"
  "NEU2AtPpxDl6f/JpU8MsY1HjhFMP8g7syHOTix4cE8+xdidLNthFy4GDdqtKGnOTg6cZb/"
  "YiKekV07c7mhV73wsEc5X9utnHnQrWQjTt/Hd61ROVrZoWTm6ZXsxgHlVMOwcrJ+WDmhvX"
  "Uj6o5zTVO/AZIcWcs=";

/* 
 * Resource generated for file:
 *    editcut.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_editcut_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_editcut_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_editcut_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_editcut_length         = 912;
static const unsigned long image_Nuvola_16x16_actions_editcut_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_editcut[] = 
  "eNr7//8/w38KMDbAyMjIICcnx6CtrQ3GampqTI2Njb0zZsy4BxQX0dLSYjA2NgZjEODg5G"
  "QQEREBY24eHgYlJSUGIyMjsF4NDQ2Gjo6OGf/+/fufkZGxAqReV1cXrl9ETIzB0NSUwczM"
  "DIxNgFhNXR2sBmRPfHx8wvfv3/8fO3bsv7CwsCMLCwuDnp4eXL8GUJ0hUA+Mbww0S0BICK"
  "wf6AZBoL5nb9++/V9dXX0OaDULSBzkLh0dHQYDAwMGNaAdIP0GQL36UP1CQH+A5LOzs0tA"
  "es+ePftfVVU1gZubG2Q3u5WVlVZcXFxiQEBAsSpQvwbQHHdjYzcXQ0MfPaAZAkD9WkA3bt"
  "m8+dbz58//L1y48Lubm1tbbW3tivnz598+cODA/127dv3X19cvBYaPeLO9/fY9np7/nwQH"
  "/w9QUakTFhRUKPXzW3fh8uX/p06d+j9z5sz/ID0nTpz4v3///v+9vb3PgO5JAoVlj7v7nk"
  "PBwX84mJiM5+npHbzo4PBjvZ7ep6uTJ/9fsnnz/+lAvdOnT/8/bdq0r1lZWUeAdhYCtUnA"
  "4vpaWtr/A9HRbzg4OLSW29qe/O/u/r9RSOhEV1XV5ednzvyvLii4LyMjE8bGxqaCLa2UmJ"
  "kt/1Fe/v9Bevr/666u/125uTv5eHnt9oSG3t/r6PhWioUlmAEPUNXXZ7MWFs5LlJefK8nB"
  "4SkuIqJzLC3txf/29v8TNTVvycvKyuHTrwWMLxjQUFcX2puY+Px6evq3NgODE2+Dgv5MVV"
  "U9D5Rix6nfxATODjQySv/f1fU/UkpqNQMrK/sKW9sLG1RUPgCleHHp1wGmHRiw1dV1eJKT"
  "8/91dPTfbaamj87r6//XZGPLwud+SRkZRFgA05yrgkLhfBOTW/PV1e8C9eYyEAAANLQkSw"
  "==";

/* 
 * Resource generated for file:
 *    editpaste.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_editpaste_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_editpaste_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_editpaste_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_editpaste_length         = 1060;
static const unsigned long image_Nuvola_16x16_actions_editpaste_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_editpaste[] = 
  "eNp10ltIFFEYB/ABKYpMArtQ2mqZq3YxVESNit7yoTAwKMzM7O6WC5HdXmzVIOkimi6WWW"
  "qFoMZGZpKaEpEl3sad3R13vS9pZE2j2W7r7Nq/bwx3e2ngmzPMnN98/3NmADDYwng51zI+"
  "0/6Mt30V43U0YVfiycqSqZy6fFGtuyTGavfatm1fksQtYbzeLWa8WxYwPq2+jBdkK1fswl"
  "uu+OX1M/G+z39u96nJvLhvpNz+Ai1oQCuaoZ16jPgjoWN9kUtrTNt8n3fHrHzZFrSwcN7P"
  "HlIANTFAwWI0ZK1GXO1uRPXuQOTHWES3xyHGsBMrisLwSLUMs0WL8FsXBz4xCG6fFuiyvw"
  "iH7nYKjt09jfXF4VDkBUORvQmKrHAEZEXA73IkEjIOo1qTDMerrbAkB7vc+dPWSMaqCBTq"
  "ujD0wwneaoB51ALz4CDMA8Mwm0fRZxlG/1cXbpR1gS2PQn+Swjnvncf9JMOzGFTWt0H6jf"
  "8e0ixQWs2C1e2H5aDHO075ScaGfaio78LMrGe+i65nKKWNZk46AFECbj0xgW1Ugz/g8bYz"
  "/pKpKZX66+e8HMFJJwfNsMv2FzD2A7D+BHLKDGBfq8D9k39atVbim1LwpI6d8/N9ZSuSHZ"
  "8ChkXQ3gC5pRz0r9OhTwpw+8kMhcS/ScVT2ZOboSc2yvrN/rfvCFnLN8A8Sf3vk29Uoftw"
  "oNsL6gCJf5+Ox3UGOFx/807YgE9yXzKW74DxK8DRmF3SC675LDpSPH7iPPkP51Bex2Ga7n"
  "4hO05rtZIdoN68AOgnAJYy5JToYWhWof3oOrf/nBkoGdvSUVJrgkj7/JlyW+kdA9SfJ68n"
  "1/EFaKfxaoGB1n8Gbcc93nphgySa1NAWV6O81oCKZyzKqntwr6ob2qfdKKzoxJ2yTtwo7U"
  "Gupgoiq8bbE0q3H7wSSkMehE854PTZMHIaKhp7NTDJ1XMNPJWxMwvCkIY+cB4aT4e5//+O"
  "PT6DIw83iyPajYJVGyIMF4cIA0UhQn+BUjDnKwX+tlIw3gwWuLwNQleuUui8Hio+iPYele"
  "0fsLL0FA==";

/* 
 * Resource generated for file:
 *    encrypted.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_encrypted_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_encrypted_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_encrypted_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_encrypted_length         = 1052;
static const unsigned long image_Nuvola_16x16_actions_encrypted_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_encrypted[] = 
  "eNpt0WtIk1Ecx/FjvbCb2YWirNZFLSJKxLIoU1waZNM1dc6xXLo5HealFy0vabZWlGhlDr"
  "UUS2tOcjatNMtpF7pqhXZxOqdZSZkEo8SkcvnrTNss6MUH/jw833MO5wAgLJbAJiCAT3g8"
  "aWB29rmHV682fquruzdcUKB6JpEk88PDE+0Egn3ECrS1CA6OHMPh7CFCYXyiWl1nLi+vh1"
  "yuNCoU+YaamrvQ6Z4gKUmRERV1gIhEyWOsfRgvZgyXK/bIy7s0rFSqfwVz42QsjnT2Tk7c"
  "zFBekqRCXf+drvNTIklnSqWHiIW1Z4fvJ7vCEkm0JKWguKgawkjZFf6OQLKX7U9tJwIWh8"
  "TGHSm53fQcGRlKVVR0JhFJT9j6VL4fYQXHEWnCsdqsHDXYgrS9sgAPcsaLkNwthKQGbST8"
  "mKxQjfYBcnIr7wtFcqIQsW39xQgnp9yIdasT9sS0ZB48hcMR/imluxkrcpiObhYXdju7HB"
  "WzYy8Ua3FSflqfJ97qqRIuXmzta9PWd/deF6JTK0JHjRhdmpBRY1Uoemp5eFMXAqOGha7y"
  "HaNdV/joqqTfNYFoyPTss/YvS4OAHyrAVAh8kgMDqcBHMfp1m/Dh5lqg2wto3Q48YQLNvk"
  "BHEAwVAbD2bUX+ZgwcB95lAj3xQF8EmpUMuM4gYEwjaFJMBR44Aw2uQP1y4N4qdJz3Mdv6"
  "s3TuS6L7xAKdXOCtH26lOMLFjmAZIaiKngTopgPXHIBqulbDLOiLN030BVvM6BXQc3GAV/"
  "R83RswVL0A4jkEPAeCz/l2tKFqKC1NbtrTfoOtby30ov0u2m8DXnsAxpV4nzEdaVMJZPYE"
  "xvjJwCO6/x2qcQrweCb0JRsn+iLav/UG2t3p/i5A20IMlzmgP3cG+s84YKjUEWiZBzyfDz"
  "ydS/9bAH3Z5r96OvfRu+l0opZQ9Gl7GcCHpePeUQbGH4vo/a6AXuVl61+U+gAjnsDXNcAX"
  "t3Ff3Sbmf9D3HFmPjipf2/tdl61tM2iZg/pKb5P+spWPqf2/vE2GaubgjXT3Tkv7GyVdcW"
  "s=";

/* 
 * Resource generated for file:
 *    exit.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_exit_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_exit_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_exit_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_exit_length         = 984;
static const unsigned long image_Nuvola_16x16_actions_exit_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_exit[] = 
  "eNql01tIk2Ecx/G/buUO6jCNCrGVqxTDeU6LGdFdWelFmEZZBOa1rhN6IZSlFWQNKzqYx6"
  "iVmWap5cxWzQPNGlKmxha6dzotD/OQtK1+PUoL6dYXvnfvh+fhef4PAMIiu09E91iVrFKi"
  "4Eqe+/Va2drB5u3b7E1bFXa1NMB6ZQn/zjmi0DPsnxzWKdb/vowoQ7MpasZcWQbHIIeh93"
  "pYGhthb3iKryeVUG+QOXKJTjDPX+jnbAWzHXuT4Pg2jLnP1t+P1tIyvLl5E8MlJUD1I/w8"
  "l4f6CDmYPbHQMxuiiY2ZdYxY5+2owQCupgZmnQ4DrJ5jx2BWKjGRmQX7kcMoWbXCmUkU6f"
  "KVbm7XLOq78/ZLVRU6i4vRkZ0NTqsF19KCN6mp+FBeDn1iImYTdqE3KhLHee4PXb42YOWQ"
  "s+Iyxl42orf68fzeOw6lgdNoYGG9jo/HuMkE49Nn+CRdDWNECM5KvCdcvik2wm5PVaA7Lg"
  "xj1hEYi4rAZSlhffsW1rY2fImIRE/GUUzbbGgKC4fOzxsqv2VOl38eE26f2h2Fz9tiMDrA"
  "oe/QAQym7Uf/rWLWbfQFrYMhTA6bdQjaxCS8FC5BoY/kn1fL1gx/T45HX2QwJqam0Z2wE+"
  "18gm6VGFo/MerdCO2KeMxMz+BV3GY0izyQKxZNunyRQFDSk7IDJukyjDS8YOffhU5/fzSz"
  "K2pgaX39MNLWjjH9O9QLPVDn6410Hq/O5S8QyR9sDHJY9ijQGxyIye4ejJsHwKmuwlyogs"
  "1owg8zh9ZQOVq8hCjwEv9KJdri8pfYLJwmUj6JDodJEYq+9VIMnz+PcV0rJti6VtUV6GWB"
  "0IoEuCHxQgrRmYNEbi5fyHwem8lsNta3A6W/X8vXw7DSBx+XS9Dl4wndUh5qxAIUeIrmbP"
  "4+IlHagvmb82f/vossoujjHh7qfHa/lySezoueQmeOUDCZzufVJhMpmCe2d1roF9MfEVNa"
  "9A==";

/* 
 * Resource generated for file:
 *    fileclose.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_fileclose_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_fileclose_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_fileclose_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_fileclose_length         = 996;
static const unsigned long image_Nuvola_16x16_actions_fileclose_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_fileclose[] = 
  "eNql0mssm1EYB/BXImE+SOYSW/vFlEXXtJZVTFwXl5ow8UGVzFAaNQsdS7quFsIkYmLZTL"
  "aIhcQizJaobEGILwgbYi5NMaaYS12C0WJV/jvt9i62rzvJk/O+J+f3nPM8OQAo/GdERFyn"
  "wsLCqNDQa5SPz1XPwMDAl3Fx8SsSidQoFkuMkZE3dBwOp5bFcuW6uV2gGIzzlIuLy18+PD"
  "yM8vPzlUokmYbOzm7odBs4ODBia0sPjUaLxsYWxMYKj5hMhpzBOGf9r/f3D5AqlQXY3NzG"
  "9vYuTk5A5j0sLa1Dq13F4KAGPT1jSEmRwsnJQX7aBwcHXcrIyDzY2NjC5OQsBgaGMTw8gc"
  "VFneXs9vY+9PcPoatrAG1tHxESEmGyt7e/QntS7wvznfX6fQwNjZL5O8bG1Oju/oSOjj6y"
  "NkZq2cP4uAYNDV0oKamCo6PjW9pHR8euNjd3Yn//B9TqGUxMTOLw0GDZPzKixtHRAaanv6"
  "K2thXV1SooleVgsS7u0D4hIcVYUfEa9fUqUusyens/kzxfyD32YDDoLbampgVVVe8gkymR"
  "kXEXXC7fRHuh8KaxsrIRBQVPUVz8DE1NbcTMw2Qy4vjYhJmZBZSVvUJyciYSE29BKs0Dm+"
  "31xwsEUWvl5XUoLHyC/PxyjI5qYB5a7TeSR2v5npqaRVZWHoTCBKSny8Bkuu7Sns/3rsvN"
  "LUZRURXp/6/9y8vrkMuLkJ39AHNzS5a1hYUVYrMRFSWCjY3de9pzOJ48gSD6qLDwOVSqLm"
  "LXSC2PkZSUDpEoGTk5CszPL6Gl5QNSU7NJ79jHFEX50Z7H41Lkbd6LiRGR3lZAoShFWtpt"
  "iMVSkkOMuDgR6ZmM/OeAzw8AsY9IWNHey4tHubu7WZN3rfD1DTpJSrpDznxI6r1PepVLcs"
  "nInePN55ptKQk7Kysr6rT38GBRTCaTcnA46+3s7PzGw4O9w+V6m9jsyyYGw3XX1vZMK3EB"
  "1O9x2v9P/AQR/HK0";

/* 
 * Resource generated for file:
 *    fileopen.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_fileopen_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_fileopen_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_fileopen_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_fileopen_length         = 724;
static const unsigned long image_Nuvola_16x16_actions_fileopen_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_fileopen[] = 
  "eNqVk+1Lk1EYhx/oP8gPQZ+EkGnZnkgNguzTMMJeBgkOtAZBFBWkUYOCXDUxwcgoeqE3Uz"
  "bdNFtqFlYuLendwmIpVtoYEyERpPJDRFf32XkKyxF54OKcPc/vund2nzPA4B+szl/Zf9jr"
  "je33eD7MxOerjMu7UsPRttEo6GQWuVU7DMNICzQGf0gdvnyHaQu1ViMnx4ypbKqRrJG103"
  "f8dMPX0c/wagQGPmqeyXriG9iXmcMq91ie/c2vGmVH/YT7IfAAgn2a+nvQEwNbtvlOZTqj"
  "JLmp5rfQEdWoceREE91D4vVCc58mcF/2Mw6Zll/3FDztsODgbLw1IaKfoFfqPRzURF7DuO"
  "zftsQ+qvzquzqbapw618KUZAcTMDSmicZBtTBzsX1M+eXXtR95r+kalt8hew7Ld16qa2di"
  "cjJl7YyM7Cnll9Rr/9obaBVCA+B/CVeeyxk5isnL3yA4yRWy7OvIW+UkfWkhcr4jyi84o/"
  "0LT+C8cPYRnJQ+1fRAZTcc6pL+3IJy6dEKV4LdN+Rs3NPKr1X+8mrtH4tAleCT86m4Awdu"
  "w94OkvntrbC1GcyiBO7Qn356hfZV/bI22CPsCsO2FnAHobQJiv2wqUF65kwk55n+/H3a3y"
  "LZzZItaQSX5Isk57wKhZdhzUXNovWJ5PzbV/dc3VX1+X8wYxiuOMZCxwvxveo/Iqy11rVz"
  "wGt586waNsGcAyqf9hOewoTI";

/* 
 * Resource generated for file:
 *    fileprint.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_fileprint_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_fileprint_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_fileprint_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_fileprint_length         = 1136;
static const unsigned long image_Nuvola_16x16_actions_fileprint_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_fileprint[] = 
  "eNp10t1Pk1ccB/AToyYmuzEmxgtvXLKbhb/Am0pLoRgaeZMXFVAzTQOri1TeJBJdlBrBal"
  "JEkjEbcZRlYEQsslKN7eMWmbRQpC3UDq19wZaW9im10KelfHdou2Q3e5JPzrn4ffN7zu8c"
  "kegkEWUJBBWkra2z32Sai1Jho9FMzYVNpnfUfPTaNcVQQUHlDrG4hvyLz6/IOk4OHxYTuV"
  "z5BP/z9fSodDzesV0iURXtV52Wm5tH8vKOkfz8U4THqyCdncrhVCqVTSSpOBWjElAqVRNC"
  "YfXOoqIztL6YCIX5NH+E5gWkqKiK5ktId/dPg5n81n+ykfS+r29oTCAoJyUlp2hWSHN8ms"
  "9NKywUkpycb/d1dd0zZHonstk1KkRxuH9/wEhrDh49WkDPy0/35fF4e8RisaShQaptb+/4"
  "oB4cSa1vcOASMcQTLF2D4JI+cFwYj0c0W1eudLgaLza+LC0p+4EvyP2qsrJazjBTCIXX4f"
  "WuYFjzGsa/Q7C4wrC5glhwB2Bzr8D8cQWPn/8J+4ITbk8Ir/RvUFtb16dQ3HEm6JhiX+Jw"
  "OD5ieNoJnTeFZ85NPLIn0Tu/ibvmJG7ObuGm3oO30xbojCbMOlxQ3un1jY6OstunXQtFMG"
  "tdgkzPonAC+EYNHBjYwv6HGXtVwKF+Fi9NDvjcHgQCa3g2NhFRqdQRj2cVkUAA+jkvvpZz"
  "IE3IaM5qydjRlMBvf3xGnA3C6VyBWv2UvX27L6zVzsDwagYvXi/i1pATVweX0Tzgx4WfM5"
  "oe+tGhXkbXr05MGuxg9DPYzvT0PGIVinvLZrMLY2MMTtedxcX682hrlOJy4/eUNK1dRvcy"
  "KS5JJaitqcPwiBbbmd7eB4EbN+Qzfn8MU1NzaG5uhWZ8HAYDA53uBSYprXYSE79r6aqDRj"
  "OOlpZWMMxfCAbj6O6+az937rsGhnkTs9LZWa0f0i9n+/nF45uIxRKIROJYXY3B748gTO/Y"
  "ZvtELdF+xvX6+vrLZWWlOyWS84UyWccvbrcvnee4JDY2EvhC75Rl12mvKHw+Nj1zrzdI//"
  "PH5zU1Z8VVVcd3l5eXEonkAmltlV+3WBajCwsONuM9a7O9Z61WB2ux2Nn5+YzFxaUore0X"
  "iU6Q4uJa8g/468DC";

/* 
 * Resource generated for file:
 *    filesave.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_filesave_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_filesave_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_filesave_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_filesave_length         = 972;
static const unsigned long image_Nuvola_16x16_actions_filesave_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_filesave[] = 
  "eNqlkvtLVHkYh/u5/oL9oaDYLSgoapEtSrvXtuuaoHSFym7Wlt0vi8VuRRe1i0jSVUOoiO"
  "hKVlJbUWZIme7cUhu1FHZmvMw4c2Y8czlzzjy90zBO9WtfeDjnhfN8zvu+fIEhw364dCNt"
  "WX00a+1LNVvIWlOrZq6uVX9f/ULNzEvy/DMLVjwJjVtUHx064uq/iBtncr6Ja10Q0ELEjy"
  "aogl+HYCxRGyROv6qwo9rFqDwrST+9wGZU2TR8Xj/I98EwKBLgVqDPK05AsqWOSl5vr5sN"
  "Vzv5aV2zkfSnbTLrlZYoPiVATHw1kvA94rv6wemBHskJBMHh6GN3tcKEgg/f+DpKYOBzj/"
  "H/BGUURUqPtNTdn8jxSh//O9zsvOdj/OaOQT9js1mvsBj41SDJo8czpA9/KNF/j09mUeK+"
  "T+b3M2Hr1/4la4xwOL41PYWhYUQ1IiGNgYEIAX+EXmcPu8Sf+IU/e4tZP90Ez1rDPG4J88"
  "AWotqicvc/P7cbFW68Vrj+2sutt26u13Wz/k6UtG3tg/5vO0z6vlew8rLB8vMhll8Is/hs"
  "mBwhuzzMQmF+aYS0gzrpZTCnCtJ3tQ36f+w06dufw4aKACZLN66eXto/9vHufR/Ngr3LzY"
  "MXLkbmePnlqM4M8afvSfkL95j0P59AQZVP5nNy7IyD+gYXMc2Dqnjk2Y+t1UlGgY9pJQZT"
  "K2Dm3pSfLX6+3Mb1F71YzB0Mn+GkrLILr8dBx0cH3ZL56k0nuYf8ZJw0+PkczPor5ecUmv"
  "W8h7Ci3ENdrY25q+ycqWrB3tJGY1M7Nmsbj5+1srE8QMapGGNLZQeFqf3l7rOQXyf+BS/1"
  "dSYaGiw0vLHS1NQiNGM1veOp5J54ZDCvEsachV//aR+8/z9OulK7tNgeXVLYqB05fF8rK3"
  "2kHS+p0YqKarTi4hp5f6gdOFyjbSlp1rL+fq/N3W+Pjp5y05T0v4dPZ8IqwQ==";

/* 
 * Resource generated for file:
 *    help.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_help_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_help_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_help_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_help_length         = 1252;
static const unsigned long image_Nuvola_16x16_actions_help_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_help[] = 
  "eNo9039Q03UYB/BnC3QbsA0OOEIlTgRBAqyd3NBaBQK1crRMhMLiUgyKq+sM5SjIDVEQQQ"
  "U6Q+IyA0JiYCKC8SOGu0J2MhyJQrghCxw6ftmYNLV3X7D647n7fP54PT/uuYdCSokWI7iM"
  "aHUxl/yPSvkRpy6sS2iZ2ZSmsYt3X7IHvNEy57K+UkNehxLJPY/P8swn4iuJBLmPbShj1x"
  "z14Yq+Vsmy+3C83YqKHqC44xHymh9hfxOQWmmFOK0fTuvK20mgCPzfBzPer8jH/cVq7We1"
  "k2g1ACfVNuRWj6KqbQJljWPYVTyM98stSD31F2IUFghDvzUQLydkyQcc43CfPfldVq0ZrS"
  "PAl53zKP7BANPELNp6x3F1yAL98B28c+g3yBQ38frhKYTvtYDjW3qJlmW70toSiTSzF+eH"
  "gBotkFU9CbVuEtZ5G5LyB/F2/u+YmruPi723sfGTAUg+vQ5x1jRWyXUgnnLnclFlbcaZGT"
  "RdA77qeoD99XNQVhlx5MxNpJSNI+6AEd1XLbDM2hC1T4/QVD2CUm7AL8WE5StK+lbKzk1s"
  "LnmIj2oWcKLNBoXqHj6suIP4AhOis0ch+2IQt6fmMfzHPYjSdPBPHoDn1l/hmXQFgrAqa1"
  "BShzVE+QCcd81IPjGNHKaX9Iq72FFkQOnZMYyYZgE8RF6NASsTdXhyWy/Ykc1wlqshFDfY"
  "AxPbrc8cWADFj4GdaIQo4xaicm7h43IjbAv3YZ62IrfGCO8ELVxkGrCjL4AkKjjLfoZgQ4"
  "PdR9poDs/9E5QwCto+BJJfA8XqsD1vCJMzVqxJvgx6qROsmDZQ1Hnm/SPouTrw47rgtPa0"
  "zSWsvHFj9gScksdAbzJ2mx60uQdBu/tQcHYcFNnJ/C8y0czYc6Dn68GS1EHwWhcc3Yr0rF"
  "WF0U/v0CAgwwyKY3YSpwW9/AsyvzGi3ziD+Dwm56Z/60rqQRHV4LzSAmcxk4v9+Qfknc9z"
  "8i9VbdgzAs+UYVCMBo6xGjRp7+JvLOCIygQSNSzVXbSOkY3gS9V4Qlh4hWivO3kXELkqVw"
  "uCKwbD0q/Dm9mtQ2wXgnb2YNexG/CS/wQSfw/2C3XgSlvBf7Uby7xKxhkrIsoicj9I5HFw"
  "8Z78uE+VNPlu6YDve/1w3srMEa0GR9oJF3k3+FvUSz07CAt7iPaEEWXSkvd47FkezE06K5"
  "xYPMVb3BXHLwvXV1ldIxrswnCVnRd4et7BrXiAxc5KJ9rnxtSm//w/brcmtA==";

/* 
 * Resource generated for file:
 *    history.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_history_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_history_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_history_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_history_length         = 1156;
static const unsigned long image_Nuvola_16x16_actions_history_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_history[] = 
  "eNp1Um1sU2UUPgazBGRGJwt1dxixahgE+WMMTBME3UicP8QSlRhEEoLEaDTBhB9+xET3Z5"
  "nCNDATgYhNS7sxVrau+26Xdu36wbrabXe0tLsW3VrXu9a297brtvbxXf0AY3yTk/fknPOc"
  "85wPqtEQbdfSut0dVLavi2hvd/3W46M/1n/hF95qDSeOts4mDnw5GVGesOtov/Fl2mNYR0"
  "93ENVoibYx7F942tVWUaUa/P7kBQEXzCI6rVHoewLQdc+U9IvM9v4PEVQfGlLTU/qqf/A7"
  "2P+E+gHlqwMDnxtEnNX8hOtdTsTm0xi1umEZtmMhloHJ5EaLehyNxgRqXh+yklJdWaq75d"
  "L6TbUdlz5Ux6HujcLvnUHwJo/V1SIkSUYmI6FYAMKhIPwTPLS9czilFaHYa2gj7uLGeyvO"
  "19Wdnl55r2USPvcU/n6FQvEuvcAEpZwhPohT53x46bMAyh5qVVXWaNSvNC/gSucE+owDsF"
  "pvIJXK4P/ebeEWdJ1OHDwTh2KXvoer7RFeO/sbEnEJy/k83G4/rl4dgJdxXcqvAOICCosi"
  "YvEkAgEB+aU80gkZR76J4tEXBmPci7bEwcZbuOF0IZfLlmqIYhJm6zjaDYNob/oWJp0RPf"
  "12eDx+xi2F6QkvjjSHUN3gTFbVuROqxgBcNjukTPoOUUmCs80A9ZXrEG7PI59fLpmzchZe"
  "5xiONgfANXiTm2tHI8fPx5AUWc9sZqWp5XJY6e8HQqF/9V4sMj8LSC9KePe7KLj9rlj5k0"
  "P6N1vi6DZ5MBsOlvyrDjuW/f7/zG7NFxHC6O1z4+1zi3hwh6Wfyo0Nz38wV2i6PI7pqZtY"
  "4Xks+3wo3IVb22UpL9tfkA/g68tu1J+O4p5y4xu0yXLfhu1e7UeaLGzDPHiDEQHGm4VCln"
  "OQZBmra/cTDmNmMgi782d8rMlg405fF1WYy+kRF9Fml6LyuVlboz6Da6ZxWIYcWFxIw+nw"
  "wGZ1ICFKsJrHcI3d9VcGCQ/vEzxUObaFqh3sfp1MPETclGLDM3O6Y01ZtFt+x4jjF5hHpj"
  "FsmWT6r+gYSeLEmSzu3z3fRVVTW4ljdTn7HfzjPBOhjB6LHlLUpbr3vCNHVZ8sJVWfLiWf"
  "PSnHuAOpPlLGDpMysp6ULLb6T/wfpVbNaA==";

/* 
 * Resource generated for file:
 *    kalarm.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_kalarm_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_kalarm_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_kalarm_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_kalarm_length         = 1208;
static const unsigned long image_Nuvola_16x16_actions_kalarm_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_kalarm[] = 
  "eNodk39M1GUcx99wnKcGGKlQgxBFt/rD9fMPl6ultbYYmzmq1Sbm+mlokygucYkWyBaTCE"
  "K0ZAa5xXJF0SpChpHRRZeQx8l5x93B/QC+cMeP4wvH/fJ498Hv9t6efZ7n9Xzez/O8v6UA"
  "jgJr6tK0h7qe0lmG3tKEBp5HrCETV/YDW94GMps3ot20F1FrkSbc/bTWXrNOU/omkFIo7L"
  "tA6vmH72ibuJhGXksi/0kgm0HHq+BnT2LozOO4tjJms9T7RP2JnKrXsSE3qfNlYGPtfWvP"
  "qX9kkxatsLLuIm7zwZ5URvpzGenbyqVf07h8Tuotouuyx40ELlSv4scZiZd6P80OUtlE1y"
  "eg/xuZ71nLuOElRh3tjI6ZGfGaGRruYKxrv/DJXGgAlTrZo0XDv/ckRrtLM2a6itMDbcWI"
  "h72rGbhazoWpAOMkgxFyPkzOzN2i36syZGzk8o/JNOxDvGOnZvaXXYlzx5GwpzgbTZNOLN"
  "NaRL9rhle+/4GK28OVT1VDVPpNnPBMccJPxnr1XBKfdZlofQ144f27EnRNB2Gkfz0jHhOX"
  "hRkeGODXFado6jPSd91Cxfgfx6bmODK+yCm7lbycw6sFcJXKG1Q+ga2d1YhR2cnQbIDB8K"
  "3bfQ2/dfLwvkJWlR2j0+ai4lM57FA4OjpN/plH8zvgCQ0erN2Nbd01iNO3m4szKufVCMNR"
  "8WC28EBBAUv0R2l3jNHrnaZ1eELGcgjDc7QUg+VaPFqRhXt/LoWf81uoKmMMLMY5PT3Pb+"
  "sa2NH6Hd3Cudw+2mxemm8qHBl2S/+H2PsKwiUJyJX8rDq7A+fDPjDqrqd/lhx1emj6d5D+"
  "mSA9wttsYxy6MUKTdYHq4FeM/aTlhUfQflhyWyIZLNNgl7kRQS5lUHX20Kss0z0REq8+3r"
  "SO02xRhJW7s/SK9020fIi4Pgn5R4StEJ0UnUnFcU8LogykMzJez0mPk64RH52OSXqcdgad"
  "X0q+c+g6hVjlBtS8IUyR6COtSANUrsEO4xHMO2rBBYPkcGQb6ckj3fnk4P1cbAMt5aDxGE"
  "JVqcj7QLgyHVCeIv9fIrSte3GpX9jTSTjUlImTv+fD/NcBBOSe1O5nYa3PQrVeh9d7axC7"
  "XIjO06uRUr9e/N8p/ZPxwOfbYa1Kw4snVjyJmnRIb7oHOV9kYfPZFNz9ntQOivQpeKZxO+"
  "y1G/BYbQbwP3oBYDw=";

/* 
 * Resource generated for file:
 *    ledblue.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_ledblue_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledblue_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledblue_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_ledblue_length         = 952;
static const unsigned long image_Nuvola_16x16_actions_ledblue_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_ledblue[] = 
  "eNqlkmlIlUEUhkdSjBbLay5F+4KQS0igUfYjW83KIgrDi2FuFJUtlBoRZYtmIpVFtGmlZm"
  "pqSFdQ+5EaZkFhLtBOplmJGYQtXpenM34i1d8GDu8355vnnZlzBlD8ZyiPLKX8i5UKrhC9"
  "o9TMnBBXn/zSpastnzaGVnwPWF7SNs7tcolSyeuUOqmUSpVIVHoM8QuFW1Y6xTmkujQpp4"
  "W3H630Y4w+iVfvf3I4tRFHl8tFSp1wU+r437xvweQZ5to3JU976PwJXd1gFbCv39AuK3zp"
  "gfzqH0xyz25UarvrH/wwNcdSti/DyqNmaGiFD1/h63f4Jl6doq2dkm+Bx/Jv25lulG2sXF"
  "jZaN5mdtZGNf8Fq471Y2mAqhdQL+tet8O7DkPrha2U/N16WHxYIPcn2KjpKzQ/3Lek3HZ9"
  "F/ZRfewvhOInUNEE1S+h5rWh5Y1QJPnYPLCN6Mcu+Af2o6LyND8mqKbDdiuM3AOzxXtbFp"
  "wuh2sPIPshZIqmlUH0dXA/ZKyzk/Wjp517pXmT+dkvUxx4J0LAKViWBmvPg/kqhF8zVM91"
  "flEKeB0BUwKM9c7+rHmXiLp2r6NyL2HXpMOGixCaAWHChl03VM91Xv/Xe3gdAyf39IH9HT"
  "ZVWQJO9RJ0VtZcgs3CxOTC9gLYWWhodK7hpT2CxGPR0V5GjAm/NVB/n9w1/nHNbJBzmjMN"
  "dncxxN+FA6UQJ7qryPAw63PIeeaZ66XxEwMH+j/hio3J4+ad0AvdRIjjDtkv3gKJ9yDpvq"
  "HaS58jQioecqYXB1PkUP+Fl89k16meNxpiMnvZL7U+KPVPrpQ+1Bqq5zofeamHibOS5P3Z"
  "uQ29vwE+RWKBm/P4HbfX720iobCHlGrhH8HJKtm/wErwzjpMzlGFwo5Xg+Nvfu5gdkagk3"
  "N0jpffued+S7LaPH3PPnd02pKj1OSV6p/xG3spcYA=";

/* 
 * Resource generated for file:
 *    ledgreen.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_ledgreen_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledgreen_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledgreen_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_ledgreen_length         = 1220;
static const unsigned long image_Nuvola_16x16_actions_ledgreen_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_ledgreen[] = 
  "eNpdk2tM02cUh8+US4GB7Z/LMEBhNIUWe6e1F0YAhbUUukK5DVKBmm1Os7i4bImLH3bT3X"
  "RGvOOCi2LYAiU4WDKQgYBV6BLdDIMKmajTbaW4ADIL25ff3nVZsuxNnuTkPb/nfDqHylKI"
  "7PFEdWFELookB5VQ0YbOpGfVflmFNSh3lK0mF5oC63KkvZQltVG2LIpkSiKtlig3l+hfv3"
  "Z9KjVSh3xfDj7sO4ibdycRWH6IBcYP93w40v0pNNtsILGkm6SKTNL9x7dxwifqw8Yd58ow"
  "/tCDVTzG/98f7O/6ohfOI7sQplJMkUwtIo2GyJrCo7LYdv0hHTruXcDEwgR8iz7MP57Hyp"
  "8rIQLBAGaWZuH9bQLdv3agaP9zIMmmPlJqYqk0pTisXgDNCSVaplrgvuOGx+/B9OI05h7N"
  "hfAt+XDNfw09d3pw/NZx5LXpEV4sBil0NeHlaW7utafAOxCBxsFGtE63ovPHTly6fwljv4"
  "zhiv8KBh8Mout2F874zuCFyy8i5uNIcK8IwdMaL/MbMvxJh5NBRwncOT7qvqnFe9f349Tk"
  "KZz1fRbi9GQrDtx4Hw3D9Uhs50AnCAmHE8FtNS1xOzOCgjY+Is6vA78jCqluDsZ+JapHbH"
  "B5nCFqRuzIG1BD2B3PMtGIbF+PuLNx4OzG1fg9KcGkDjbri2iILiZD/nUaNEMZMIyKkO/J"
  "DmEaEyF3OB2y/jSIv9yIxM4nkfC5AFxl3lr8Hi6Q3ZUJ4UUBlP3peGZEAvOEEvYbm1F10x"
  "CigtUWrwr5Y1KoBjKQ3ieAuOtpJJjzH0W4ontlbVLIh9JgHMmC5Vs1apjTNFOIl26XMIrR"
  "PFuE2kkTrKxnGpVANroRypN6RKuNV6kyrly4W44CjwKFXikc3xngYvnd963Y67dj73wFXm"
  "X19tktqPregCJvDgrGN0HUXASSarZRdWxMuDHLbTpYgkqfDs/P6LFzrgRvBhz4YKUBH/3u"
  "xL6FKuy6a0b9LSMcM1oUHLOAJzMMkVzFJ0sqkSY7M0ZtmipusWEHy72+aMY7QQeOognHGO"
  "8Gq/DGcile/skMy+lybNDlzTFXSlq2/2p2Bzq2x+wmIqSbe2XbS+HsqcNbD5pwKOjCJ6su"
  "vP1zM5q+qoNqRykic/QDJFFIQs7f96NVM58hY2QrYihLWc1T6IdTLVuWJA3mNYnTvCa0bl"
  "2OUumvsp6TxIrYUFb7j/8XQlP5Dg==";

/* 
 * Resource generated for file:
 *    ledlightblue.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_ledlightblue_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledlightblue_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledlightblue_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_ledlightblue_length         = 1096;
static const unsigned long image_Nuvola_16x16_actions_ledlightblue_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_ledlightblue[] = 
  "eNp1k39M1HUYxx8yBXO22lyLyVyh8mMoyK+kf9SmLCnd0GSpg610q1zNZv/2T2WsP1w17u"
  "A4ya6ruyPD+4GHdwkTbqtIjUJkIKhxQqIh8scd5IHg7dXz7bt+/NN3e+/z3vM87+d5vp/P"
  "88jar0Ry3SIb/SLbv02VTYHylI3ulie3eibyd32TKNjdMrtyi3NyUV5DULIsOyXbslTWNY"
  "iUNIkUHxf5W1/qy5Ctoebit7qpC4wwcCPO3dh9puL3GRqLYfcPU1bdiqyt80muNVNKP/tX"
  "n+1atajMf/5g4zWuxxf4v29sZp7D1l5SC2yDkle/WgrtImu+TJM1LteLR6/QMwUjcRifgf"
  "gcJB7ArGJa+e0/IDoNfTHYe+wykmNpk3zb8pRVjm2LyzuoCM/TMQoXx2H4rubQPHdUM6kY"
  "V91Vzd1zC7rGoKozyZLKM0ietWrJaqc3493rPO2HYxehMwo/3oT+CRiaMtF/By6oNqK++p"
  "8hS2MzakdILbRFHn/WO1HsmmG92nYG4eOfwDcEZ0c01w0TBvdfhboe2NUG+T4oOnmPFeXu"
  "WHple+K51nm2n4GXQ/DGOfigG2y/wOe9Jgz+odoOqW9vGCo0dvPpJOkvBWZX7o8kdocXqO"
  "6AI13w/g/aw3nVaB/2HhMG/+SC5lXfOxGo0djKs0ky9gTmntgXmXwlnODwd3BU/TaNd2jN"
  "L/rA2W/C4IbNrv9eq328/T0caE+QXuGZfnhHKFjlGKdWe6zXOo5LpsY1AJ4rJgxu2Byap0"
  "FjPtKYGucoaYWN3bLFu2PdaxEsvQs4LmsthXsQTg7DqWsmDG7YnOozYhr7kxQfDBszUCPb"
  "AstSik54X/20D6++T7PefbPWbFGdjjGBqJnDsHnU59P3eNM+yOI8a6estz0mm78WKWjKfG"
  "RD4+AhyyX80QeEbkObzkDolongb3r+Dq2jSY40DfBo6fGoanOlROe/SPHMCd2h+syHci3B"
  "sgNtvNfyK6eG7hG6mfwL3uEEtdrIptdDRt12ybHm/LM/JXqWqt7Yyey6Zbqje9LybV1PPe"
  "+OFe4LzBXtD8xlvuCJL92gd5Vlqdb9W/7f/f0Tsu2oDQ==";

/* 
 * Resource generated for file:
 *    ledlightgreen.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_ledlightgreen_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledlightgreen_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledlightgreen_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_ledlightgreen_length         = 1140;
static const unsigned long image_Nuvola_16x16_actions_ledlightgreen_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_ledlightgreen[] = 
  "eNp1U3tMjXEYfiVLa8Vmc8utdNqpk3M612YYwpTTZXTccnLQMHWUZRbmWjTktnRb6EqSlE"
  "IXCkP6w202uST3LsdJdOF06pjH62Pzl2979r37vc/zvs/3fr+XtK5E2uFEOjsiAznQQppn"
  "5z+seEyAyiQNC7L4hgX3ufpPNw+WeFWQSBxMnt6OJJESqdREShVr/+oXDRpHeirU7JYjtS"
  "odTz+8QEdvJzp7v+D5x2ZklZ/BtNU6kEh0kcQ+7qTR/NMHukwYtNSuwXjJALOlGf97vlje"
  "IT57J4bIpI0k9p1MciVrxw6l+Y4FK4tC0IbH+IoP6EI7vqMHA7AKsHDcjU+cew8zniAqL4"
  "p9eF2mKXJnmjN67qjosTjethZNuI03eAQTmpnbzqrPAn7XM3HmLddvxl1kdcZgvF4OEisW"
  "Dw5wLdEWqrGj1R/VfZl4iXq8xgN8xDP284qVTWhBI5894lwDaq3Z2GWag4VnZ8Jepr45Qu"
  "9m2vQkENtaZmN/uw5X+1O4SxWr7wj8JsZzjh+jGtX96ThgWsbcmdjSqMXogBldE2M9LDvf"
  "hyLRHILEjlAk9yxFzsAmlP9MxjVkMDJRgcPItW3Gkd7lAifRHITdrSHwCJ/d5xbvZtnXvg"
  "QHu3U4+m0FUgcMSP8ZiSxswClsZMRwHCWcpdpW4dj3CBzs0SGpQwfPFf7WkXEjzAkt4Thh"
  "03N+NfOjkY94FGIPirCfsQ/nOC7AVpyGEWk/IpFiC8eBtgi4LpjVY693qFh3Kwg5WIeT3P"
  "MMtuE868pwHOXs/zfKkIJiJHFuO3OikI01iL1hgINMXU/BTkGyeDVy+2K4Rxz3ShD4lcjl"
  "bz8voBJ5XOeE4CWfOQU/YuC3MYTvgCyCwpydSD2pJDLfwHPai1Ic4ncWalHCU6/hv32d41"
  "Jc5s5lSOZcAowX1sLeS1FHPrLhFDCeSC5yd5RqGqPzjKjsT2NdId+CK7iPe3jIaGAHd9lZ"
  "jS0DccWxcFH4vSEfqRepFEQK3gE/vse8E3aesoqp63m21UmoMl9Aw0Atow41n0txuO4QZh"
  "mXwV7sW0OeEjGpWadkvVpOpGFIZEQiiRNDN3SK4sakwHldqohFVtXKMKu7dn63o1RZTx4S"
  "PXl4O//ZX6Wg/wXouWQq";

/* 
 * Resource generated for file:
 *    ledorange.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_ledorange_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledorange_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledorange_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_ledorange_length         = 1072;
static const unsigned long image_Nuvola_16x16_actions_ledorange_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_ledorange[] = 
  "eNplz2tIk1EcBvBjVrPW1LXuadZuXodSgzLNZpvWh0LCMoyyD0mXzWuuK2XpNs3ZxZXXtJ"
  "ZaVmpYWoFdNCUVDTK6aARdpA+WCTmLOct4+sde6EMv/ODwP89zznmN0lnMKPJgZldXZmGM"
  "l+vCojLn8Wqz1bLP5oRVdvOOVWOZMYqhlPCFjboVXht0K32mpUSI2f4oP6bX+DIj189zme"
  "RVwFjNtVBfPLOa8PVdL8ZsX2AnwwMv0XO7EOd3q7B3+fybSeFi8YHof/1sofui/CkuXV2p"
  "6zA+3A7Ajv8/OxwjXXhYnIB0lc/r5AiZJEMjZwbJLLcswdTqjj1BwHA1MNpN3gBjX4Cf35"
  "0cQzR7C4z0AF9r0JoXCW2od1NapFxwbPFsTaWCh/HSQOCjBfhUT5kngK0P+P6efKB1P806"
  "aa+BMkX4ZVWiNGYOdCq/zSeWzKnv3SoAMnlASwIwUEbqgMFmYKiN0P8MPqAuzQbKgSe7gG"
  "NueK4TIU3j31oQMPfzt8OewBEG5LgDD2KBfhPwgbIDVaSS1hXAm5N0/hbALAQOMtiOe8Cw"
  "MWDkUshcu8MwAzBQP4ucdAUu+gBNkZSns1o2AXfUgFUM5E12ZsiEgQ9LfMBYdaDIPp5D78"
  "+luZmcJmfIeVLCKeRmZ7iMifq5fJyLD3RY57kPjRpFwFluv4hcJFfINVLDrS+RYubM5TP8"
  "OCWCKTZ4tIDn1tinWwCUTXLeaeV6DaSJc4tcJ5e5888xvDKIsS8qqCPHnb++SiPG+AUPoI"
  "L2rnL5ZvKYc5/c5t5Cmd/lAlQkBkMX4bs9f+Z0vj5gUX3rUQVQOw2oo8xdrtdDnpI2co/U"
  "kxs8dBoVSIpUPEpTST0NvrNZhtJbnB4d/LrFFIJfd4TOfDd5SV5x57TTvfc80WEORsa6kP"
  "cpq6X+erWc6dfK2aFoGUsKl4h1qqDGkt1K9FYEwdbmjYleISaeCTHa7oUXlwNRrlX+vbdZ"
  "Gy7x2x8lYxnUP6CWsoMaKUtZLWM05+vC5JtS1yhasuOWjVh2LnVYEpc5THFKW7pa0aENk2"
  "/ThkkEyZTVa5z9P9XrWJI=";

/* 
 * Resource generated for file:
 *    ledpurple.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_ledpurple_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledpurple_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledpurple_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_ledpurple_length         = 1212;
static const unsigned long image_Nuvola_16x16_actions_ledpurple_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_ledpurple[] = 
  "eNpVk31MW2UUxl/njNNlBmMCGpe54FjLaukHbRf3IUwpa+e6jqJ0WVsKDBjBZYYYxW1MNG"
  "FicIosG4lDF526bKzEWJNtiIiAFN3mQnRjmYy2YoW2K+O2vf0GHk9WY+JNfsnNc8553vPH"
  "c7TaJvbijmZmMLYys7XjQf3OFnXBlsZutbrRq9e/FS0paY4VFDb414kq7DlCk06wzvSQSF"
  "zBFIq9LD+/lmn/nS8pO7LSaGk/82bDV/jm7BU4J33guAiCwShcLj9sZ0ZgKXsPa3JNPUJR"
  "ebZSWfffvFZ3eFXp7rbRL9scCF9OAByARfz/iwDha3F0HriAPMWeGyKJ9WmZvIZptIeWFe"
  "uavjjxSh/ip5NIDieRuJlEyjePhfDCPVL+ecRvke5IYbEbaK+0Y63Y/K1EVrVCrTtQZNZ8"
  "iO/XjyF0lEewJ4LIT3HEx8nLmULSlUKc/CKOOIJfR8B3ROHYPA6d7DBECuvLmtImW6uqB/"
  "alv2DSMo25j0PgzvMI98bADxJDRF8UnI0H1xWCu8aLS8t+RUvuOUg31Azs2tXmPbd2FBfZ"
  "bxh8ZALO0jvwHZlF4OQcZj8Ppumag7/1LlzGAIYencQl6rWt/BkvPPc6V7u7M9qbdR1DzA"
  "UHm8bY/Rxur4pi6nkenrIQPMYQporCuL06irGlQYyyGQwzN/oyxmHY2Bzbb/00Opg1iSvM"
  "h9+X8PhjyQKcDwN/ZhJPEasBN/27SJug2vX7IrjK7mA4w43STe/E9+37xD8kmMJNFsPEA4"
  "twPw54JMBMAeDVpJkuBP6WktcTuNdziyUw8qQHxQVvhEx17fbuLWPwMKo/RrNywLcNCJQD"
  "d+vTBCpI05GHgnbJIj/qPSu5CsnGqpHtxre37zecwl+ZSXhp3xk1MFtJEToE8O8TR4FQE2"
  "nVVNtK+6whMudRs/kYBAqzxWBoWa4qrrd1Fn0HnvzndhANNNcBJM4DSRtF7zhprxEGIKYE"
  "Piv8EbnPlveLpZUZW4sPMrmqNluyoerGyZ0XwZcngYMU3y7KbD8xQJwiaIdoxTxOlwxAvq"
  "nW+Yy0MleRv5fJpdVsvbyOCSWWbIHSZK/WfYALr16G7zhH76eQsKUQOBFEf8M11Os/glBl"
  "6RXkWYRKefp+lOShyq9jIpmVCcSm5Tl55pfEiqofNEWNnFn/btxCbFM3BiWKPSM5eSZzjt"
  "i0QiSj+5Wn7/cfrcmO1g==";

/* 
 * Resource generated for file:
 *    ledred.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_ledred_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledred_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledred_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_ledred_length         = 1008;
static const unsigned long image_Nuvola_16x16_actions_ledred_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_ledred[] = 
  "eNplk0tIlGEUhs9kOf80jjOZWUZ5xRohuyy6LbpAGRK6KScrL91IKi26LXJTJBYiROBCkN"
  "pE1MKMwDCQbqhdxKJdSi1sUek4aVnWzFjq0/lmFIJ+eODj+9/3nMP5zqkUkWPKceWsiL1C"
  "JPewSNOJuXP9VV5vsCo7O1SRmBjYI9LiEylQHHtVe0DZr1RO+dW36JTI7Xqvl+fV1fhfve"
  "LXwABBv5/BN2/oqKujJicH9d8tEsk4+I//iEjKSZGXbdu3E+rshFCI/76xMcJdXdzfsYNS"
  "kbe7RTLLormtcpGbrRqbW7dANfT2wuAgjI5GCQTg/Xvo7oamJlrXrWOXyP1iEZd6t9aIMG"
  "D89fXQ3AzPnkFPD/T1wYcP0XgvXsC9e9DQwPCaNVxQj9bgOxoT09zicPDJsgiVlUFjI9y5"
  "A21t0N4OHR3w8GH07to1wuXl9M+eTavqS2fNenrO6fT3eDz0a7xAfDy/d+6ES5ciWm7ciH"
  "L9OtTW8qeoiC9z5vBZte9cLk7GxY1cjo8PftTzkN59VYIxMYynpMCmTWBiFRbCli1MpKUR"
  "nDmTb6oxWlPDeZcrVOd2BwPq/6l3YWVSwRAbC3FxUex2sNmYmNIY7bDxu93hGrc7MJCYGP"
  "k3oRqcTpg/H1JTISMjiuZmwYJIrMkZMyI5hhISOOPx/Dhrt7d0JydH4qN9jOiysmD5cli9"
  "OsqKFbBkCSxcCJrXaF+rp8TheF5hs+VfnTePMe0h2j/S02HlStiwAXJzYds22LgRVq2CzE"
  "xQ3bjbzZWkJHw2W6nOnbM0Nrb5ganT9M3kWbsW8vLA5wPtOTqXrF8PS5fC4sU8Vu1uy3qs"
  "8+PRuRedx4wSp/Nt67Jl/Db1mtz5+WDmwVBQEHmPcZ2bR6rZ53L1qTd7eocOKWYndmkvaj"
  "V2l/q/6bv9KS6OMKLv+HrzZq5o/UWW1aaz653eHxPDnPfYbKK75VQKiy3ryenk5JGLqanh"
  "akXP302vCkVKFJfRTuf+C4ob/d0=";

/* 
 * Resource generated for file:
 *    ledyellow.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_ledyellow_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledyellow_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_ledyellow_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_ledyellow_length         = 988;
static const unsigned long image_Nuvola_16x16_actions_ledyellow_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_ledyellow[] = 
  "eNpl031MzHEcB/BPpE7tnGjWMJtkwph5Zv5hnlae5mE2XQ8yFTMzpkwkD6WZpe7q0tOWEZ"
  "PjcuUpqqGjiZoIM5LYOi2UdHfqrrf31W/zh9/2+ufz8H3a71N6RKTsmEjlaZEnGeJdkSIr"
  "jPFSciV+tPVqYrCt5OhUe9E+//bsSDHrtLJWFy7Ds6NE8mJFcmNESpX+B6ky3pIulxsuBq"
  "Ol9gS6rHX487uNrOi01uPdozMoTZ2BzG1yXR8hgflx//rNSTKhMk2ettaEwGl/DMCO/78/"
  "6LXVot68EYZoacqKlEnnd4qYEkV1M1Eufrw/A+gvZl0tvaVv1K1op/f0jErwsmwhdNukjO"
  "uojYdkec05QV8r+6EjI9XQG2qmT8p6T8hEOXBZ56M8SaCPlC03Dg81fi5XAS1kj2A+l67R"
  "PXpIj+i+EsvnNWKALz74eNMbhh2e1RVpPtaeVxqgVQDrCKB3E+tSKI8uKNiHNOa28ip+wF"
  "dBT5Malw74dloMaltfi5px9n8n21DAOYH1S2mLYhngmsicJ/CDNR0C11cfmI6r7XWFGpuz"
  "jf3djNvJRWAdGIO/YsRgrJ85B/1mfwf7T2gcLwo07Y421vQx3j+EdTwfAsn9nvMUM2kSjW"
  "KN+3wCG+9RHK/59Tjdy2xtDGDOQ9kziBbQSlqvWEWLaAqNHKhteR6AnGiV5U6yxxpLoT+c"
  "vVwb7nXm0GrSUizFUTiF0lwaC5fTD7czxkAX5hFecUp8i3YPMzbedZ9vGi2mjbSHkuk47V"
  "XecQlNR1N1EPQR3pX8f0beOCxSECuBhmjfpoY7s3iOEGW/g5ROGZRAUdw3FK+rZiM3Rt1s"
  "iJKpuZwh9z9csEskizOh03qZy85Oxodn69Dzcx9cfScH2Dr3o7l+A25lTIE+3PueXivB+c"
  "r8uefI3e+eyUyt+HJGNxu2q6ouxY/tNKUEOUypQY7ihHFdOTtUFl2YaDPDRJ0d6SF5MYP9"
  "fwE/rKr2";

/* 
 * Resource generated for file:
 *    mail_generic.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_mail_generic_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_mail_generic_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_mail_generic_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_mail_generic_length         = 1156;
static const unsigned long image_Nuvola_16x16_actions_mail_generic_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_mail_generic[] = 
  "eNptU2tMk2cUPgUKUVtdjYDaEpgxQRL9Y0g0Yeoo1xTMhrLq8IcjEUMh4g1c2FyNl0yyH5"
  "ukxojKDMNqFDVEtsVoWYt4AUOxFhSLlIu1F4FBB9QC0u/ZoZBlWXaSk+fN+z7POec753wZ"
  "GRcoY97T0s6HaDS37+7fX+2Uy7MLxeLVYRLJelq4cAtFR+dQZJSSJIvSSCyOpdDQ5ewraN"
  "MmXdA3bjxDmZlVJc3NvQGwmUw2Qa0+2iWTZeYRradlkZ/9r37z5rPz+srYysoHQ/iX+d8L"
  "+LWhS1CptB2RUblbFy9OJKlEyfq4f/RK5TlKStJRYWGdweMZx5QfGHQDLgfgfgt4/+Qz4y"
  "81zwIZ6WWtsiXZqpAQOWtXssuD+bnuAsN9e2CUub09gL0b6HkFvHoBWMzAk+YPMN4fQfWl"
  "fqRnXp4iUhQSiUkkWkDJn+o+1ukeDr9zAV2dgPlpAKZGH25cc+KnH604csSIgj31yFLVoO"
  "IHC6pr32GJLLmN5k2juXnvt4YB6GsGUHG6HaWHGpGffwtqtR65uVeQt+s6vlDfQFl5KwaH"
  "A+gZAOLXHviLpWuIRHT81CP/pct27M6/g+yttcjZdhW7v6pHUfFdHC41orjEhK+17bD1+Y"
  "M9HfcBuTtrA0SLimbzF+zVO1zuGTg90zA0uXCuyorvjrWg/NunKPvmGY6e7EC3fSyonZwE"
  "BAE4U2kFUXz9rD4xUVPX0urF9DQQmAGjAJdzAo1/uKA7b4fFOhrU+iaAUe8cGgxeKBTbB1"
  "i+TCH/vKjqQrswNAx4eG4jIzx3/2wuAePjM/D5BIxwiKFBwOkE3nCfzVYgKamC5xCWFR39"
  "5Zp9JXXebu5LTz/Qx+hwzHHd7jns57vXduDFa54no51zaU88hogUFyXSLEpO1rY8NI/BzO"
  "9tL4HnNqCTd+Alc21vmM9xej181wc0tU3j6i0HduysRWhIzB2pNI1WxRWc1t/swyPenaYu"
  "ro95HZzTwvGMLRP4+YoNB0tvIyX12IeYmJyhiPD4J0TSs/z9GxTyfJJ9tCNFe9ww1cl1N5"
  "hGobtogaZYL6SmlE0q5OlvRaLVRqKI75mvYo8iCmUIC+6PRLKO/88ESkjIa0hRHh6Li03t"
  "jwiP+Z0ovJyfP2FfOrdps/xw+u/5b+waPSQ=";

/* 
 * Resource generated for file:
 *    message.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_message_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_message_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_message_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_message_length         = 1020;
static const unsigned long image_Nuvola_16x16_actions_message_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_message[] = 
  "eNqN01lIVGEYBuA/HTULc1CxRU/mFhjRIqVeJGoURYutBpXtq1S0CCUWFl20SVEXRctFli"
  "2WSWpOkea4ZLmM40SLZVFNWJajzYzjluPMeXsPDFF3HXjgcPje8//fOf+XoVJpngYEoCUy"
  "Ut7tpSq6FS/i0kLFCCGEm/iP64FaPdgpSeiZNAWNI9WwaA877WW7Bvpy51isp6KMpnR1Q2"
  "uqKGiZLbKbpoktTyNEYpEkghl1pyEVoeMHemJi8D0iAs89vWA2fwRgo0/UQPfpDOSeHXC0"
  "LsNAUwJaDvn1MzuOhlVE+1R8CPRHnRBo2LcdTphYr7zjNenpOWnpIeXTBdScC3cwu5jG2L"
  "LCC83vyvBNp4UDba51layOqugR3UO//TpsPed5n4HbOwKV9bdSaNeRCVyglc+7/snKqP6T"
  "Ba6hw3IBupenAMcmnExWW5ndrPTQlx3d/M3aDKdsZF0zNaLTVo3HTY/RbrkPTX0eCipzUG"
  "vIxtuWA4BlCdKmDWtjdj2NHbwY11pvNOCF8RU0+no81FfhekUpzpcU40Z5PnJLc1DVeAaN"
  "+kx0fN0AfJ6JBSFe75hdSUHO3Pifb0x6nNXUobChGndrSlH2ogjNX27jjfEK2k3HMdi9l7"
  "8klS3OAQwxiPb1qGV2KY36dSeh1y7r8PXnM1h7yyDLhezhJl2kY8AvJbuW+54HWGNg106E"
  "pHLXMDuP/PtLkuxADWvLqYhu0WVg8ATQl87sOjjb5kM2TAXeB6EvJww+Ysg1ZpPI11E7yw"
  "nUMfPEdVZyAPk00L+fWfZrXQiTLpZbGgdkCewJcetgLoOmk7e5IEi2G1OAH+u5x21Adxpt"
  "olXsN5n5GbDVTcX3gxISR4i3zGS6eg9RzrDkJTaHDRdXJ/uJyiRJGFZEiQ87Yz3bjs72MV"
  "9aHtBbvDV4IG/pGLukctOyPp2SKZyGKueflFmb6OpnLi2iFFpN62gjbaE1rhpldjz+GkFl"
  "jryVb0F+FEijlX+rnA/XnISSRGpS/T2/vwHdmh69";

/* 
 * Resource generated for file:
 *    messagebox_critical.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_messagebox_critical_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_messagebox_critical_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_messagebox_critical_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_messagebox_critical_length         = 980;
static const unsigned long image_Nuvola_16x16_actions_messagebox_critical_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_messagebox_critical[] = 
  "eNqlkt1Lk2EYxu/STZ17c27vbB9GafR1YBYZdqj9Af4BQQdhRdFBmUZCigUletAXmpqW6a"
  "imlAU1ZbPGNp0zv3KzoIHu451ODZLU8sAorm6TNzz34D654Xdfz3VdDwDCJucpEbUSHXi7"
  "Z+/oQPEZdIhidyNRWj3v63juEqU2CUKXo7gYT3JyvtwgOlrFe5lvZ7b7SF5waWoSmItg/s"
  "MwLAaj5z5z94gUDVqdPeJy408shEUpgraCwmgF35D5t/v2B5YnmW2txuqB7YDzFebGxtEs"
  "6p11qWqb5B3ASv87BAwZmL5+Bd+mY2g8dDgk877TZ4GvEWbTsGwiLGQpseroQmxgEGGXCz"
  "/cvQhsFzCcQuhTJmDlcwC2sjLIfKfJ7JhjjTXdhaxkzPMNyazEUs8rfHc7mFVjRE3oV23F"
  "bPsjTI+PoyYre1DmHxOJFqPJMxf4hF/2l4gyOyUSgrtU+LRTwKjALGvPPH6IWfZZs3v3yG"
  "WiTJlv4ywfEAnN6em90oAPS7aXzArw841RLcEnJkGyPEHk4zhuGQzeS0TaqxvyX+voDlFK"
  "vVr9Juzuw/f3PQjs1GA0ndk0gluXAulFB0LDI6jUaN6fZ60LG3juV2jQifaY17eelZH98p"
  "t9OgU82iS8SyTYkhQIP3+GsN+PayaT5yx7lvkmfUZXxOnET48DEwb1ul8VZ9jeyrqdsCkV"
  "eL2F0KFUYtJqRdDrRbnZ7JR5R/Fp/J6JwK/XYCh5LasEzLS2IMpaU0NDCHVY0alQwMJPbk"
  "lMRJz31tLS//215RycXIxKiFVdQf82gTtqQTwYRPWOHcOVougKj439021Wq+HkPxyXJNw8"
  "dmxG5quJ8toKj0cWYhJWJvyYDgRQm509UsIeLxKpKoxGT3DwA+Kcfzwaxe2iotmTRAUyX8"
  "tZVhLlN+TmBm2XS1GTmdnHHZnXOirjOUekKdeLdmtJCW7m50dPEBWe2pD/ZuYvKlVX7g==";

/* 
 * Resource generated for file:
 *    messagebox_info.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_messagebox_info_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_messagebox_info_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_messagebox_info_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_messagebox_info_length         = 1012;
static const unsigned long image_Nuvola_16x16_actions_messagebox_info_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_messagebox_info[] = 
  "eNql039MzHEcx/H36cdWyZ2SE3FxN5Fd0w/+iIS2Yk4RWaxGNstadv2wVH704/rBRr92VO"
  "s6thSJSCE1ZWyIflBpUa6r4ZAfue666zpevv64W+bP/nj+93m8P9vnBwDCDCPPYiKhlMi9"
  "iIifv4K1Slo8f3PVR7dd9QZBcL3B0ffyp1m8PDlxc4TEPU3kkE3EyfnfC/Kjl4Xc1IplCk"
  "gfGpDToEHqNTUSq3QQpQ+B61czRfOykhhv+Z9fXhi99lArKjomUdcHXGhSo6XjMxqfqZBQ"
  "rkKMXI2wQi14W5tB7IwkYk/zK4vcBTtu6SraDajtBgqaDMivU0Ezoce4Ro/4UgWCM5XYzu"
  "SfNg6O51Uj2aV5mTzL/fwFcZkSd98CxS0GnL2jQ2zZF2RWjiC5fAiiNAVEp4bgF98H7zgl"
  "XPf1g8XOrjF5jn+lKlw2iaIWIwobdUi8NIrTNSqkX36PY+VKhEoG4Rv3BqsPv8bSiC4sin"
  "wFmyXnx0x+aUi9we2UHoKEr0ipGkNMiQpZV0bwU6PF+IQWUWcHIdjfA35kF6yDmmEf+gh2"
  "bnKjybuK6gyr0jSgsBFwDijglzqMjakD6H33HTq9Grsl/bDf9gRWgfdB/rWwD2mFHV9m9k"
  "7rKz57nfwG1l4laHc/KOglnPZ0oVfxDRO6nwhI6ACtuQ3axLThOmaLHsCaW6g2eWtBwUVv"
  "cR/YB4dBO7tBW16As/M5ugdHodX+wGZxG8inFuR3HRabbsB+4z3Mss6oN9/fwjMezv7VU8"
  "JjH2AZ2gkKeAzn0GcYGBnF1OQPBB9lvEcVaF0l7P7uvbj0F1GKr9kvOUfklJvI29IAfuwg"
  "bHe0QSwbRs/Qd/Qpv0DeMgrHkGbm7Jpg417JgGQJ0XGW2fPyiLi5zJuUJDt4Vfx2DX8K4Z"
  "Fe8KI6sSiiDYKodjgEMt6lhFmckst4W2KdoH/8AuZfzM0isk33sWRnV1s4S8cseGVGlkup"
  "kebkqckqvY5x65mImUHT/Uz6A7ohVxE=";

/* 
 * Resource generated for file:
 *    messagebox_warning.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_messagebox_warning_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_messagebox_warning_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_messagebox_warning_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_messagebox_warning_length         = 1008;
static const unsigned long image_Nuvola_16x16_actions_messagebox_warning_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_messagebox_warning[] = 
  "eNptkn1Ik1EUxg/6bns3N82llhZ9YGoK5hLK7OOPhAQJosj/+vCPBYFQiSEVmUEWrFopaR"
  "a23HTNZYoL9TWsJZOKigxLMftCzZyZYVLhfHVuT9epMMQLP3jg3Oc8516OlYisi1BNFNu0"
  "LPxL44rIQSNRMoMWo3oRLESB1sCA0uFbJfhpLIdJIrHcJuLKWW0hlkWoJEpo25ryDx8/AG"
  "/b0bpti1hMlFrCaqULMC+gamZ+CVfhLNYD7e1Ak4DBs6dRJpPW61jtygKq/DDPvinFkbrp"
  "j9fRCvT0AK9eA0XX0ZyU6LpItOsyu6Pzw+QH83JmLvCu89IFn29saAijDJSV4fv+fbgqlT"
  "woJOJZH5qnco4Z/x2izSz7n7epAejrw4m8PBzJycG0wwHvoYOwRa+dOEW0M5/dPTfHvL+C"
  "/blZITf/uHAesD8F3G7szczEzvR0eF0u4NgxDGzUoJCXNZwkkrE+dMpvdpa9tTUledJTVQ"
  "F0dGDm5LF8rVbr07Ba4Y2NQU3kMs9xogzWg2YwzHrJpFTW9qZpMJ61G9O/R30WvV6PgoIC"
  "n/b+GkFfigaOyCU4o1A8OkoUkD3nvcXeZNfEjY8mLcVwYR4mZhNht9shCIJPTzO6S4vhUH"
  "EwRKhFLdEeBrG9khiDgx/0bo/H8I5YONnO/J2cgtfjQU93N7o6O316fGoKzoFvsGsSIah4"
  "5PKyloNESrZDaU8S49wjmjD06PLxaXwSIy4RbpZ3ODsbmVlZmGR6jPkH2J++KLoGQcahRB"
  "WEA0T7TOpQ4cuOBAyu5PA+V4t3tlp8qq9B/6NGvDQa8NxQjq/NTeiqr8ObhzY8zs3BPY5D"
  "bZAcxyWSNiFuret3xgYMboxAf0IoPseHoTtGjY41IfiwPgqd66LQFqbC01AVWkKCIPAS2H"
  "gpWhRy6HjZhEHBP7ZFr3LXxawR76+OEi1R4WLl8qViRXioWK5WiTdDlOINlUIsCpKLerlU"
  "vKzgRZ1CLl6USd3ZAQHP/gO9WdDO";

/* 
 * Resource generated for file:
 *    no.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_no_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_no_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_no_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_no_length         = 868;
static const unsigned long image_Nuvola_16x16_actions_no_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_no[] = 
  "eNp9k19IU3EUx4+m6cOgocj8g+xxCsIeROafHnxJ0R6MQM0YhLIN1EoY2PQhZyQIKUwRhP"
  "my8KUcxPBPTOHClcE0l3Eha1qY1qXoj+I1cBH92bdz51xbSAc+3Mu953N/55zf7xKlho1I"
  "78jNdblra8VHFovit9kUd3W16NBqXeo7+k/063ROweFAJBwGDg+BgwNgfx/Y20NkbQ2CxY"
  "J+rdZ5mjtkMHjk+XlgZwfY3AQ2NgBJAkIhYGUFCAQAUYQ8MoJejcaTsm5+vlP2eo/zV1eB"
  "5WVgcRGYnQVmZoDpaWBqCpiYQHR0FG+sVtwicsb7Pee3WhXMzQELC5CcTkg+H4TubmB8HB"
  "gehtDRgS2/H3s2G6LNzTgqK4OXSGkmymW/JzI5CfT1AQMD2FpaghoRRYHQ1gahpSV2r0Zw"
  "bAy/09NxSITnjOq6jEYfBgeBzk6gqwtyT08iX72e3Mvcm5SXhx/s7TM7zB2iObfJJMZcXi"
  "tGayvk9vaEl3ALCxHNzMQ39j4xr5hBonV3RYUIsxloaDimvh5CY2OKH+ulvBw/2VEYmXnB"
  "8ADXh/R6D3gmqKwEqqog1NWl1Jzcy7LRiI/svWaeMXaihzyDa3JTE1BSApSWIqjO/KTmoi"
  "LIJlPiGwHem9347B4zV4muq3v4oKZmFwYDUFAAOScHQbsdkk6HaFYWfqWlYZvXXeS5PmHn"
  "JRNi7hJ9YFUTPwNNweJiIDsbYCeakRHzvnPeV+Yz85YJM0+Z+8xloo7kM6jWEuDn6nyPGH"
  "WPvzDvme34vEJ/3V5Wzvz7D1wharhHJIuc8y7uqWtKDJ833OaaLxK1nOYmxdlLROfNRKM3"
  "+XzcYLg21wWiupN+k+MP1Xj6vg==";

/* 
 * Resource generated for file:
 *    rotate.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_rotate_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_rotate_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_rotate_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_rotate_length         = 824;
static const unsigned long image_Nuvola_16x16_actions_rotate_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_rotate[] = 
  "eNqtk2tI01EYh3/nvzk33NzFOacpiVtNLbJES01TCTUl/zrddK5N7aLYxRQJUytbRuknv5"
  "SCZmFEFJSfMoxuEpUFQUSh3UAhyUoL+tAXrXg7Rl4QgkEdeDgvh/O87znv4RAR6B+BE4Ad"
  "Wv0B1aWU3shp313SY9gKhiIIfF0CG8cOyCqkgIPvLZEAhfIF347AkEPaB553drpMtZTUY/"
  "kcuN+/29ioORfcqOk1NqjPK3fLm+FC9myepb6xQXPzyLiNTn2roLapUjrxxUnNEzbyfCya"
  "p340j3L746b99you8PMYFvvruyw/22e208G3Dqp/YyfPhJOOT7kWmHRTywc3tX4to+rXOa"
  "Sv096C6KOd831L/U7mDmygpkleh9cte5JOeTcSqWAwmQrucm5vpKqXW6huzEZN753kfJxG"
  "Mpfy6JwvuBWQuJRtaVdjqXIsi/S1QSMoUzqRLD+NJHmXtErt0lTpBvLvJFLliJX2jIpkag"
  "n/NOcznQCoGFiqyq2uDL6GVFUKC+A98mEiZKxE0PNYwfwMNaHDJc8yqHxYpNjuVT/m+w/w"
  "h0Eaf61CPouQMCufZ+MOzhlOPhgTlaL+RfajFCp8mkWrO6JmlvibOTs52zhuzmyOTk7P71"
  "gQrMocw6tNgwmU+TCdzO0rFvt/G44/OQGJBArH8nux/Wspgfc0rDXCG38HZx+/D6RxRiiK"
  "TfdXXomm6OtxZPCEe+0LEVpIrVGQ5ZuGQi6aKawvhtSHl333wq/g1CA0ACxjDYTMyCHVWR"
  "1p+nTkWx1KXvjFnHIEGYCEeCB+XRbLtjxnVvM4EmPa6T/83V+BfIkV";

/* 
 * Resource generated for file:
 *    stop.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_stop_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_stop_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_stop_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_stop_length         = 980;
static const unsigned long image_Nuvola_16x16_actions_stop_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_stop[] = 
  "eNqlkt1Lk2EYxu/STZ17c27vbB9GafR1YBYZdqj9Af4BQQdhRdFBmUZCigUletAXmpqW6a"
  "imlAU1ZbPGNp0zv3KzoIHu451ODZLU8sAorm6TNzz34D654Xdfz3VdDwDCJucpEbUSHXi7"
  "Z+/oQPEZdIhidyNRWj3v63juEqU2CUKXo7gYT3JyvtwgOlrFe5lvZ7b7SF5waWoSmItg/s"
  "MwLAaj5z5z94gUDVqdPeJy408shEUpgraCwmgF35D5t/v2B5YnmW2txuqB7YDzFebGxtEs"
  "6p11qWqb5B3ASv87BAwZmL5+Bd+mY2g8dDgk877TZ4GvEWbTsGwiLGQpseroQmxgEGGXCz"
  "/cvQhsFzCcQuhTJmDlcwC2sjLIfKfJ7JhjjTXdhaxkzPMNyazEUs8rfHc7mFVjRE3oV23F"
  "bPsjTI+PoyYre1DmHxOJFqPJMxf4hF/2l4gyOyUSgrtU+LRTwKjALGvPPH6IWfZZs3v3yG"
  "WiTJlv4ywfEAnN6em90oAPS7aXzArw841RLcEnJkGyPEHk4zhuGQzeS0TaqxvyX+voDlFK"
  "vVr9Juzuw/f3PQjs1GA0ndk0gluXAulFB0LDI6jUaN6fZ60LG3juV2jQifaY17eelZH98p"
  "t9OgU82iS8SyTYkhQIP3+GsN+PayaT5yx7lvkmfUZXxOnET48DEwb1ul8VZ9jeyrqdsCkV"
  "eL2F0KFUYtJqRdDrRbnZ7JR5R/Fp/J6JwK/XYCh5LasEzLS2IMpaU0NDCHVY0alQwMJPbk"
  "lMRJz31tLS//215RycXIxKiFVdQf82gTtqQTwYRPWOHcOVougKj439021Wq+HkPxyXJNw8"
  "dmxG5quJ8toKj0cWYhJWJvyYDgRQm509UsIeLxKpKoxGT3DwA+Kcfzwaxe2iotmTRAUyX8"
  "tZVhLlN+TmBm2XS1GTmdnHHZnXOirjOUekKdeLdmtJCW7m50dPEBWe2pD/ZuYvKlVX7g==";

/* 
 * Resource generated for file:
 *    thumbnail.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_thumbnail_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_thumbnail_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_thumbnail_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_thumbnail_length         = 1048;
static const unsigned long image_Nuvola_16x16_actions_thumbnail_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_thumbnail[] = 
  "eNpNk1toU3cYwOMqLYoXGGMPPnRrsQ10dCqCsAsOvCIU9yCMjrE9rE8p1G4+jEzqGI7tbe"
  "7yoE1za5rEJjlBB9FSXWPnUEmTxrajmFuT9L5ePCe9zNTZHH/757A2PfDjO3zn/Pi+8//O"
  "B+iMxq/TLpcr53a7ZJfLKTudXbLD0Sl3dhaxyzabRbZYzLLZ3CGbTB2KyWTKGQyGcYRbRD"
  "gUr/GxFJl4nHQiIYiT2SAZJ5uKi+cxsmMJCgXo6upiw/f7vWokMsqRT9s52XaLs98F+PCH"
  "WzRcDnDCGOD95gAHGwO8efw2lQeuca8/guTrVjd9cf/gYZR3Lg/z2R1o7YcL98HQB42/wb"
  "F2eMuosveceLkmyu2eR/h97k1f8narofAQjdeifB+BK4/h5yH4MQrfPICmHjh1tYC+9QUV"
  "74a4czeE5C35Pk+3OhAeptkRxToG92dUolN5boy/pCMJX/3xL+e6Cxz+FvaeGeZu34DwXV"
  "v862p4cATjzRg3JgqsreXh5ToPY9O03YzQePEnGn4d5Ogv8FrDAL8Hw0ierfU96qDwm9t7"
  "+eTLL+jt7dHm0dT0Mac/N/DR+Vaqjhzj0IXHvFp7luC9AXxeb8n3+dXhoTBvVL5OeZmOD0"
  "4d52pPkAOHq9AfrKO6/hA7tuvY914LO3eU09//J5Iklc5P8quh0CN27dqJTqfTqNizh/KK"
  "csq26f7PbUNXtpvtZa8QDPbh80lb6vvUkZG/qK9/m6rqavbX1FJdJeL+GoEevV5PbW2NyF"
  "VSV1dHOBzB4yn1L/5TdW1tnWQyQyKRETGrxUQirRGPp3nyZEyQYnQ0yfLyc6xW26Zvs9nV"
  "fF5Flp/x9OmqxsLCCvPzyxpzc0vMzuaYmckxNSWjKM+xWCybvt1uV1dXXzA5ucDExLxGNj"
  "tHJvO3YJZ0epZUalr0NU0sNsni4jPhl+qLfdPmtbSUJ5fb4B/RT4nFxRXBquhlhfV1cDhK"
  "+3PpUtukmMey2+1WnE6nhtgvxeFwKOJsFPF9itVqVSwWq2I2m4v5pZaW8zNF9z9G4ed4";

/* 
 * Resource generated for file:
 *    view_bottom.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_view_bottom_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_bottom_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_bottom_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_view_bottom_length         = 1140;
static const unsigned long image_Nuvola_16x16_actions_view_bottom_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_view_bottom[] = 
  "eNp9kQ9MlHUYx98oZ2st20BrttmaMk1QECy1OdHSWaYbJiUnBx7Hn6Ljv0iigWFMwzmdBf"
  "4BcZHvYA5NSkQ4Aj2B1dpCNhcBQ42rdsfp2/Hy3r13x9356YVya2352z77Pnue3/P7Pd89"
  "UTH7bxlzG5zb3xelhHRRik8Vpc0GUXozWZTWJ4lSXKIord4uSisTRCl2myhFx4vSkncanM"
  "8vO+IQhJRNhsJLvqoB2PMdFJkh9yp8cBmMzaBvgvcaIV6ETfWwvg7W1EDcOYjOu0nI48n5"
  "m41NcsbZ+xirbaSftJF2woZR01RNU7WcocrGzi9spGiaMq12Eqv/ZIG+l5AZaaa4xPNye5"
  "8TxeXDNYX7b9wPUX2oqleLp/DgUVVGbCovJ11HeCLLtDqxSe7+ReHR5wEEA/gnJzX1Murw"
  "sDD5BsLMHNOqxIuyZcD16O7gA/z+AF6vj+Ckl9tjXsKTexCeyjet0DXLbTdlXOokivshvm"
  "k/U0woXuQJFVlWkZQgTsXPwKjCfL3WP6vItFLfImd81kfxYQu7Ky0UHeqiqKKDonIzu8qu"
  "sKu0hd0HOsnb20pF7nEqcw6TWtDC0wk/ITz3sSlGf0U+dnEUc/evmHs0uu9ittzGfH2E9q"
  "5hWttu0XisnobTXXQc2MmNinjqa3t4a2sVIXP3myJ2tMqWQc//evcr49i+2Yf90kF+O2vg"
  "XoMRtdNE15Fo5j5bnLloR5vmf2L6biAQxOfz4/FoO1Q8TGj+7b876PuyiuFTOsaat+I0b8"
  "DxdRRJW0r4cOaWjxbozHJHv/zPb0ENbUcBrxZO4r5/j5GmT7Fe+ARrQxr4KrV6vjbPKq7V"
  "vYY1b87gQoPFfbpjnP47Kj8Ou/lhcILvB2R6f1a41udArK7jq9IyRmqSQCnT3kjH3vgKRw"
  "t0tMQv631R1+5avu8uEQVDLMobIjxniJeyh5iXNcwLWXcITbdSWFKjzZFN/+cbGTyzFmvz"
  "CoqzC3l1dolRiDlleGx5bbkQU1sqxP6HmPo9z4QfOnjZ9MYfR9etbT2X+brtwt5t4+Vr1n"
  "07VjjLnhH6dqwQVS0Ii48LQoRGpMbSf3NSmDO/VDgTGba4MGR2WPvGeeevvrukM/PJuDDr"
  "UiEyP3TDjL8Ac3nIAw==";

/* 
 * Resource generated for file:
 *    view_fullscreen.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_view_fullscreen_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_fullscreen_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_fullscreen_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_view_fullscreen_length         = 1072;
static const unsigned long image_Nuvola_16x16_actions_view_fullscreen_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_view_fullscreen[] = 
  "eNqlk1toXFUUhoMKTSSkim/SBx9agoWCSEFEaW2aW3WStLmNkYKtSh9sQmulaqFYqWAljZ"
  "RKsXia0KQkoTOdxEmTtCaaTOJl0guCL23VokY6ucz1nD3nzJmZfWbmc6ctgopPbvjZrMX6"
  "+Nda7L2u/NCtpp1nHJdbk7XNmqxq0mTFDk1u3q7J5+o0+YxLkxtf1ORTtZrcUK3J9ZWaLN"
  "+qybWV3U7ZmkO/7d7nNfv+gKNBeP9beDcAB6agfRL2XIJdF6FtGBq9UDcANX2wuQeqPLCu"
  "0Z9s2H1e7OqO0nxa55Veh7azaRpPLLKjK8R2pYbjIeo6Q7g6F6n73Kb+jEP9pwZbOmM8Xj"
  "MkXmgZEF9cNYhOTXKz6wA/Hv+Q+EIUPZlVSmMkM0pZjIjBwomPCX3UgfhqBM+VFI9s8onn"
  "3R4x/oOqOfk6d94qIXShl/868SEPSx2lxE+1MHxVsrrCL551+xRvEntnD5Ge03+rLxQK5P"
  "MFpHTIyhxS5X739XPzYCu+OYvSiotiY6tPjF7TcebnKcjCfe4em8vlcZwcmYzETmWw7AzC"
  "yiF++pkL38d5eOuoeLplWIxcN/7lu6IVNpt1sBVnmjaGYRFPWDjSxhs0KNkyKja0+oX/n3"
  "x+hc3fZ7OKVXs0UsRiSSIRgZ1OMfidTknFJbHePSaGggkyS8sUcvzlK9W8ti2xLBshrLts"
  "OJxgKWaj/3Kb/qkIxZUTorztsvDNCW4d3ktoePCuf1btK618LUv5ihTxuPIN6yybBW57hl"
  "hod9P7dZRVVVNibduE8AZtwqde5U5HGYnxMRzVg51WMydT6LpJNCpYTqS54R9jft9j6Me2"
  "0TOhU1wTEE+8PKn6V/PPfYn5WTvJk0chqeJchpwlyAqdtIqNxSVufHKEefVOkmO9eAJRiq"
  "sD4snXvjHb+xMcG7f4YMThyIjF4fNh3huMcHAgwtvnwuzvC9PRs8jeczpvdKd482yCmq44"
  "D74UNB+t9vy6Zuess7opIMuaZ2Rp04wsaZiWq+qn5UOuafmAKyCLtk3LotqVe/aeqmZUPO"
  "sUbfKqn0fR/9GfrRIbsw==";

/* 
 * Resource generated for file:
 *    view_left_right.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_view_left_right_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_left_right_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_left_right_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_view_left_right_length         = 1008;
static const unsigned long image_Nuvola_16x16_actions_view_left_right_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_view_left_right[] = 
  "eNqlk3tIU1Ecx4UCtcLq3+iPoEwSioigQNB8zmriWwn6o5KyVNCKHgZK1B8VWv0bN7OHZW"
  "66udCy12aWqVgiGaJSzsfeu5u7595tujO3b2czCXr81YEP5/4O53PP48uJjaseyz981y8v"
  "5mhmAUfT8zmanMvRxByOJmRxdI+co7sPcHRnJke3Z3A0Po2jcakc3ZLW4I/ZWK0/WqmUHs"
  "4AV/qB2l7gYg9QpQUqXgOn2fexTuCQGshTAlnNgKwJSGoE0hVAbJ5GzD7aQo7ccyCv3ojC"
  "20bk32TcMiO3zogdZcOQXZ1Gdr0Z8htGHAxx3Qg5I7nOgQ0yFdlX8ISo+x2YI/Nw/UQQKQ"
  "xGASUl9zHy1QRBomxsPgxhiJIXij6CdYmtJKHwKekaJvi9iWxeWWUL9NOOcB0MBOD3L8Ln"
  "o6zyQTPkRkySiuwtUJDnQ3/6AtvHqapWfNfz4XphgcLrXYDb7QWoB+2DEtYktZPdha2k47"
  "PwV//kGRW+6dn6wWDYFUUvBMGNgFeCaoBgVcozsqtQTZ59+rtfek6DiUkegcAiJGnJdTpF"
  "+CQXlB8FRCd3kO1FGtI++A//fAfGv9lB2ZkFwQOHQ4LNJsDjcqL5gwvRKS9IfFEHUQ/88g"
  "Psnpb9E9WdGJ2wwutZYK7IXBdMJicIb8fjd05Epb4kW4s6SVv/kh8MBkDpYvgfoRyPX+rC"
  "yJgFkugJu2azAzMzdjgtFjzQ8ohMfUM2F3eRtoFlPxjOKJRVKOvjNa/wZdQMUZBgtThhMN"
  "gxNWUBbzDgwVs7ItO0ZFPxK9LWG8p4keFnB/CF8513SyiteYGJcQMCbgGi3YY5swn87Cy8"
  "1mkotFZEpXeTbSXvpfKmOVzT8Ljc5kCtgkeNkseFZhsSzo2g9I4RZx/ZUdFoQ1mDBaWcBe"
  "V3TZDVObFC3ietz1BMbjzc41+bp6UxuTq6OkdHo7N1NDJLR2MKeuhKeTeN2K+jEZmslzEy"
  "GGmMzB5/RKKSvTxE/A8/AO6LJqw=";

/* 
 * Resource generated for file:
 *    view_right.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_view_right_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_right_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_right_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_view_right_length         = 1156;
static const unsigned long image_Nuvola_16x16_actions_view_right_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_view_right[] = 
  "eNptj3tMU1ccx4+o08SYmYkO/UOTidEJWgXmK0Z0k7g4H8RnC0IqhfooSq2Eh1tRsgSzuZ"
  "hsgmIVI+sNjqApAkMoFhDUOLZAFQMUwUcLtqB3eNve296+vrsF5sy2k3zyO+d38jm/7xFF"
  "nepMOVY2su8gRe9Opej4AxS9VUrRXyZR9KYEio4VU/S6fRS9ejdFR++i6OXxFL10Z9lI2I"
  "ofhglJ3iJV6fjCLiDnDpCpB47dBg5WA/IaIK0W2PsLEE8BW0qBTSXAeg0QqwWWZ3QgZGKS"
  "cmtKBZN29Q1SiqxIvWiF7IIVcs0wtn/7FKvT/xD6NkgLrUgOcj5YbRAX/Ynw/fcRMlmmiB"
  "WXM/XtI3A4eTiDsDxYzouaaiNUyjIwjAsc5wHLugVccHEc+qwcPk1sBpl0WLFOXMG0djvw"
  "79XY1IOT3+gQ8PvGGkL1ejxCdePlsAuLklpAPjiqWCu5yTQ++a/fYDAhR10FN++Fx+MTMg"
  "TzucBzLHoHWSzcfw9kmlKxUqxjDJ3/4zeakH36V7jdXiEzD4eDg90FcHwA3S/tWBD0Z2Qq"
  "osRVzJ3H//iBwLjf9BTZ+XXCfB944ez0BDDQ3oahtlY8tnjwcVInSGiuQiSpYfSP7O98v9"
  "8/WvV3+5FdYIDTwcLyWxMsXS/Qrz0BizYVXR2vsGPPBYSEqRURCbVMvdE+PjsAr3fcb3mG"
  "nLOtoAdeofvnE+i+mgfTeQlelCTCppPBcFaEuTOy5IsT6pi6jjHf5/OP/nfUb32OrO9b8G"
  "ZwGMbSQvQWSzBUuRMj+ji81omQuC0XR6Zsyw6X6JkGI/N3egHP6K75dwsy82sxUFkAy83T"
  "MF+XAfx3wo0S1ltr0FSyFuaM2T2LpHfZSw1vYXzGoa2XxcMeO9r7WRRXmZF86gHKNdegVe"
  "ehT5MIOPKEN1Jhu/4Zzh2XoCZ+xf35knpnzNfPEXHchMUZJoQfNeGTdBPmHTJhzuF+fCQz"
  "Q5WrQV9FOow/bUbPlQ0wV65CVroKK2flppCoYumEmMv5JOqymkS/R0yQ0pzpC88UVCu+GD"
  "y3cUOtVv659cbJXW/z12+sGlJ9aEub+VU0ERURsuRHQiIEIgWWvc9FMnuBmlyJDF2iCpkV"
  "Wr95XvntPUsN8qmxoeZlJFI5M27yX1q5y+Y=";

/* 
 * Resource generated for file:
 *    view_top_bottom.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_view_top_bottom_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_top_bottom_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_view_top_bottom_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_view_top_bottom_length         = 996;
static const unsigned long image_Nuvola_16x16_actions_view_top_bottom_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_view_top_bottom[] = 
  "eNqlk11ok1cYx4sOqhbqditeCPMDBcEL5waC1Tb9mEvXNm1XhF7oBg5m7bSazaKITlBnLd"
  "v16wedsR+Jse1iqfWjqa3SKsNaJropOLc2Nm2Sxpw3Mel73iS/HSvqjaDgw/nB/4Hz8Bz+"
  "f86SZfV/lVefMK1Vmiyq0GR+uSZzyzSZU6rJtcWa/NSqydUbNbmqSJMrCzS5wqLJZXmaXG"
  "w5aWYvrP9ny/eu6G//wU9DsP8G7OmHOi/UXIat3bDZA5vaweaC4hYodEDOach3whJbp16y"
  "pU1sPhXCdtxH5S8+yht9M7pMUaooafBRfMyH9WcfXzznqNKKDQ0hFhSeF+srmkX7UIiwSP"
  "D0JfprIvq0IvEKodCjcZyDgg/XnRNrK1vFxTuCt1U6lSJpJpGGVJ1B5+0Y2TnnxWcVTtF1"
  "+83zqVSaZDKFYZjE4waxmNqtPyNtxGi/pZOV0yE+qTyn9uu8U6VTpJKmEiae4QTzNnjEmk"
  "0d4uDZR7gvP8TZ84C27r9p67pP24V7tP5+l9aOP2l2D3PW+QdnWm7R5BikxXGN3b+OkGXp"
  "Fmuqu8TXDSPYG6/zY+MAPxzrx360D/vhq+w+dIldB7vZue8CO+o7qLW72b7TRV1tE7baK8"
  "wr6BHLKz2iZyT2Lo9Xx8SUhtIJPHfizMntEUu/6hLuociLG+kXfklpkkjIGb+EeEY4rBMI"
  "RBgfn2J0NMiUf4Iz3hCZeVfEx1UXhfvm63lTZWSojOLxaaLK66fhGMFgBL9/irGxAI8f+w"
  "mOjdF0NUCmpVcsqrok3DdCajo546sKB2QCpmMkYzqGHiEeDqEHJgmPPyE4Okp84l+cvRPM"
  "ye8Ty78ZiG5zhDnSGeSAO8R+V5C9zgB7WgPYmwPsckyyo2mSmtOTfHfSz7ean20nnlDYMM"
  "Vs62D0owLno4XV/eZ8W6/MLvPKrFKvnFvilZlfeuUHVq+cZe2TGZ8rihSFigKF5Xnfb2as"
  "c6mfR8b78D8zpyAz";

/* 
 * Resource generated for file:
 *    viewmag.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_viewmag_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_viewmag_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_viewmag_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_viewmag_length         = 804;
static const unsigned long image_Nuvola_16x16_actions_viewmag_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_viewmag[] = 
  "eNqtk19IU2EYxr/mdo6BZRFDItaFXUh2EQoqEXTRSJqVRSR6IdJdIHjRlO2mVFpEmWkziD"
  "ZPOS2Y0hb93z/dUpcbOpvaNC+WU1OjdGKpzTXp6TubioRdSD3wg4eP93fO+3E4AAj+kdJS"
  "OVEqlaTqxnVZS3Ozw2prXbS1toaNRmM/V6+5oFarSXFxMeEjk8kIwzDRvurL5RdJza2bJV"
  "aH8+dA4Ctm50OYW1zC4HgQlvZuNOoauMLCwjjeUalUJCcnhwiFwjW/ovzSsRe2jl8dgQj8"
  "34CZEBCkBGjvmgRedvajID+vjPcTExOJWCwmLMuu+RxX327wTMM6CvTQ+cFpYIjimQLaxg"
  "CjL4LaursTjEiUQNZl1dcbni3Ud4fx+ANg9gNvRmNYPlKXnnF9QIPBij27k9LZDf2nP3S9"
  "YWjeAY39QLMvRhPt2l7qDtD+xML7hx5RL/4PX6u55zK9D6JlmL7LG3N4+K4fonv4l1Grvj"
  "NLRKIkO/XqVp6x6p/JPXX6udkOF72v/RNgonu/prSNA+4v9E5OL6RHpdWHqWOh6ClX1vnR"
  "73o8+6rZ7oR3YgEDM4jSNxXCK4cbBpMFty+XmX27BNlmOvtwZYf1Pp8DqfuLFAqFR3u/YY"
  "HTNS1VVFaOZGVlllefkOomPVX4bj2y7JBsz2+ks7Ub+CuJYxnRvq3xbCrtO/iDPAFJHi4S"
  "foY7E/NduRGjZFt+zd/9DZNMSJrvHDsFVwbmnCcjD1J2nt+Mz0eyhRzsOcuM4W0GDCWpI5"
  "v1+ewVkPRraYwpJSGuAP/h3/0NMZsH9g==";

/* 
 * Resource generated for file:
 *    window_new.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_actions_window_new_width          = 16;
static const unsigned int  image_Nuvola_16x16_actions_window_new_height         = 16;
static const unsigned int  image_Nuvola_16x16_actions_window_new_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_actions_window_new_length         = 1092;
static const unsigned long image_Nuvola_16x16_actions_window_new_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_actions_window_new[] = 
  "eNp9kXtIU1EAxk/2hKAC7UFBESU9tFazN5E9KXqQlObW1Oacls3SZlQWWhIUUQSV9rDs5S"
  "URC+1BpWVvKfxDTcs5sdfKNh83u7vbvdvd3b7OtKIXHfjxHc7hd87HOQrl3nrd1iud0RsZ"
  "NlLPsBHxDLtSy7DLYhl2sYZhw1UMOzeaYWdFMmzYWoadEsGwk9Zc6Rw29UgbIXHLtcYSd0"
  "4DsOs+sL0c2HoH2HQT0JUCMcXAukIgggGWXwIW5wPz8oDwAmBKag0CesamrdQVc4nnO6DL"
  "tUJ/yoqEk1boaMbTjKdr2hwrNpywIo5mXFfaoMr9grExlQjonWAIVxVxZdWd4B1uOPw4u3"
  "H+QHBDEFx07keEKAhotgqYoHkE0ivZMFdVzD018fj/8AFeGR5JounChzYR42KfgPTZYpij"
  "vsY9ePVv3+v1QZZluFwe2sHfT4RbcKKpxYngmGcg/dMMM1QlXEX9777P58cHj0eG201d2p"
  "3nBdhFQHD7YPpgxxi/P2i7Qam6wd2v4/9yZdnb5YouCS665pB8+FRdhdaqp6j7KGFobD1I"
  "UIZBob7Flb+0/9LZ2+VKkgcu6vN2BywvHsBieo83Ben4WKBHQ81nrI46iYBhmYaQ9be5sl"
  "r797t9310Zoih1dW1vscF0OR2mC1kwn1Djfb4GtpIEVBxWYPigHUnj19/l7tZ0+z87i/St"
  "eBF2h4TWlnbUXMxB02k1WkvXoLN8CdpLFNCsysDmvqt2jlWXc/dquR/tKfSPZBedSnB2tK"
  "O5eD8sV/fBUpgAuA/R/TRYr8/Gw/w5sKQOaRynfew8c+8rat8KqGpy4kWjHc8bOFS+5vGw"
  "ug1Mbj4uZ2ahOU8D8Fn0DD1shdNxdJsatyKmVo5Slzmm7XmHkG1mjE81I3iLGaNTzBiZ3I"
  "QRyW8RqLfAmJFHe6Sg9vhSNJ6bD0vpTOxIMWLG4AwdUZ7W9ph2Npsoz2aSsD9QXto1IPjg"
  "gZuGRS1HF8y/XZC00Hp199qv2fMW3Gg1DrQlBq4II4pcQiYeIySEEkqZ/CunyJAxmeRcaN"
  "BEY8DgoLKlI4vuRE2qSOoXHmSZTELTApf0/gbXtN3A";

/* 
 * Resource generated for file:
 *    ark.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_apps_ark_width          = 16;
static const unsigned int  image_Nuvola_16x16_apps_ark_height         = 16;
static const unsigned int  image_Nuvola_16x16_apps_ark_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_apps_ark_length         = 1188;
static const unsigned long image_Nuvola_16x16_apps_ark_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_apps_ark[] = 
  "eNqF039MU1cUB/BLYZmhjrdJBRJEN+NCWyj+2I8sXaEbzCgG1JS2UKihIEWgEIUWSl+h2q"
  "llBCTbyqISRQduwRCiWDBuuGRumolaUt0CakVEJVuoZkFUQjved/fFxWR/eXNPbnJOPjn3"
  "3OQCIFqt9mUUFBTI+/r6ZiorK28RQuIjI6NIhamTpKfvJDrdHmIsdxFFajZhmDdJeDghoD"
  "5HrSVqtZqoVCpSW1t7dWxsDG63GwwT1Z2YqCClpYdImqKCaDR2Umx0LpLLN5CoN5iXXp+v"
  "I+q8QpKn0yfXVO+at9lYbC82QKlUPi0sbO6ysScHrGz3sKtl8O6Br399rMmtu7hYKJQKBC"
  "/8iaq3SXWJmhj0eZoas4UzmcphNltx8OgQzl+aw08XQxj6ZR69/TM4fGwaX7qnkZ1dG3j9"
  "NYGY9+froonXHkP25SbqrI4mrsHxOVwHjuDb7y/BXtfOqVTsM3ma8U/Z6q03xWLFWFnFj5"
  "zTOYnoJbFHeX/OvCR3pG3d4Gh3zmPPdy4camHRvncXTrpN6G/dzHXUfPi0epPoilhENkUu"
  "jkrepu8JNtjvI2ZpwgDvvQc/nubGXcC9ZoT8+zFzxYrAOQOe+ByAn+Yf7Ke1MtRkMf5ly1"
  "d/YCw5G7TV3+F9P+99J9RPEGgGfHrg6hZgRAPc2kmtERhVATdpbioHpZlvBeIT1mZsL/6/"
  "9/aaZvH8NHCbBa7lABfkwO8FwB8bqaX+QQnwqArbPhNNxSfI0oqKzgbr68cR+58fGfhiDr"
  "gDBLrosQe4TvuOVwEPy4G/LMAzev/5VmiUcZPLV6xJMRj4/rxf9qK/pzUI0I3bwOwpOmsr"
  "ME3ned4ELLhpvhPcrBubP1o6IU1SpOXne0LW+gnExiSc4f0Wxaoel9XwaOj0N6HAffqksz"
  "S4XgTn2vHQ/xV+9rTB7XQha735n1Sl8++iIh92O+5CFB3n4X1q6lbRujXyfe/LZENNDSx3"
  "3N2IU90O9B3rQUfbBey1j8BaPYrdjZNwsPfgpJGVaVkIDxewvG9p6frtjOcyXE3HF9RaY8"
  "hisUKnK+RWrsyYeHdV5rBEssGbJF3vTZJ86pVJP/G9syJlOCIiopH+r0W837HDdqOjYxBl"
  "ZY0QCoWdGRnpfolEOkXryeQVi/cME/2eWLz2B5EorjcsLCyWYZgYWkqhIXiV/xcjEQzH";

/* 
 * Resource generated for file:
 *    bug.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_apps_bug_width          = 16;
static const unsigned int  image_Nuvola_16x16_apps_bug_height         = 16;
static const unsigned int  image_Nuvola_16x16_apps_bug_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_apps_bug_length         = 960;
static const unsigned long image_Nuvola_16x16_apps_bug_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_apps_bug[] = 
  "eNqFk1lIVGEYhr9zZj02jmO4jc5oDm7ZuKVGF0pupDdluGCmoYVgggpqIIhLoJSFXQReGN"
  "TQVQiJl0EXEhUSEaER3thiYlBYlthiVjNv7ymlrvSDh/Of//vfbzv/qReRU+QkOaEoUqGq"
  "Usv1iNMpF91uSZU/ZiVVVk3zWs1mO9duEqY76v/T11FfSarpG7TbT46mpIwMJCb6qmJjb+"
  "yPjFzIyM1d8SQnL5qMxlEedxB1S9+ox1IUb4mm3erNzv4439f3a6y9HR0tLbjt8+H58DB8"
  "ZWU4XlMDt8ezxuPerfx67sMil1xW69eMnBxM9fUB4+OY6ejAQGkpLnd1YXVqCujuRndMDE"
  "w2m5+SBl1fJ2LuF5nstFoDNUlJmKiuxo/WVqCkBOBZhIbiW2YmvvT04NfQEO4lJGC3yGdK"
  "83R9p0jvC5GAPyoK/qIigDVi3z7AaARUFYiPx3phIc5kZaG/oACv0tJwQGRWOCeFXBeZhw"
  "h+BAfju9OJgMMBKArAd+TnAw0NuF9eDpfXi0PZ2ZhmPYWqOidmczX1YRUiH65Rv0TNMp9+"
  "5n1tt+Mtc6K5GWhrw93KSjjS01Hl8WCaNWXa7T/FYplk+REekWV+TDzk/np4OB6lpKCY1O"
  "Xm4n1TE8D5f+IMO0JCcIexbxoMiI6LCwTZbIN6/42KsthD/WPur7lcuML+7Hl52JOailnO"
  "DXv3AkFB0Ht8Rw4qysIup/NpdHT0AuuPP2KxvJ9l7c/oWzCbMc2+8xinhX1+1edCVslLcl"
  "pknUOrVUwmt6ZpD1RVbVcMhuljIosT9M+QN0SPtURWyBwZZ9wSVf2siJyVf6bfv8TNuxzB"
  "ez7axFkOi/h9/J5XVTVwjnUfNRg2XJr2XQyGUdnGggnjRxj5GzFwl81kmgxyODaoG6PrPC"
  "neTq//TOomFn1DUS6QJ1w5N4+Yd9Kb/tawZXq+QtnBfgM+mSK0";

/* 
 * Resource generated for file:
 *    email.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_apps_email_width          = 16;
static const unsigned int  image_Nuvola_16x16_apps_email_height         = 16;
static const unsigned int  image_Nuvola_16x16_apps_email_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_apps_email_length         = 944;
static const unsigned long image_Nuvola_16x16_apps_email_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_apps_email[] = 
  "eNqlkV1Ik2EUx5+5zelSMa1pHyAZoUQLUpzp5kdNyC6kmyQSXOhF3SaBJJKZWBcSFUmpm9"
  "PsTsEIhlGSSuVXZQr50cyZKeqcc1Pnx9yH+3feKSqS3XTgz8Pzvuf3nPM/BwDDfygjQ8tS"
  "UivofMnS0tQsJbmCKZUvWHJyDVPItSwmVh0SJ6vJV2W3zSQmlI4xJopg3uB7tRcfH18ZkJ"
  "CgLb2cqZuurTNgYAAoe/wbgUGnqv7FKxTPfBRyTfHVLJ2pUm3A0E8HFhaA1nYXOr8DyrR7"
  "FgLDGONt8UnJz9nF9FqxUql5oMrWzamrRzHwwwkrcevrQO+3VTR/cmDcDDwpH4RQeLyMbQ"
  "bxkgvp2tLcXJ25upY4vRuWeWBphVg3YJ514V3zEvQGDyaNQP8gECe7NUVoEMerVPVjWm0f"
  "hkccsK9t1NsZ3e02qm+HcQYwEr9M75bc/+zx8TlcwPE5OXVLjU3jqH89gsZXBnxom8TQkB"
  "UzRjuG9St0X4DZ7IHFAq+cTvLT50JU9HUD4cFS6RVNU4sZfaNOdJDPjx1WtLaY0KQzejUx"
  "4cDyMmCzkaclwLG20VdRSbeHxzt6UyAIj87La7D9mgJGx4GpacBqpfxF6nXZ42U5rdoBz6"
  "anKcotvNsDf/Hpt3x+IJNKVQ0dnTaY58gj8XN0LhK/Ql7t9u2ZWOi7hnYqkxW7RaKoPh6P"
  "f0ksljA/v8jYojtv7Fx/87Qzbt9cTbd7g+PeU1fpkZRU5PL1PdFLvq+R/Lj5ifcdYQJhCI"
  "s5c+P9QP8aXK5tzjzrgVYzDHlioYvPP/aF0rNJArYj/PzDma8olAUExqQ8etjl4jiTiavX"
  "D7n8tlMgiPxKaVnbBIfztm6SsFgmkcSwAwfPsnOp+Z3lT3ugPF/g5PMjuuh35u56u3l//x"
  "BSKM0gmIlE+08KhIc0f+tzL/4P7GcdeQ==";

/* 
 * Resource generated for file:
 *    error.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_apps_error_width          = 16;
static const unsigned int  image_Nuvola_16x16_apps_error_height         = 16;
static const unsigned int  image_Nuvola_16x16_apps_error_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_apps_error_length         = 1184;
static const unsigned long image_Nuvola_16x16_apps_error_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_apps_error[] = 
  "eNo1k21MW2UUx8+lL9iW9t5e+l7b0nWstSOtbWkZCm4dAzcMZvuwLFEJGUJq/DJNCMmyaA"
  "IqRIwxZm46jTiXaHV8ISTMCNmWqInRKq1hOrO5NVPnHEI3lUCrrn9PYdzk9+He+/zOc895"
  "/rc7GqWecDj5utW6MCZJt4OS1O/R68mn01GHwUDP19bSS6JIIxqNKS3L2VmXq/SoQnEyTE"
  "QS83gkknzFar29sHcvbh04gBG9vrTFYEjdq9Wu+c+xP6zXm97R6XI/8vs7J07gy0Si3CUI"
  "71cTVb3qdC4u7dyJO9ks/snl8FtXF0a5xmattm87+0eMxpq3DIZsdscO/D09jdV8Hhgfx1"
  "xjY9kvCKPDJtPyclsbViYmUJiZwXI6jXx7O17U64uPSNLh12Q581U8jsVjx/AX+4XJSeD4"
  "ccw3NyNANLvZZusbMhpLC4kEbg0PY4HX/TEyguy2bXjPaCzPBIP4dWAAi0eP4ubYGFYGBz"
  "EXi2G7QnGD22/3WCzkNplSL0hS8XpDA34/eBDXDx1CvrcXmWgUF/ftW7v/OZXCUnc3MuEw"
  "HrrrMuQxmUg2GskiSX1DkrR6sa4OPyWTyHd2Ir9nzxpXd+3CZe5/JhBA87qbpLvXA14vNb"
  "ndFHU4qM3tHhy328vzsox5jwff+3y44PXiu/p6fLN1Kzqrq5dUrNSyZ2Y0zJPxOPVzBvpC"
  "IcOQ3//1OUnCF4KAqaoqpBUKTGi1OGO3IxMK4Q2Xq5gg6g2x9yDjYHpisUoGag77/XMZUc"
  "QlIpxjPmLGuc5JjQaTDgc+5zn+0tqKD7zeYiNRqpIfO/NYPG4fDAZz39bUgBtDjjnLfKJW"
  "41OnE9M2G6Z4//Pce+XMCjyPD32+YivXqPRxhN0LOh3+ZOcKk63Abpqdh2W58LLTWcpw/5"
  "+xP8dnfG33bhT378dUIFCqE4TuN12uf8FOgbnMXFWp1vaLimJlzi1Btbr3bbe79EMkglxT"
  "Ey7xWfzX04ObHR2IKJXnEzbbux+bzeUVntUSM2m14v51N6kWBPIoFBRTKvu5RvFaSwsKnO"
  "8bnM+nZXlVTfSMy2ymBqv11GmLpTzFbmjdbauc7T3sb1GpiHNOEUF46tSmTcUrnMuUKBYF"
  "ooHKmnrOn5P/sTpRHLVptbP8qGMjGxt+mL/hPr4PC8ITYaXyrILo2Y01/wOsInzz";

/* 
 * Resource generated for file:
 *    keyboard.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_apps_keyboard_width          = 16;
static const unsigned int  image_Nuvola_16x16_apps_keyboard_height         = 16;
static const unsigned int  image_Nuvola_16x16_apps_keyboard_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_apps_keyboard_length         = 852;
static const unsigned long image_Nuvola_16x16_apps_keyboard_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_apps_keyboard[] = 
  "eNqFku8vG3Ecx+vBEpElKMOpJ4g/gj9CIvsLPKosoeGBUP2V4BIhG2at6XWJJUZN0plfXU"
  "a0pTLCtKy1qtJZ117XXGmW1OrEe9+7zmUPjEteyX1z9/p8Pt/39wtAVlf35JlGY74gXOr1"
  "rzJaLZPR6y0EhryPieh0Y2QtctnfP8E3NCh9OTkPqkH8zs6XFwcH37C66gHDvIPdvgWr1Y"
  "6ZmWVsbPjhcu1JOJ1eeDzHmJ11oaDgkUXwafr11dFRFAsLn6BS0RgZmQJNGzE+/h6bm4dY"
  "W/siIdTY3Q1hZWULxcXly4JvMFj4aJTD9PQKBgffQKsdhlrdT/73wOs9wc5OUGJ7+xCBQJ"
  "TMuAG5nLJnfYaPx89hNtswP+/GwIAFbW3d8PnCIvv7xxJ7eyGcnPzE0pIbhYVlok+yIf2T"
  "ZP+fSb8Q3G6v+D0Q+A4hl3/x+8OIRDgsLq4Tv1T0u7pGeZZNkrosQqEowuE4IYFgMHIrLJ"
  "sic66R/LK+Wm3iE4kUTk/jYo1wmP1bg70Vjktjbs4l+R0dL3iO+4VYjCOzJe4llfpNzs8p"
  "+e3tz/nz8zSEGWKx5L2k01ew2VaRn18i+irVU/7sLI3r62tkMvyd8PwVhGdy0i7cH9Fvau"
  "rj/f6IeC6BwI87CQajJKckRkdtJP9sf6Wyj19f/4qhoXl0d0+ht9f6X2h6mtw9H0wmG+lf"
  "8kHwGxt7eYZxwmCYgU43RbCK6PVZbtYCGo0VRqMDPT0TKCoq/Sj4tbWP95XKYTQ3m9DSYp"
  "RQqW6ntdWM+nolcnNzhwWfompq5HLFW4qqcpeVVTpuoKgs5eWVDoXihipHRUW1Oy/voUUm"
  "kyn+AN+S6fY=";

/* 
 * Resource generated for file:
 *    ktimer.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_apps_ktimer_width          = 16;
static const unsigned int  image_Nuvola_16x16_apps_ktimer_height         = 16;
static const unsigned int  image_Nuvola_16x16_apps_ktimer_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_apps_ktimer_length         = 1100;
static const unsigned long image_Nuvola_16x16_apps_ktimer_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_apps_ktimer[] = 
  "eNptk3tIU2EYxt+p00zS2UXNstKiotRadKXS7oUUJBVFBeUfYdEfXbCisCiIggTJECNQgi"
  "6WNcssp+Zty8xZdtHMmqm7aKdtrc2Zbufscp6OKw2lFz4+eOH3Pc97+QDQGvFsWhsUS+sk"
  "82itJI72EtH50YH15VGT8CwywnNvrISLIDpA/wkIPEnyyDf2IfklyslnlZykc/bRXnFEfe"
  "6YUOSETsQ5kS8/bvyM06IQKfmHL6OAkOjhfEg2Bcy5ReJFBSReVyydf7b9fmrmC2vGTQWy"
  "H7zDicxHSDqapw6NP5ziN/MQBU9ZPUI/mygmj6K2lFxML+jiZC9NUHywoqK+G+UvNVB+sK"
  "H0bS+yShl++f4b7/3GLpg6jA/MookJsiuXiy18kdIApaIFBsaCHyYzmG8MbJZevH3zGU8q"
  "tcit5bB0+0UNkU/4IB8Qfn1FSpbWda1QA10HA/BuuN0eDIbHw8PJcbCaf0JWpsWZQhZT4r"
  "dVD/LTVxZWHs/vw6MiFZQ1ddDpGPA8j5ExkNO2a3C+wIaE1BKnSBS4eoCP36WynbhtQr/F"
  "AoYxorpa5T3fzT1w6bvQq9FD3dEFtVoDOB24W/kDS9O0GBUcfd2rv/+L6+RNDfqM3/769a"
  "BTy+Dp0yrkXrqK8qIKNDS2QK9nwPXbIKvsxOwjBgRKpPIBPnqPmku/1Q3WaobH/de3yYSf"
  "CgVaWtvwq98xVIOL7UOxkkHsMQP8Q+K8fOSaEm3anT50tWvBCdp8Tw+cVVXwmM3D6ne53L"
  "CZTciVWxB/sAU+4rAcb//DUi7symZRXPEFvwwGcCoVXIL+v779mQHLsmhUteJUgQeRKy45"
  "hPYneudP0uBpG+/rMhXAx7IG6N83wSH4cDhY2PvtwuycMH43Qt2sgeyVHavSmkC+kx8P7Q"
  "8tJBJtmD8r+aEp6zmLmgYDOr4a0dmmg/pTG7r1ZtS/1iG/1o6k9GaIgqSvBShsiBctIRq9"
  "VbgTZ4bGHa9LPtvgyii04k6NBflKC3LkPTh4rR0x6zPsJJr2QMDCh+0vLRb4ZKKgzcIbkU"
  "TBOzb5T1h+e/ysnXVhc3c3BkUl1VJAzA1hZxNG/t/fWHxdtQ==";

/* 
 * Resource generated for file:
 *    camera.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_devices_camera_width          = 16;
static const unsigned int  image_Nuvola_16x16_devices_camera_height         = 16;
static const unsigned int  image_Nuvola_16x16_devices_camera_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_devices_camera_length         = 976;
static const unsigned long image_Nuvola_16x16_devices_camera_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_devices_camera[] = 
  "eNrFk1tIU3EcxwdCbz75YIL3y6ahRMFKFN98LTQtQSjrpXyKMLpagRCEkA8xiChkHp3zto"
  "lu3ljzOG2Xc9zM5Za6xeamm5pMnfMyXZNvv42uzz104M/5c/h9ft/v73IACPAfT3Fx/a3y"
  "8jtMXd2LhQcPJJGamvuBsrJrfZcqH7deqXzEVFU9Y6qrm5iKiidMNd0vVz1lrtY+l128cE"
  "+SmHgySyLpDS8t+WEy2TE0ZMTYmAX6qUW0y8fR0CRFG6OErKMPugkzJqdsMM4uQ8N5Ievk"
  "kZ11pkupfH8cjYaxsODGyAgPjcYKs8mBphY5CmrfQPL6LRof3kUgsAG7aw2DZh/6TBvolN"
  "uQLyr52Nk5HN3dDWJ2dhGDg3ryMA21Wg8TZ8UHk5W4ADweNyKRKDa39jAzY8fkpAvd3U7k"
  "5op5uXw4urcXhNXqgEplwsCAHlqtCV/Xd/Dt6BB+/xrcbh9cbi82AyH4fRswGuYhl88jL+"
  "8819U18otXqzkoFFoYDFb4fDHdFaqzH/X1DVAoh+FyeSjfNnlwgGHMEIlK4nzM/0/9/n4W"
  "HPcZXu86fP51XL9xEwKBAI2NTXF+eXkDc3NfIJUaIRSWEj/6F69QjNMsbPE4j3cFL1teQX"
  "yuGO9a2zC/4CD9AMU6iedJv5Tr7v7Nx/wrlTrqj4XitrC6uk5adspnBsdPUz0++rYFnp9H"
  "R8enuP+entFoKLT9o/8G8sBRHh1iOxEOR7C/f4Cd4DaCwRBCoTAcDjflX0Rvr5P8F3Mqle"
  "4YiMDppL3QzIBl7dR/K6an54g/xJ/P5uYO7HYPxR6R1gry80vNzc3SA5vNQXvHU01jaG/X"
  "oqdHD5mMJQ0tafGwWOYwPh6brQE6nZvm44NEMoW0tCJDUlL67ezsosnMzMKJ9PRTbEZGIZ"
  "0iNivrNJuaWsgmJ+fQO5dNScllc3LOsiKRmBUKxbrU1AI2IeFE3b/+f98BoK/ujA==";

/* 
 * Resource generated for file:
 *    folder_inbox.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_filesystems_folder_inbox_width          = 16;
static const unsigned int  image_Nuvola_16x16_filesystems_folder_inbox_height         = 16;
static const unsigned int  image_Nuvola_16x16_filesystems_folder_inbox_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_filesystems_folder_inbox_length         = 348;
static const unsigned long image_Nuvola_16x16_filesystems_folder_inbox_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_filesystems_folder_inbox[] = 
  "eNr7//8/w38qY5FyEWOGDoZnyBgkRqx+kPq3/4//e/n/9N8Hfy/8u/fn9n+GbIbXpOpf8l"
  "/ja913259hb7zpoh/Z39j0gzC+cADp+/z/wP/D/zn/3vzf8x9Zv/59j/9CV2zxugNm/4f/"
  "h/5v/i+JoZ+Q/chmYHM/sXEIMwMUfyD9pOjFFpaE9M5MM/4Pw4TM7QhV+t8aJP+/yV/mP7"
  "L+5+fnwc2YkWr0f1qywf8piXr/J8Xr/J8Qq/W/N0r9f3eE6n+Q/rOzLbDqf3Jyyv+HRzr/"
  "399X+//OzuL/N7dk/r++Pv7/1VWh/y8t8/1/cZHr//Pz7bDqR8aE7Ed3PyUYAPS7nRA=";

/* 
 * Resource generated for file:
 *    folder_outbox.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_filesystems_folder_outbox_width          = 16;
static const unsigned int  image_Nuvola_16x16_filesystems_folder_outbox_height         = 16;
static const unsigned int  image_Nuvola_16x16_filesystems_folder_outbox_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_filesystems_folder_outbox_length         = 316;
static const unsigned long image_Nuvola_16x16_filesystems_folder_outbox_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_filesystems_folder_outbox[] = 
  "eNr7//8/w38a4ZkMDP9BOI2BQYocvf/37Pn/f/16kH6SzADrPXXq///Kyv//4+L+/3d1Jd"
  "oMsN6bN///nzIFRf9/LS2CZoD1vnjx///mzVj1/xcWBpuBSz/IbFiY4XA/8X7Aop/S8KOX"
  "fpAfkfxLONzTjP/DMCGzO0KV/rcGyf9v8pf5j6z/+fl5cDNmpBr9n5Zs8H9Kot7/SfE6/y"
  "fEav3vjVL/3x2h+h+k/+xsC6z6n5yc8v/hkc7/9/fV/r+zs/j/zS2Z/6+vj/9/dVXo/0vL"
  "fP9fXOT6//x8O6z6kTEh+9HdTwkGAPT4pJI=";

/* 
 * Resource generated for file:
 *    trashcan_empty.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_filesystems_trashcan_empty_width          = 16;
static const unsigned int  image_Nuvola_16x16_filesystems_trashcan_empty_height         = 16;
static const unsigned int  image_Nuvola_16x16_filesystems_trashcan_empty_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_filesystems_trashcan_empty_length         = 1132;
static const unsigned long image_Nuvola_16x16_filesystems_trashcan_empty_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_filesystems_trashcan_empty[] = 
  "eNpV039M1HUcx/HPHSgegh2/ImgdOQUD7kgIusCKGU1XucmK/EE53Q4S/NFcsoC7DkSCAa"
  "urqctw6tVKLK0JwaZFuKFTyeA6KJDklxBwcigg0aXo3bMvjGP52V7/fPd9fF/f9z6fDyBE"
  "eqMQGxoDlduv6NWGtssvlHfZ1nzcO7XGdONucmmXI8HYMRaRUdvhv+6zStnyTVoRsloIr0"
  "CBZGcif+tCUlLZnwOZpybYYJ4gxXSThMIeNDm/E7WrmaisJla+ayXJ0E3Mnl/+9Xoq/SMh"
  "9533zxR3Duz+4S4JFbdQ5fQQnN1GwNYrLHmzAcW6WjxXf4PQHkehPUakzoJ6V7PTw0e12+"
  "3fOWl3vVY5iU9WJ6E72wjJvErg2xdQvn4On1fOsODFrxFxnyPCK1jyrJl4g51FoQk/uf3+"
  "OpvzwGUnKwv7CdK14Jt2frZ3wUvfIn/OjHj6EJ6xhwlM+Y7oPX2E7u1D+Ec3uH1x3aDTOg"
  "pV1gcYqidJNQ2yKq8ddfZVIjOa0OywEpfXT1zpHVQfTiDPbEH4Rde7fVHNoNMyAp234PoY"
  "1HXB3h9h4ylYfxJSvoK4Iy6eLB9HaRzEY9ZHzfv9NX85f7PDH1KuSf9xxAJbqiHtNKw9AU"
  "nHQX3wHqoSOwHGYTwzLQjl/3x1v7NV6m6XvNUGemmybZLf9D28WgXPm0Ej+bCS0Tkv9T8S"
  "Oe+LJd92W+qWvnFxAHbUOUk/fZ/1J6Z52XyfxKMuNIemCSud8xnND/mSMzdm+7vH4VjTFK"
  "F5vTyR30dY/gBL9UMsN44QXnSbsKIR/CXvoXvYm84OuaosU1zscVBRP4bQtRP8Xh+q9wdZ"
  "lmcjQj9CRL4U/U1UxlG8slpn5p/fv+2HO6Y/ueSgodvBgcY7KLK7WZo7xIoPRtAUjBO7b5"
  "K4opn8TXQZKLb9ivBWnXN736iNX7xR3uK6NOTky1YX/jl2IgoniCn+B23ZA5JNkPwpxJZD"
  "8M5ryJZtdggh2+r2QiySy/20+sTU3OG0grPOyJxW1IZe6TzaiC0YRpN7nTDdeRav2ndP+M"
  "V0SGCzlPn7IxYGCdlilfTk0WCZZ9AW74DwSu+Q+FrF44k/ez0WXy9XrqgRCwMOSp2p0ktK"
  "Mbdm7H94/WSa";

/* 
 * Resource generated for file:
 *    trashcan_full.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_16x16_filesystems_trashcan_full_width          = 16;
static const unsigned int  image_Nuvola_16x16_filesystems_trashcan_full_height         = 16;
static const unsigned int  image_Nuvola_16x16_filesystems_trashcan_full_pixel_size     = 4;
static const unsigned long image_Nuvola_16x16_filesystems_trashcan_full_length         = 1168;
static const unsigned long image_Nuvola_16x16_filesystems_trashcan_full_decoded_length = 1024;

static const unsigned char image_Nuvola_16x16_filesystems_trashcan_full[] = 
  "eNpV039M1HUcx/EPIKjkBMkoE7a0hqWH2g9FHTn9h39yhkCt6Y60HeVygxCBRvJLFwORWa"
  "BBHAlaIJDU+GGtjim/cggKHHjXwR13x4Ecv1F+RY67Z19WR/rZ3vtsn30ee73fn+0DCHG4"
  "UYj36708I27Hy77obNp7rse6L9M8s/983/y+9N65nYl/TvgpqrVeB/IKnDeE7BG+7wixwl"
  "sg2cVyOtIYEJDWYz5WPk1I4TS7MobZcVrD9uhWfBWtbPqkhW2RagIS9GyNbplfLvsoR7is"
  "XvLbzuh6oypn2X/OiE9kJ9sjb1FU2ULpjWZC4n5keWAhQqbEVZbLpqP38I9ss7usfinG4c"
  "OvDi0EXRzj7c8qqFH9QXNrOyODRob6DTTVqYg5c5nIlFJOJl1lY5CSLXHDrPTZddPh4ysG"
  "FjLqITijHZPJhF7Tzp3b9QwNmLEYNGju1mPWq6mq0/FGTDfe0RbE2q23HP7z630L7SNwre"
  "1vfmiZJ692lMuqB5Q3jXKlfoLMqhHiSic5kD3JupRxXI6rEWtkS/mxZX0LHZLXjdpoHYQy"
  "jR1l4yMybgwjL7AQXjKDvGye9wqt+CabEBEdCC//J73t/ijoRxfokvYa7RSFDRaUDVYyq3"
  "XElvcSVtBPaH4fLyaaEQr10/6ayaaVXM+YjQ6rjRxVHxdqrZytNJJd1UlKhY5Q5QDBuWa2"
  "pJlw+7j9qf7jJK8b/zf/zoCddNUkKb+McfL7+5y9riW1xoqi/BGHiwYJzNLjFnEP4fnE/M"
  "UGe7c0u3HCRkXHFGHf6DlVoiehWMuXP1uIKrbw7lcGQi8Z2Z2px1UheY//fepPFnt52zQ3"
  "9TMUNo0RmNxG1JUeUssMJJcYUOR2cyirlw9yTARlmXhm8f09/esc/mh21+Ovm+f5rWeOvM"
  "ZJNp7SIM/RcuI7I8fzzRw530l4jplPi8bZe2EW1w/bEO4bVA6/yi9YGZJ+197Qb6e4Ezxi"
  "hticaCUg7SEHs+eQ588SnveQQ5emWH+iC/GK/C8hnBQOL4Srs5PHW/E7D8Y+CEv61fZajJ"
  "rNCWZkSUP4n5YqTs/Lx35n1Z6kx8Lr9W4JyKVa+j9imacQ7j7SiffzTsvWylc+6/et+7o3"
  "q93X765d8cIOlfOaV6uE23MXpcww6ZKn+G8t2n8Ap5mLsA==";

/* 
 * Resource generated for file:
 *    help.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_22x22_actions_help_width          = 22;
static const unsigned int  image_Nuvola_22x22_actions_help_height         = 22;
static const unsigned int  image_Nuvola_22x22_actions_help_pixel_size     = 4;
static const unsigned long image_Nuvola_22x22_actions_help_length         = 1524;
static const unsigned long image_Nuvola_22x22_actions_help_decoded_length = 1936;

static const unsigned char image_Nuvola_22x22_actions_help[] = 
  "eNrV1YlPVFcUBvADoZQZyyCtoKjYolCJCCoUU9BBxaqDRYECKtQNRLuZVJtSKyCtYJGtIJ"
  "tIIQiK1LAUF1YR7ECHUqxVYEBU9rEwSoZFllFZvt6ZSUoD9A/wJTd5ebn55Tv3nNwHgPAK"
  "LpplQrTyLNGqRCLLc0QW7N00dpPm+2mXFrsVSCx9KsdWeVdOGDkXPuFYpV6nRZE7yDBSjd"
  "6OJpofSaQXSqS1cbq7PH7SNYtbxOVnZDmdrB87nT+MZBGQWAlElQLfX5nAoeQh8I80gmeV"
  "Xk7zQi3/dWeHzeAmqFyzuJVLdhZ1/lgix/UmILVqAn4Z3fBNbsUXCS04GC/BV+n9OJwmh9"
  "uZ5zAUFA+SXoij0tU5NXNeszgDI/fCzpTfJ3BVDCSUyRF4/iGq6qRok/Sis6sf2WUdcAsS"
  "wzNSgh3h3XAIH4fBxqJh0j1l9X8uxzY9I6xQjrx64MIfwLHz7ejtH8KLFy/xSZQYwRebgY"
  "lxiGqlsPetx9bAFmw43gHr43JwlqbUEC9Yc5prGmst8Ls3erURSGd5E38dw9cpbRgaGkYz"
  "y+oZ3gzHoFYUV3dB8XiFi2Fz9AFWH66HxZEeLHAVg7SDPKa6Gu+lnN2dNIC0aiBZ+BLRxX"
  "J8e0mGwwmPcCD6IXziuyEIbEXmTYnS9U16gGUH62F+sA6L99bD6MAjaC6MKZnqznfME9tH"
  "v4BNyCDiS+U4fWUQAZf78WWqDPtjpXD4rg0OAQ142NnPtr+Exw8NMN5XB+O9tdB2FELf8z"
  "Z0LDJkU12TXTd6+RHPQR5SWAf2wC+zD8cuyOCTIMXO0CZcuCFBe5fCHIWw9ilM9v+FJXtq"
  "wdteCVp/DbNdRdC1zsFU19i9pM82dBj08d+gXR3QP9QOQfBjOIdI8E1qmzLj8MgIckVSrP"
  "j0LvTda6C1tRxknw+y+wU85wroWGVPc+dtzm1ad3qAuZ0gz1aQ+wPQRw3guNTCO7YZfc/k"
  "WPb5Hag7VEBdcAu0qURlbrgKWpsNHedKcN9N75vqaponpWw42Q2OF3N3MNO9EeRaC9pSA8"
  "HJ+6hs6AMJhKAPbrJVDNpYwOpnpl0O1PhZmO30GzTejLo1bc4MI/gW3tXjS489AbmIVabL"
  "HZBDNRyC7uNMQTcW7K1m+Yr+Y+aCbDPx+uYCaPPZd7UT3tPchZHENf8pjx/YBe09TaDtt0"
  "EfVkPH4088fvqMbRlASmk3aE3+pLnmZ6ivvQwdpypozIkRE/lzZ3JpbqjRvPW5Pav9u8Dd"
  "eZedQQU0t4lwpUaGoZFhfHauBWSTp6xdkVNhajuLoGWaMUrkZ0cUQDO6BhFEb4Xw5/JzZC"
  "uOtkCfzaf6lnK8tu0WDPdVgdYpepSlPE9F7YqcKtN/t8Kc0TU8o3L1wxT3khlnSWLZOy5C"
  "LPaqgx47i1lsTnlOQmXfdVmPeHZF0NCLucdy2hOdIJUbNN3lLJ9057A7j3dKjd4IdtOcH3"
  "ONZ35RymZ+nM3nBHdpuoz1vZxZh5jFJbVAmnS3vJL/NMX6Bx1oj9o=";

/* 
 * Resource generated for file:
 *    messagebox_info.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_22x22_actions_messagebox_info_width          = 22;
static const unsigned int  image_Nuvola_22x22_actions_messagebox_info_height         = 22;
static const unsigned int  image_Nuvola_22x22_actions_messagebox_info_pixel_size     = 4;
static const unsigned long image_Nuvola_22x22_actions_messagebox_info_length         = 1512;
static const unsigned long image_Nuvola_22x22_actions_messagebox_info_decoded_length = 1936;

static const unsigned char image_Nuvola_22x22_actions_messagebox_info[] = 
  "eNrV1HtQ1FUUB/Czgu4uqAhhGg9Fs1JTJkJgQBtwlYdam4qQjyZAY8ZR0bQQUViSllVeK/"
  "IwUzHd0NRAeaZhGaCimIbIS2BBF8wFd2FBQRZW+HaV+Ic16l9/M2d+M3d+v8+ce+45FwDh"
  "FQyy/24g7A4SzU5h72+J3kkIoBlJhXz7IypTF5l2nJNMy7M9pCYb6TWy2LOBJsWNIKs4Io"
  "t4ogmxL2JYd2aiHc1MvjvNO6f/09gaiNI1EOd2ISyjCxuOaOARWgtrj0yQZYyCJkYv+F/u"
  "rOQVXIej3f4JtThZ2o9zFUDybz34Ok2BHan3EHqiHTvPaLH+eC/mbpWD91aKjswlQcO6ti"
  "n2fIejPdtkSuTVAqduAkkXe5CS1Qjloyd40NyB3cflWJv4EH4Jf2FlUhdctjeDNyXpGZlG"
  "uZN5tL5rd9Dw+d79EuT4mZlpJf04XPQMuzM6kHVVicHn2IUmLI+6jxUSBRaF1WBh5GNMXy"
  "sHx1SspHESnp47I9HveT1PlwE/sjwPFeiQcKEb4nOdCE5txC9/tCC7uBlrouuwTKzA4vB6"
  "uH1VA4eNFbAN7sLY99NBRhGhL3EL3UW1kDHz2BUd9l3QQpLZiR1pbfDfr8Si8Dq4bq+GZ7"
  "gcH0Y0wC24Fg6bqjBr3W1MC6yH1bISjDCOrBjqjnY8onKP1cB5jxbS808hzevC5lQVgg/L"
  "kX9ThfxbKlwuV0Mka4Dj5mo4BjHz83LYrCnF6I8KYLnqBkaNj38y1H1t3g9ad7ZMn6nxbv"
  "AjhJzQIESmhv+++/j+YjPQr2WfaZF6/iGmryuHbWAFpqz5E/zFl0CCHLzuex1ci8Teoa6Z"
  "y3GtILodhgHNoE8UMFt7D56RTRBKmrAyRg51WwfQ9wQHch7AcnUp3vApwUiPfND8bHDmZ8"
  "J8+VVwJ+zXc43fO9QqiGqB0TolaFUDyLcGtLwS/KVl8NhVDU3HY+Y+Rnz6fXBcfwUtOM/y"
  "zAW5ZWKEWwbMhEUwNInpHOpypkqvOW+thNWWFpA3M32qmHsHtPAGXLaVM5flq2tH9Jl7IO"
  "fcf8ws0NzTGLUwGyaCfHAMRDV6/TApdoO1+1k4RbaB413JzDLQ0lvMLcZc5ra1a4AeDfae"
  "YntxYp4rm+MPWG85p2GMsBC8N48yJFSs59pIDTnWcYo5m9h5bGkELSkBCa+zf3+H08bbzG"
  "1FX7dqwJ19GjTvJ+bLwPPMwxgBq4uBqJU44eP03MlSdi/FuPLfPqCz/6IGVuvrWK4FmBZw"
  "E2eva9Cv64Suuw1N6qfw3l0OcjwBrkcuxnoVwsAkpo/l6kMckf4cT5IOxHhJEH9qsm5mwC"
  "1MDqyG3ZfVCEyuh29UJXzEd+AfVwWvyLswFl7GmPn5g6aESETP419dS3afmkZ5kalEaT7n"
  "JCw+LsJYYTGMllwB17MQhoJL4DrnvagnOyc1M1cPmv/pmu8lMokyIm54CMdYXM5lc8SzSO"
  "rlTkzsHcl6iWMQUU208xuiXWZEYTSc+6rE337Kk60=";

/* 
 * Resource generated for file:
 *    misc.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_22x22_actions_misc_width          = 22;
static const unsigned int  image_Nuvola_22x22_actions_misc_height         = 22;
static const unsigned int  image_Nuvola_22x22_actions_misc_pixel_size     = 4;
static const unsigned long image_Nuvola_22x22_actions_misc_length         = 1704;
static const unsigned long image_Nuvola_22x22_actions_misc_decoded_length = 1936;

static const unsigned char image_Nuvola_22x22_actions_misc[] = 
  "eNq1lXtM01cUx38KG4NBGC6ZkqkoJJDNDTYHGckyjTGZiSGIUTImyRamoCmBBR/lMR61pR"
  "QrBSxD3g9RUAEnMEAeSkRAKygPRaTlUcqrPFoe5VFsLWfnXgPqNrPtD09ycpv+7v3cc7/n"
  "e38/AGDgLeRKREenM0LhBebs2TyaAsGFr4TCi+8JBDlMbGw2Ex9fcCkjo0yOYzGfnx0aG5"
  "vrSNYFB5/BuRlMVJSYCQ09yzg4fEZ5GzZsZLy8/Fa5yLERifIziovrtWLx1SoeL+MjDifV"
  "/tKl6kWNZgnGx2egrU0OJ0/G1P0TNyQklnLDwxPx/0zKRea+nJwKlVQ6Ano9gEymhPT060"
  "NpadcVnZ0KWAmtdhmCgqJ7yfpTpwQMl3veOiIi0YJw2Ww+s2nTViYy8hxz+nQy4X4gFhf2"
  "19Z2wPS0FtcaKFuj0cGzZ8vwauh0BigvbzKwWOGFXG5yfl5exXRMTFoD1m5KuKR23IdyOZ"
  "zkrZmZf+jLypqhvX0A5uf1NHU6gOXXsasxOjoNY2PT9PfDhzIID4/PDwsTGrPZMSvcfTxe"
  "StyZMzmqsjIJDAyoYGZmCebmdDSHhtTQ3T0Cvb1KUKk0b9ynqKgOvLyO/Ozvz0Z9Ez5OSM"
  "hXSyRSePRogGo6OTkPavUCMhZAIpHhmZuhoqIFbt3qgMbGJ9DVNYja6Fd5er0B7t59Cv7+"
  "obI1a9a6EG5kZGIs9hp6esbwTBpQKmdpTk0tQnOzDFCzUTe37wv37j1YEBgYIS0oqIGmpq"
  "c4f3S1bsJNTS0CS0srj/XrrRnC5XJ/qy8qqqd1dXcrQaFQwfDwNNa8ACUlDbB5s50/8zIs"
  "HR1dfk1KKlhube1HjZZWa25oaEcNfKtYrFPuAQEh74tEObOVla1QVdWO2QpPngyjnlPo0z"
  "moqXkA27ZtZ9vbf85s2WLHmJmZUbiPT0BcaWkjzM6+5JLa1ep5uHbtJhw6dCTLw+NQSnCw"
  "YDw3txJ1bIH793to3whbJhsD9Png/v3e9oGBYYyvbwDeoR+Zw4cDdqSlFcLiogEMhtd719"
  "bWC87O31wk+2/caLPB0/OnktLSe9i7Qez7OPT3T1I9OjoGQCTKmmCx2NF+fr8cPHbseBCH"
  "E9/z+LGc+pr4UKt9DhMTGur7kpLbYGtrH0a4qMm6iAhR/507nbRGqVQJfX0TIJe/YCsUU3"
  "DvXhfcuHGX6jgyMgMLC8/R3zo6Eg+1tMixn714PoHWwsJiN+GeOBGVQDxRWSlBf/dBZ+cQ"
  "zuuhI2EPDqqpV1QqLda0hLlI/aLRPKM+v3KlFgSCFB2PJ9Y7OHxKXhBGhLtnj7tvUlI+6i"
  "uBuroOrEkK1dWt2LcWePCgh7JXNCf1k32IF1/c92WqqZvbgQ4zM9MdiFv3in8YV9dv43Jz"
  "y/HO3AY+P3k5NbUQ74KE+p3oTdhE8/Z2BWrSjXs/Qr4KdZ3Hs/WDjw9LSXzI/D3WIFvs5O"
  "ScZG5uvsvJaTsvMTEP/dFH3xdEc3InL1+uofe1rq4Nn8nw7shRg/NgbW0dhIy1zL+Eu7vH"
  "hzzeuefNzQO0JySFwgxwcPgkZdeu76qys0vQq/Vw9OjxSRsbmyhcYs78h/Dy8jb19PS+GR"
  "LCnxOL8yAr63fYuXN3LT4ywTR2cvpC5Oz89VUjo7UuzP8I5JLB1NjY6EsrK6sfbG3tuCYm"
  "77r+Zdo7b1oPb+m7+Se2EIbG";

/* 
 * Resource generated for file:
 *    wizard.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_22x22_actions_wizard_width          = 22;
static const unsigned int  image_Nuvola_22x22_actions_wizard_height         = 22;
static const unsigned int  image_Nuvola_22x22_actions_wizard_pixel_size     = 4;
static const unsigned long image_Nuvola_22x22_actions_wizard_length         = 1148;
static const unsigned long image_Nuvola_22x22_actions_wizard_decoded_length = 1936;

static const unsigned char image_Nuvola_22x22_actions_wizard[] = 
  "eNq1lWlIVFEUx4+z+bBp0pkcp5rMXEowxZkIAj8U1tBKkAXVh6igTzG4UuZMZFG0SDvt9S"
  "GyJqXFFm2hvdxKqxmTJgcCswS/lGWohc38O2/mvRCiNKwLf+499777u+ecey4PAOE/6QUR"
  "PScSaolG3efxddYF1qVQf6zSqOl1aRQnT7M9GMncZ0SRnijhqXucrvMOL1USGc/zehnRwc"
  "bFEwLtp2woHa5sOcxzx1knBpDMZT/HeZL03b1P9+HtxmW4Z1J3MrOu1pYQ8He70Oaai6Nh"
  "dOsQ7znI2j+A+nGJ4y9/t20lm33ofnkOrTvn4dv7c2xX4EXueOwlKtzN321iFbEcf5DMvc"
  "vjm0Rj7pvVXT3eCoTaK1YV8D0Xj5bpwbxy5gnr+VvnAJK5FTy+GMpnfduuBTz1mt2+AvQ4"
  "WTZ01U/EwxV6lESFfVxHVMJ7dRsGyRXvqGZGgv9rqwsIVIWYXbOAz1bg2zSgcyY+XbXgik"
  "0L9vky82n9byRzLyrpaMOiZN4fyif8eUC3Lcj87rWg/XA86tcYcX1hZKAsTeVnn84UhoVR"
  "0W8kc6tM4X0dpbPRVjYP7rUJqFluQE8jn/N1Gt7sGY3s4SNxaWMJcqbP/zBXO2Lq2vBwcq"
  "pU5FCryanRkFO0+/UytzxcWXo2UuU7QnRnD1HxZqJrtatHBvPQkD0a8SoB9qIi+N62BrJW"
  "rapOM5kUU6KjaZJOR4nMiVMoaLxSGewT+CyZe4Zzwkw6INXfFiLV7ijll54bk/FgqSlgVe"
  "s6xLRl2+3w+XyYn5XVqDUYNFq9noi5wcbMYOvHPSu9I7Hud7GKWXwv+6rmDEN5mtq/xGie"
  "ZJw44Z7Izs3JQUtLCzIzM+s0oSZhFRL2V674TrdLdc93E1FIVMn15NrKMU5PSVEYx46tFt"
  "l5eXnwer3IyMhoYFs1GO4O6c1sCPkcPEOMYUZiIsWnpJDBYHgos5ubm2G1WhvZ1v4Nt1Aa"
  "l7Ayk5IoLjmZYmNjNTqdrkZkFxQUoKmpCenp6U9El4fCNZvNFBMTQ4IgPBbZ+fn58Hg8SE"
  "1NFf0WhsKN5hpjnwWO/affEruObc0QuWLMYuzVMtvtdsNisdT9Ay5JeQ3epcPhgN1u9/8j"
  "Lkm1Jv7C+iIiIm7jP/4zfwAdGrM7";

/* 
 * Resource generated for file:
 *    designer.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_22x22_apps_designer_width          = 22;
static const unsigned int  image_Nuvola_22x22_apps_designer_height         = 22;
static const unsigned int  image_Nuvola_22x22_apps_designer_pixel_size     = 4;
static const unsigned long image_Nuvola_22x22_apps_designer_length         = 1428;
static const unsigned long image_Nuvola_22x22_apps_designer_decoded_length = 1936;

static const unsigned char image_Nuvola_22x22_apps_designer[] = 
  "eNqdlGtMk2cUxw+zhYLUKM5RLpH7zQFSaOmN0hK5lstaqISCLUWkUC6FFYGCRpBhSwbJ5D"
  "a2sJARCRKyMFhEE7c49cuYCku2ZCwqy5aRQMIXYjYCEXd2SpSwhW3Uk/yT9z3n//6e5znn"
  "zSMSiUEiSYCMjByIieGCUCgGkUgCYrEc0tNzgMcT0bMMpNKkHYlECZCYmBylztNfKy6qWi"
  "ouqF7NfUf7WVj4iVo2m20GAHeRw1w5yOUpsdqi6p9z89Sot2ai9dtSLGssxuTETPTzC3hA"
  "3ID9ceXksfNS7Wswz+rrJvN1Z1DUGoQxmYGo+UiIaWUClCukmJ6q/pHFcovYD1ckkoFMlk"
  "pnTwMeX+JpMV/5laviovdMDHpfCkcABqZaItB0U4Ep8twNL6/jBfvlCoUyyiWHVxjNYxOj"
  "N54HiEMQOrzQZSwO32oLRV/JYYzJ90FljnbLx8ff+H9cLjeeJOCoVJr28fEvVtfXt3BxcR"
  "kNJUaESEBo56DvrTgMrDmMJ09GY6Wx5Zmr68F/3a9QKN3up0yWorHZeuafPl3G5eU1HB4e"
  "f5Gn1v42Nvr5Rm1VHQYnhmCYKhTV+lzstA5iXJz0Ds0tfC8ulxtLuSRJff2FmXv35nFu7j"
  "HabL2bfH7Cd05Ob7xH3/FUubprCwu/4OzdORz7ZBK7bEObPJ70PtWSSU67uVFRUcDnx4fq"
  "dIbBkZGpzenpr9FkanoWHBzxFXlNpOgDBxgssTidMTAwemd9/Tm2t1/9w8vL/1Mmk3WW6m"
  "/bmSSwcwUCIaSkZLCzs3ObOzsHVnp6RlCjKVk5doxznSw6kj+8DKlUAVrtu8r5+Z+2Hj5c"
  "wKCgE7co7Qf/CD6f76JQ5BRWV5//vr7+0p+nTimeuLuze6iURjryyufs7AIBAeGgUpUyrd"
  "bBqaWlNSwtrV2hUj7sEQpF9vWiotLNuDjBA2dn5xZKxZJcd3sYDCakpeVDSUkDFBaaeLdv"
  "z/4+PX0XPTw4w1T22Ivr6cnR0V7K6DHsVW92h5ubO61dCOfOtYBGUwPNzV0fPnr0BLOyCh"
  "7b2wKvGdHRQqiqage9vgF0unrviYkvV/v7R7dYrIMd9va8DtO+T73+PBiNrVBWdhGamrot"
  "MzOzKBAkffNy9g4F3RsQGRlPrAtQU9MBFRWtYDBcfHNoaGrBYnl/g/pt3Ktn/xVMJhNOny"
  "6HhoYPts9fWXkZystbobGxWzsychNDQqKmyebrCNPFhQVqdTmYzV109ss7qqhoY/T2Ttw3"
  "GJrWyKZ0jOlK8zbRPq+CyWQjdW6rpsYKFkuPvLt79AWHc/xjsrId4RYW1kFb2zDNpo84/T"
  "uid0Zf3+QNpVK7SDahI8yjRz3prJegtta2PafdMpmuBJrNth8OHTrS6uh/RXcb9dUAWVln"
  "SNq/SakscfX29peQLcgR5l+Nuavm";

/* 
 * Resource generated for file:
 *    folder_blue.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_22x22_filesystems_folder_blue_width          = 22;
static const unsigned int  image_Nuvola_22x22_filesystems_folder_blue_height         = 22;
static const unsigned int  image_Nuvola_22x22_filesystems_folder_blue_pixel_size     = 4;
static const unsigned long image_Nuvola_22x22_filesystems_folder_blue_length         = 2000;
static const unsigned long image_Nuvola_22x22_filesystems_folder_blue_decoded_length = 1936;

static const unsigned char image_Nuvola_22x22_filesystems_folder_blue[] = 
  "eNqVlWdQlFcUhg+CBZViV4INIRZAQxFEnShKVZCio2LiKOqIDVAiFixBJtSoqNiotsRgDI"
  "qh6EoRWSxUHaWIuAKuDUQFhF1ky5uzkPyI8Uc8M+/Mt/e757nvOed+s+SVS7RQQH2+y6Ex"
  "P5SR44KF5OxoR05OjuTo6ED29nbqERGRyWlp6fX+/v6xtra2C+3tHcbp64+ktWvXkYWFBZ"
  "mbm5ObmxuZmZnRsmXLSUtLi+hf3HtkvvIQuTrb07x588jZ2ZlcXV1NKiurZOBQKBQQi8Xg"
  "M0RBQXuS/fw2bzAxMTFl8X5nMjU1/Sx33NYyGrTmBhnbuJCrixPZ2dmRj4/PdqlUis9FQ0"
  "Mj8vJuNh06dOS6t/eqXTNmzLR0d/fU0tTU/A93yOosGjDGmuznziKuuefJk7FZ+B/R2tqG"
  "kpIy+YkT8fmGhkZzP+WO8OHffUaRo+008vTwMCouLn6NLwhuFZyc5qfQ0hwilwwd8hSMHb"
  "qxyEZnhcCaNL/q8Y31HArc4rtU8qFZ+XcGZHIZ3rd1oP6NBOXidgirm5Fa2oSWNhnkcnnX"
  "rpqapzAwGJfQz7vg+wXRjwp8z9c/PpDd1O7z28sPpD9vE+kt6b1pX+y53IdN+L2wEUevP0"
  "fIlWfYc1mMkLSXiLreiOPCZqxIFOF0ehlkUkkX9/z5i1INDQ2f6WHV1efKgdhS4HgxsP82"
  "MCe8XOIWWfx458XaztiCZlwoa8PVKglyaj4i96kMeXUK5NYBt14CwdeasC0mEy1v3+ED+9"
  "6wwVdERJbmu++Vpj4C0iqBTFb+E6D6PfCwUYaqhk48bQEq3gBlr4DCF4DwGZD9FEivBq48"
  "BnZdb8W6qAw0vHiNJ6KXsLKySmfuoCn+eSn1zYCoESjn80vEwG2WoKIFRWIZipl193n3Wn"
  "49kMPMzBrgMnv45QHwU74cS0IyUVvzDILMbIVWbw1/oh402isluuiZEpXMLOS8ApUfkRzX"
  "KlpRwmt3xd1reXXdPjO5HlV95x8CJ7lvB4qA+cHZKCupQGjEsXYaueiw2iDLkQOm+m8ScE"
  "0P2Fe+SNnlJ62yA9nVEhTx2i1m3mRmFq9ncN2XqoBf2WcCz+NIYTfXJbQAf6ZkYuV+AYYE"
  "iKCmPXFLD7PdrvEFbUpV/VmPlchQ9e1BK4R1cmTXdntL5rmeuQcklgHxpd0+Y5j5M884/A"
  "6wOKYcYZFxmB1aiMHLLr4jUvOkaXGWP/4hbrvDPUivVCKNOTH5HxCd345w7l2YkHNvdd+T"
  "aGYcYh1kRRVwb28Ce/OB9Rca4OUXBeMdd9HHwq+U52ZAxiGG647efy7kWq+UK+F/WQHTg3"
  "JYH5fC82wz1qe0YMdVCUJudCK8QIFIPiOcmSF5QFAO3wfmOkQ8wQT3UBhuvgn1YdYJzO1L"
  "+j5DFwffeHiHZ775ghx6gZ34OkwOk8OAeawSMxJkcExqxyI+wzu5BRsvtSIgQ4pAgRLbme"
  "11rhlzd1VhkMcZ6C+/8FFNvf8qUsW4kJ52AYJc1f2dGNgBvS0fMT5YBuNIBaYcUcIyFrBJ"
  "Ar49BdieksE+SQKnxGa4nX4P58R3cI0QYeeVFgxfLcRA2+BaJlp1cYcuocnLkuJ4lNBdLo"
  "G+rxQG29nzvk5MipDDNFoJs2Pd/KlxgFUCYBnPtcQpMHlvLfZltCKI+20SUAH1EbNTVd9E"
  "F1fThIbYBO30Oa2AztIODFvdjpG+HRizTQbDPXJMCOWc/cCUGMDsBLr41omAwb42zP6xFl"
  "6n2HN0HfTnJypITXsrE9W6uDqWRLo2hqMWp4omBAJDvMFcYOxWwGgX92Z3ByYFvYWRfw1G"
  "ewuVeotSpEMdD7/qY7zufq9R7tlqg2clk+aEI6SuHaDqKv0TujZEWhZEA20d9DxSxXqLhb"
  "KBDmff6c6MEvef4leuaeCR1XPY9NPU1yCcemj7EfXy4qzZrPGs4SpnrF70aWjoEvVkqfN/"
  "krq2FT+v4W2e/GYWy5g1jNWPpU5fEH8BI2hr3Q==";

/* 
 * Resource generated for file:
 *    camera.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_22x22_devices_camera_width          = 22;
static const unsigned int  image_Nuvola_22x22_devices_camera_height         = 22;
static const unsigned int  image_Nuvola_22x22_devices_camera_pixel_size     = 4;
static const unsigned long image_Nuvola_22x22_devices_camera_length         = 1552;
static const unsigned long image_Nuvola_22x22_devices_camera_decoded_length = 1936;

static const unsigned char image_Nuvola_22x22_devices_camera[] = 
  "eNrtlWtMU2cYx7FF7kwYWbIPfNsHEuMHExdRq8niYpYFJMsuiUtmqi4RULcPW2KWmXFxOE"
  "epDBdZZlHHHUpLKfd7uRVoSwsF2nIpl3JpuRRpD1DKWtb/np4tZlO370t2kifvOe/l9/7f"
  "//O8OQAC8H8EHDlyKTou7uOThw9/cjop6Zuc5OTvJi9fzpw+evR9UWws7+1jxz49GR+fzD"
  "t16gbv+PFkXnx8Cu/EiVT6vsbj8a5Re52N02c+4509+8WZuLh3YjmcwICLF7NKamp6tmpr"
  "ldtisQJlZa0UbSgvV6C0tGu3UtzrfCyqZn4UPmJKStoYsbiLKStrZ4qKWhlxZR8jk/YxdT"
  "VKRl5N79XandRUQQ+XG/JGXl7Fps/nhtu9g+npBXR3j6KzUw+l0gSdbgHqfiMufPkQb11/"
  "gkqxFFnfpkEsroDNasOAZgwTi5tQL/2K6tFNNHbOIVfYhNDQ6EsCQdGqw7GB1dU14kygrm"
  "4Acnk/Ghu16OgwQi5pwJsXshGT8DPa2jqQlPguBIIc+J/JOSvk/WY8ajGhWLEEiXwK6WlS"
  "L3FTBILCFadzA2tr6xgenkRDwyDLbm0dgVSqgEqtx/joOAb7eojkg5NxYm/Pjf19HxyOba"
  "zZ1qFSqqHsNkPZt4W0NIknLCz6Kuklrv1v3Pp6FbVq4ndgZmYFDONm9TmdTiwsWDA3N4eN"
  "jafY2nLTOgbz81bSoSL/1pGeLv0H7gCFBlVV7ejt1cJsXsH6uhOLi8tQqXToUmihUAyht2"
  "8QFssC+effy47BQT15Z0ZGhoy4r17NySlecTie16um3DTR3DHKpZXWbsBgMKGpuQ/nziUg"
  "MfEDtLQqMTSkg81mJ712jIyYKC/DyMyUs3qFwhe5tbWDqKlpJ31G1geLZRnL1lV89XU6Ag"
  "IC2Pg++wcYTVPkySKN22lfM3E1pLeG1SsUlryEq6KctbJcs9lGHqxgZnYeooJCREREIioq"
  "GmUVUuiG9aR1ieWOjU1CJtOQ3lqWe+9eyUt80KCyshn9/XrWB7+/hnEDtLpRlJVLIJbIoR"
  "xQ0/gArXOw/up0Bsqz4V+5/lqQyXqpfvsxO7vKrnU4GJhMRtJlIMYInUVF/U/ZvFksa+jp"
  "0VBNLBJX5gkPj7mam1v6Atdfv83NOkgkzTAaZ2G3b2FnZw9e72/Y2d6m+mLofnqo7lx0Fo"
  "a8nUJLi5bYm8StZrl5eeWrz9evn9vSMszWW319B5aXbfB4vPD58OzxevdpLzebt+5uLfR6"
  "5k/uH3rv36/a8Hp3aX83eblMtTlG5x+lORN01nlqJ6lPQ+wVYnmfcT0eD3sfNJppWK2gcd"
  "B8N7KyGnzETU1ISHmSn1+6IxKJd7Ozf3HduvUTG2lpIldGxmPXnTvFrtu3C103b+ZRf44r"
  "N7eA4iG9C13p6QWu/Pwml0jU7nrwoMl1926t+/z5zxe53OAPOZzg1ziciI8CAyOuHDwYyQ"
  "8K8scrf4lIfnDwIX5ISDSfwwnnHzgQTBHC53Ij+GFhMdR/iJ3nb0NDo65wuUHvUX2//l/7"
  "D/0OuLxxfw==";

/* 
 * Resource generated for file:
 *    messagebox_critical.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_48x48_actions_messagebox_critical_width          = 48;
static const unsigned int  image_Nuvola_48x48_actions_messagebox_critical_height         = 48;
static const unsigned int  image_Nuvola_48x48_actions_messagebox_critical_pixel_size     = 4;
static const unsigned long image_Nuvola_48x48_actions_messagebox_critical_length         = 3536;
static const unsigned long image_Nuvola_48x48_actions_messagebox_critical_decoded_length = 9216;

static const unsigned char image_Nuvola_48x48_actions_messagebox_critical[] = 
  "eNrtmWlQ1PcZxx8ipxdJmoJHPBJjNEltY6bj5JVjHcdMMmPyrnXG2Bmj0oga0zYSTA1IxQ"
  "sViGnVJLWiQlxQEy1RQeOBhqA1joio1UQFuY9d7mPZXb79Pn8WXRBhF3zTDjvzzLL353me"
  "73P8fwAQ9Fu/9dv/jaWIPMzGJYtE7xW5mCRyi3boS5HZvPfew9d30XbS/kH7nLadtq0b2y"
  "oy81ORxHiRm3Ei13i/8xORKfxbNtM20tbT1jqtj/zTyJ23z8cHx6dMwakZM/CvsWNBbrVd"
  "NH9P+MkeuYWf3REUhK+nT8f+qVOxdcgQkLuW/PMeMf90xrgmbdIkVGZmotVmg96sVVW4sn"
  "o1yI0EkVTe+7rDT/ZYxhrH585FXVERbPw+W0sLzNevY//MmSCr+hHyiPjfoEYq0ydPRi2/"
  "v6vb1U2bQG78U8TE+8Bu+AeQfQ3ji1Pvvgu73Y6W1lY0ONpMo1JfXo6vZs1SH+wxIqEb+s"
  "Y/nezmIxMnoiEv7x5va9FtODLTYNe/232IjQW51Uw0/674lZ36xskFC2BnzJvJX2ezo+J0"
  "GirPZaCmuQXNDgea62phoqaiRRyMf0gv+X+jmjnGuNffuXOfvTgPjreeh22CoGXLR4YPdu"
  "drufSB3GqpNN/tXWhG2R3KSP56fqY06XNcHe2H3AmPoyzjGGrsrWiilppqapDCPESKtJJ9"
  "oYf8z7FWi1TvrpppvXMdjt9ONtitvxA0TRQ0b4uCjTztPuRs3Ahyq5log9vjfk8zGndlp1"
  "5KU3bi6hg/5AQJsp8SXH4xCCXHUlFtc6CJ76ktK8Pe119HlIh1DbXgLj975Np9fn4wnz/v"
  "opk7ZH8ZtufI/jLZfyWof0lQ+6ygYesqtPA9ttY2NeUwD38nL7l302I6a8aIe0oCckcOQE"
  "4wuZ8WXBopuPCE4OLEIBSdTIelsQlNDjssBQWIDQ5WH0zu8lPz2d+++up99oKfqJnxbXF3"
  "sjf8UlA3SVDzgsBCn2pjw9GsPcnpQ/bmzWBvR6yyL1z4oGbGBCBn2H32iyPIP1yQ9bjg3D"
  "OBKDh+hD40GnH5as4crBT50V1+6j7v9Guv3eN3ZB6F7XmnZlzZ+biKOTDTr3LmofrTSCPv"
  "VrvD+NyFNWuQsXSp0Rsf0Ezwg+zn6c/31FLGAMHNuLWwWFsM/m8WL8ZHIsUe8B/R2WSn/w"
  "a/9jnWaiP13vBSJ/YXBRXMQel4QTF5zPH0gSlQP9QLNa3Hh2nGlT2L7GcG8bW330R5SQmq"
  "6upg5fckTJuGv4icd5eftTt7N/OeExXVph9nj9FarR3HOL/Qkb2MfpUwB0V8LX80c7EhDA"
  "3UUSPj19DU1KNm7sXdl7+5YDYqzRaYa2sN3y+bTIj09kaESIQH+vdL5E6wy8vLmE1w8rfo"
  "nNkaZehdNdOBnfoqYA7ynhHcJl9p7Meot7bHvQfN/FxwdlAbe3lxMSx19Qb7lZQURA8dio"
  "9FMtlHgz3Qj5Dfl/tAqs5VnU160/lopWmtqt7Lxndkz6dfd5iDn8YIbpC1ZEs0yvbtQu6o"
  "njWTPedNVFgssNTXG79z7eBBRHMfYt3mkH14pAf938kv1JD/zrZ5aswmOHuk9hmt1eJRgs"
  "JxHdlv0a8fmYMb1NF12lXalRGeaUbZowIClP0cuUcoey/5JaFtnzF9ofXA2aQ33Vm0Pi2f"
  "ROAu+fLGdmLn4+vMQS79yxnZO82QPYvMz7az94FfdlBLuhPoXM1x5sHKft7IwtZaVb3fGt"
  "ORXeOeQ/7sPmrmEfEL4++vO4HOVZ1NMPqizdgby2IjcINM/xntjLuT/aGa8euoGXs3mukN"
  "v7K7Xk/tuL/TD9GdQOfqhbVrYdccaI9hf9davTbKG7lPd4z7D53i/t0TXrgS+ntUcLdRdu"
  "3v2UlJ+Ovgwcp+mpyj23kjOpm7/Nudu+/2rnfgGN0JMpYsMXaCxvb+vi+BmvF5qN6z2H8y"
  "qfkzgV64tmo5zA2NMPP6R3e/TGoynN9J/oPslQGctcLHEkZbTvsT7Y8e8HdzzXdvf7dZrS"
  "5zdSfjTvbh3bAz9mfJf/pnghMDqbGocFSyZi3VNZwrDpxlb1jB76aZOGv9w53sHzjZ3+8j"
  "f7f7ezdz1ZU9gzvyKeUPFKQHUGMr3kd5TS0s3PW1fjPow4f8DVoq+X3DHg3/gB739252Md"
  "VMB/Yned3LPTltiOCwPz8T8SFKKytRWV1t7Gon168H4w6ym2iBfeXv6prPrV0sWGtV9U72"
  "Jzuyp3NHPsrnv2EPPfgYP7eSPlRVo5L1YPgQEwNqHn+mD+T37y1/bzWjcT/DHnkldC5rNc"
  "zQ+7eBHdkPDxWkMgeHqKMD3tz5P1iGEksVyjkP9BriBH0gt1oqzddTfj2fie+NZlznqvZI"
  "9hmt1XT6kDa4Ezsff8337qevycxD1oowFJaWocxsNmb88XXrsIw75DKRL8k/yF1+ss/Qs6"
  "Vjc+d6phmXuVpp0dlUZ/TICvYZrdXDfm2acWU/QL/2MQcmHwHnDjLDl6OQ9VBG0zykrV6N"
  "pXyePoS6y/836k7PxepLS4041HHOery/s6/ojqF6trA2yzmrLkWEG3o/GNCRPZl1vJe+Jf"
  "K6K8GL37PsPdwtKjJ8qOM1TMwrryCUs81dfurmlp7p2Rj3BjJUnE7HVd2Bg9zfxXQnyE5M"
  "RGZcnBEDM3uk9pkfVoYZet/v25E9iY/3+LTx6xlMVuxmFFJHOtuTeP28UKTAXX72yhsHpk"
  "5Fi/LTKrPOIHfCUFx6yrNdbPXAgcZMOsO+rs9pj9Q+o7WaPKBNM67su+gXdxV88ZgXzn+2"
  "HYUVFQb/nnnzsEAk311+9stt27gHmm/eNH63hjtOWcZx43xGzzg82N/P6k6gPmSwn6iWKl"
  "gP2me0VlXvqhlX9h0+3jgXH4d85lHjUcWcRYwbhz+IHPaA/9ebRBr0LFXPI63MgZ6L6dmS"
  "ns/oGUeWe/v7qIi2fcakc/UUZ5PhA7kKWVvfsVb17Henl5Pd1wffb9qIAjKXUzuq/URqJ4"
  "SvUf+/80A/avPWibQemDULzdRuU4sVNTaHcbak5zN6xnH57bdQYe5+f9e9kfuMr+4EOld1"
  "NmlfUb4icmqtqt71+igrPt5gL2XMdLfau3gx5vP5RSIbQz3o/05+/R+Cnp069Cy1idpoYh"
  "70XEzPlm7GrjPOOHq65lN+PifMgT/5TTpXTzh90P5yt6gYWbye+Pf2bchjHvU5Zd89f77W"
  "rLLHKXsv+fV/CKHRInY9S61jXHQWWHT3bbaiiv29p2s+F37diQN1J9C5qrOp3Qft91qrqi"
  "vVjMbdyb6pnb0P/LKBeVhFLe194w1Y8vMNDatZGafLycndXvN14ted2Fd3As4jHI2ONni1"
  "x6hprSaGhLRrJs6VvS/8zv+BhESJtMQOG2acRx5etMg4FyOjns+cfdg1Xxf8whz4kz9pCT"
  "+rs0n7+5533kEk+0yIi94fMb+s4V5BHxLJc4M8hazLLD0XI2dQV+zd8OtOHPCeyGKynqBW"
  "8tnfb7NHHiLn7K7YPeHvt37rt/8N+y/JebiO";

/* 
 * Resource generated for file:
 *    messagebox_info.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_48x48_actions_messagebox_info_width          = 48;
static const unsigned int  image_Nuvola_48x48_actions_messagebox_info_height         = 48;
static const unsigned int  image_Nuvola_48x48_actions_messagebox_info_pixel_size     = 4;
static const unsigned long image_Nuvola_48x48_actions_messagebox_info_length         = 4744;
static const unsigned long image_Nuvola_48x48_actions_messagebox_info_decoded_length = 9216;

static const unsigned char image_Nuvola_48x48_actions_messagebox_info[] = 
  "eNrt2AlYjukaB/CnogmTUihGltEYW0OMLQ6yDApJ2ihLxjoYY6TBVKR90yJKMRMmZDkY2W"
  "YsSdb2JKS00L6r1PeV/7mf9/uYZOY6nzlmznXOpeu6r7e45Pc+3/+9n/t5ATC8r/f1vv5v"
  "ig0Nkb2G8ApmTDe4AxscPIEN2rma6ezcyQbuOMf674hl/QKvU11kfQP3UK1nnwYasj4Bmu"
  "yTAMZ6+zP2sR9jvbYz1oNKy5exbj6MdfFmTMPzjfqL/EOY7i43phOUw/r5gw0MAhsUAnnd"
  "UCgO2wvFz/dCnn5mA3aB3GC9fMA+9i1h2v4h5J9AfoX/kv9zWveTbGBgPTe3GxsB3RW3MM"
  "MlE0t3l+HbQ3XYEFmPdQfrsWpfLawCS/HF94+gY3MDqqMj6B78wLS8wHr6xpDf4G/0K1Ft"
  "YZ8FVbBBwehhdh6mXllwihJh9w1g700gLBYIiQGCLgN+vwJe5wDXKGDLKcDuOPDlXhEmb8"
  "5Cj5lnoaAdCPaRp5h19w0lv+Zf7O9Ga36asg2ViYcx2zMbQdeAyCTg4B0gnPxh15oQGtOI"
  "3TFN8DtfD+8zz6nqse14Dewja2BHn8e3ES/wdQTdx4+A/uYcqI2iz6OLB92Hdwr5dVnXv8"
  "Tfm57RFG7vZxOLrafrEZkMHIoHfroN7L8F/BDbiB+vv4D7qWcwdkjAlG+uYuKaaBg5JGHj"
  "TxWwP1SJ9eGlWLunFCtCK/DlbhEWhgHG2xvQxzwGrKsnmKZnAfknvWN/F7KnMt0QjFibgC"
  "DKxlGyH4wDImjdD0jtP8S+wMYDRZi35QaiYrKRX/wMOU8rcfBcBgxsY7Es6CnW/VCGr0KK"
  "sDQoH4v88zHPrxJmgcAsf2DAgji06kHPRWf3EqbpNfQd+dtRZs7ydR+xNhGhlO+jiRJ3c3"
  "voVTECf2nAPOd45BVUQfL1QlpAdPwTTLa9jdVhJVi6sxA2/gWw8smDhUc2ZrsVYLqnGAa+"
  "QF/rOMhpUJY6eWSwzp5aVOxl/Un/Fm7va3NNsu7N7be5nfIeLUbwZTE2RpTBbf89ibypCY"
  "2NjRCLxXQV0Z80YaVPEuZ552FxQD6sfZ6SPRcmLtmYuTUT0xxzMNFZjPEuQC/jaDB1F7CO"
  "HofoPtjL+hN+Xeozlcr0rDqdFgmZeX3dm7Cb7Dsvimjt67F+XwncD6QL/sZGsWAXiUQQix"
  "oE/1fbU2DqnoP5vtyeR/Ycsj+GgX0mJm98gHF2OdBzaMKwzc+hOvQAmIrzC6bubknFeL21"
  "n/eaQbuoz+TiyO/kfXe0iOwN8Kc+43OmDluPVsPKNRGllXWv7qFRLBK+T35YBv1v78D6lZ"
  "2ve5bU/gjjbR9g9DdpGLYuH7qbgX7LHqN1V9rrVF0fMDW3tlSy+4WZIGQQGxAo5v19J/XI"
  "w/FvZkZip/4YVQu3k8/geqIGNoG5mO1wE8kZZaita8Cz2npcii/A+LXXMdMpE3O9XtofY5"
  "pgz5Da72P46nu0B6Zi4NpqDLB7gU7jToN96MTvYQ5TfRu/MM948H3V2D1b6O+8R7bMjJ9g"
  "r4P7yRpsO1YN+8NVQi3wy8OUjYlY4JEKS+dkjFkbD2Pnx5T9J5gttRvYZ0ntDzFGah+yIg"
  "06S5LR98sM9F4L9LB+CHl1N7D2Lr8yFVcFmf26wSo0z+Qpj4/AgnAxgq5K9qeWmXm57tuO"
  "PYNjZBU2H6zAhv0V1OPL8fWeMvosCuleCmATUES9Jh+mbrlCZqa9lhluTyf7XbKnoO+iJP"
  "S2TkLPZZXouyoX7T8LB2uztYkpu3wms3/wrgl8Fhu0/BaWRAIWYWKERDdiTwzdS4vMONG6"
  "c/uqUDL6PoGZRw5mOD3CFPsH0LdLw+h1yRi2OgGDl93GONt7MHSkdd+U8Tv2VLInQ3t+Ir"
  "Qs4tBlbgL6rXoEzSkXwNpuoxw5L5fZP2jnGlp/TKT/a8lhoJtdDSZ4P6PMNyDgwuuZ2Xqk"
  "GosCnsLYMR5ekZnwP56F4J+zEX4+F4cuPcGJa/k4f6cQVxIKMX1zIsZSXvQ3tMyM1G6diJ"
  "5zE6FqdA2tp/4C7SXp0DK7Cbn2bvwedsjs1wnaJU97rZFvKebRjNJ2ZSWYdSlMAqux45c6"
  "eJyqEdbd/nClMBPMdM7C+pC0V3uV5Cqmot7TVE/1XOifC73uYfiae/SZtMxMMmWG2xOgbn"
  "wdbOIZqihozaccUZYU1GlOVXKKktlPZw/FoWEw31UD42AxFJaUgi0ohvyCQhh4l8ODcrP1"
  "SBXNNOWw3VeOlTQPTLVPx6TvkuB6KFPYt2pra1BdXY2qqio8q65CQ0MDrDyov6xMw4g1LT"
  "OTJKy72qzrkJt0DmwC9Z0JP0PT8g56zE+BYlc6NyhuuS2zv39gbJvhP8AypA4GgfWQX1wM"
  "trAQbH4+mNUTjHQoxLrwMmwi/9o9JVi1u5juoRjz/fIxcGUifrqUT/uvSLA39891v4eBS+"
  "9iyMrf7J+QvbtlPFRmxpD9LK27xM7Gn0An0xvozv3d6EzU2jFVZj+d+ZTo7GS+qxbT/J9D"
  "3qZIYp//lPy5YObZ0FyeAxOvAqwJJXswzTM0Eyz0ewo92/uw3ZMh5KeqqhIVFRWopiv3W7"
  "ilo+/iFHy2NBX9bVLwyYIkdDG7DSWDS9LMSO36J8HGHYf6nFh0s0qW+Fs53H0L/8XWuruF"
  "vBsGkH9RAeX/CVUe+XPA5j2me3hE9RB9VmfB0DkXc6m3W/s8EfybfswUsl9RWSH4q+gq+N"
  "3Tob2Q+rtNMrQs46BiRGs++YLEPiFKaj9F9n+CjT0KdZPr6GqZgNYadC5VcIiX2d83cK+C"
  "zi5McyvErJ3P8cFinptm9rmZYJYZYGYPwEzugc1JQ3urNPRefl945jaFZ9GvaSB7OcrLy1"
  "FJVz4HzdqWBuXp16A0/QrYF7+A8awLmTnzm51yw8YeozqCjqY3oTHnDuRV6Fyg4Hj+Lfwb"
  "2KeBGGP3EGYhDeiymtbfMltit5TaLchulg5mmkb3kApmnAQ2M4Ec12EX/ljwc3tZWRkqys"
  "tolhPRnpBCrvNgfM0nn5f4J0ZJnteXdsoN+0ckFMYdQ2eLeKgbXqXes437Q2X283ccvXww"
  "YOENWIaJoLOJnl+LTIndguzmzexzyG6STP5EsFnxZOL+bPo19Sgle2lpKcrLSmkGFWGqQ6"
  "rUf05ify0zfN25/QiY3kG0+eIMNOYlQ3k0/b28I/d/I7O/T4AG+3h7heron2DkVw191wrI"
  "88xYPHzdbiK1z+b2ODCjO7SeseTPoS3guWAvKSlBWWmJkJ+pjtx/9g8yw+1HwcYcJn8EVG"
  "ZEo5NFIj7Q3kugzdyvJ7Ofv1vS9guT6+0HvfUPMdO/Bh2XUX5M099c99nSdef2mbfIdQ12"
  "+3LJXyfYi4uLUVpS/Jv/H1F/kBlujwSjs7wCZV99zm2oTouGnBKdY5hDAn0GSjL7+Xsxbf"
  "9xTMvrRfcZZ2EUUIvh9oWQNyf7nLstMkPrPktqn0F7p/5V2O3Po+22juxFKCoqQgldGwQ/"
  "/VueB/2WmZHaRx8EG7kf7aZeQEfzRLTROShZeznHZVSyz8/8nR5/L9bT92arT3ZglO0jGP"
  "hUQmtlFpmT38yMYL8BZhhLrmjYHXgq+IuKClFYWChcBf8W8uudkPT38S3th8i+D63HH4ca"
  "9RwV+l3yynQOZt8XMjkHNSrZ/b38pLV9Cuvq2dCBPtNJriUYu6UI7a0pO0bxr2eG26eTnf"
  "eKcZdhu5/8jbVkL0BBQYFw5f1/Mn9+Rx6X5KXluo/aD3m68n24w5x4tO61R7L2zGE9FeMl"
  "s7+Hr7T4e0nfMNbFE73NojHJrRzDN+ZByYzWfsat1+0GMdRXaB/Vu0TnyCLafp8hPz9fWk"
  "9pJqL5x596gC659Y5I+kwzu5zeASgbXoGaaQLajqR8yTkQxD6G3K3e2s/fQ76s7r4arJt3"
  "mtxH3vjU6ib0XcowxDYH7cyp1xvESu1XIW9EswrNkouCcpFfIUJleQkKyM3tT/Ly6OdiZB"
  "XVY3VYLjTn35bssdRneGYU6B6UDS+jA9nbjT0HOcVtPDfVZB780v5Wfv4O8vUaxDQ9i/i7"
  "pT7zbmCMYyF0bbPRySpJsLOJF6FpQ+f2Orz6EjU8b1Z1qH9e+2q+Pp1STz2UetDwcCjqH6"
  "deGfPKLv+hO8+NiLyzmtv/Qz9jH3lPZJ3di+Q0PNHT+BKGf5eHYXZ56LUkDW0ps21orzfx"
  "zoLZ9iyY+vLrY5jzou8llQlT7wyYeT/EeId0KEw+g3ZTzkHNJA4dqNqOPEXr7sTt9WRd3t"
  "L+DvyMaXoNY5087jM1N6gOOYD+NEcO3ZAHna8z0YPmSUWhf9JsMIZ6ux71x1GUkRGU9xH0"
  "nA4/IrmOjYLi1CtCf1enHqlieA2KH++R5v37CnIa/579nfi7ePH3eN1ZR48IpuKMVl190X"
  "nsCTr3xaH/6kcYQKW99J4ww/GzB5/fO9IMqW4SS9/TLGYeB425SehEbr43tdE5JO2RvM/Y"
  "Xybj0D+yvzM/f5fa0YO/D7Niqq6prJ0T5NU9oKyzD5pfXIAWOXuSn5+b+NmDz+98BtYwvS"
  "PMYsqjT0Op917pvsrd3+eSzbZ5n/mb/IypubejezBj7V0usDZbG/h7Arn2rsJ5lZ/5FLWC"
  "hLMHn98VaAaWk8yR3NxInju0p66g3HT6d+6/0M/Iz5gKlbLLYP6Og+4hkM7ap/l5lZ/5WC"
  "vHu3T2SCD3OaoQPkfyWYzmmQ/4TMD31Xftf1/v6339b9S/ADrc7Cw=";

/* 
 * Resource generated for file:
 *    messagebox_warning.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_48x48_actions_messagebox_warning_width          = 48;
static const unsigned int  image_Nuvola_48x48_actions_messagebox_warning_height         = 48;
static const unsigned int  image_Nuvola_48x48_actions_messagebox_warning_pixel_size     = 4;
static const unsigned long image_Nuvola_48x48_actions_messagebox_warning_length         = 4432;
static const unsigned long image_Nuvola_48x48_actions_messagebox_warning_decoded_length = 9216;

static const unsigned char image_Nuvola_48x48_actions_messagebox_warning[] = 
  "eNrtmXdUVVcWxs97oqKA2EBBOipixRiNRmMsGQ1mjMlyohPbxF6xxRo1ozGWDERMNHZUsI"
  "tYg6hYELuCdBGRDg9BQQRpInzznftseWIMlj9mjXetb9277nn33t/eZ5+99wEAAu/0Tv/n"
  "2i3Em1RlavpOIcJ2CHGd164819rOsTelt8z/M9nhV7cmjpmZQF7zm4epav8D/B/R1zjr5I"
  "giny0o8d2DEOcu8OK9rUKM2cbfvAm9Jf4q9HWAj54aOSuWAmmpQGISCrd7YK+xATYLoaEd"
  "5pR4Xb0l/oGcWwR1/gAIDQKux/AcCly6gKh+vbGRY7RhISVeV2+Bvzp9H3GopiEKPFcDN2"
  "KBq1eBixeB8+dRstUDvjYWWCdEtocQTSjxOnoL/HNk3N8Y/A8ggj4PC9OyBwYCx08AR48g"
  "ZeJIbKykljbs3sBnXkdvmN+acXPb39oMJQd3AZFRz7AfBw4fBg4eRJmXB060csRvQpSsFa"
  "In7RCvqjfMv5k5AQnjh5E9HLh8GThz5in7/v3Arl2K0iaNxjq1CquEuLRGCDUlXkVvkL81"
  "2QsDHO3x0HefNuYf+/3QIWDPHmDnTmDLFmDTJpStXI7ADu/hFyJwHvpT4lWky7+L915Beo"
  "x5313Ml3d+/I7swU/97uuLYl4X05aybduA9euB1VzXK1ciZ+YkeBobYbkQCb8KYUKJikqX"
  "n7njVfTFFr4quHtHIMCfeeaClp2xXhwUhJy8PNwtKEChnJMVK4DlywFXV2DpYoT26gZ3Pk"
  "sbZlGionoD/Gqu2cA91aoid6Ubc/wl4MQJxe9lVEFWFvILCxXdpx2lnp7A4sXAokXA/AXI"
  "n+oCz7q14CpE8jIhTClREenyMw4qqqGyJ7j6aRfgNLlPBWjXqrc3SliziktL8ZAqpYr5gQ"
  "cREcCCBcC8ecDsWcDMGQj9tCtcVSq4CbGCEhXRa/LXYtzcPMj+rGD9r9r16ucH+PigjDaU"
  "MGbkUcBzbm6ucq3Y4uUFTJ0KfPst4OKCojHDsdPKHIuFuP8fIZx+4rv/qnT5K9j/rWANR8"
  "yQrxj3J8l+RJsjd+xAWVKSwruXtjRv3hy2trZYuHAhynivLDOTvp8NjB0LjBoJDB+OGOdP"
  "8BPz6RIhTi4VQsWz+CvS5a9A79fQk/7yszJD8ZYN2vUq2WWOOXlSYS8rK0OHDh0gPyNlYG"
  "CA7Lt3lTElnw4aBHzzDfD11ygZ0A/7HOywgL/jPPRYxAf+il6Vnz2wh4z7ZJcRgP9RJdco"
  "tUnGhkbzhL9bt25P+E1MTHAvJ0fLL+dA+r9fP6BvX6BPH6Q4d4erflX8IETQQvZRlHiZdP"
  "m3atlepo6bhCg93bopSr3pb1/tesXGjVzDp/HsMXDgwCf8LVq0QFFR0dNBaXOvXkDv3kCP"
  "Hihz7oljrZrie/6W8zBqPh96mV6B34B+P7e9amXcWcD84feIXfp961bgsX8fHdOnT3/C37"
  "Nnzz+MIT8fmDwZ6MLc1bUr0LEj7nTpCHcjA8zlHuHfQthQ4s+ky8988jKNZN+Kix+3B/aR"
  "22evlnvtWm2vqXOs5f3H/MO5Tp87WN/QqRO4UIA2bYC2bRDY0hFzmE9pw7J5fPDPpMv/Z3"
  "sdshswbiK9jQ2R67aQceOn5BqlJ6ANZc/GxqPjNONJrVYr/PPnz3+en/kU48YBzZoBrVoB"
  "Dk2Q1/59rDKpjRncI8wRwoESL1JF+Kl5cu8U/kVPFMwZg6I5ExnzHsCadXgYEoLS5+mQnp"
  "4OQ0NDhX+bzE06h8ynpXIOnFoDjRvjrmV9JL7viEsd2mAu9wgzhfCexYdfpArwmzJuMg5Z"
  "N0Du/CnI6mKJDFuBrE72KFy2CA9KSsrll7XL2tpa4Q8ODi6fn8qb4oIoo8oIqCMQaK6PhO"
  "4fYnOD+pgixAPOw3uUKE+6/Mzp5Yp16kfudxA94EvkjeqNzEYC6VSqmUD27vVKbyB7hOfD"
  "oxRt27aFvr4+srOzyx1/KNPppbM4Va8KThoLHK/JfqSpFa60a43ZnIOpQhz6VohKlNCVLv"
  "8L9snvrxeiyL9FE9ybNQq329RQ2NMsaMNwZ+QyjxQWF6OEcyBzvu7RiznSysoKxcXFz409"
  "fPhQuV/I6+j5M3CsisAx8h+rpcb1di3gbWuJicSkDQMpoStdfq7PP4jslRjzfpv1KiFlwl"
  "Dc7d8R6fYCGirVoQoyLwTgXnEJ8u/fVzgkj64N/fv3V3K/7n3p+wcPHigxlse1fzshHqeb"
  "W+JINYHDRgJnresgop0T5lWpDBch4idzj0CJZ/UyfuoL7lFx3KkpcmeORIaTATQNyd6Amj"
  "samXn5Sk8g+zPJUZ4N586dYzvt+zTmOSZ/I9kLZV9N23NYN7KLihG99lccrirgS/7fa6gR"
  "0bIxvK0aYBwZaMMszoV4Vi/hVzHmA72qV4Nm4jBk/70l0uwYN1y3yU7GSA65gnT293fu3F"
  "G+n8f+/rENMpYkY3nxIscku6zF+Yy9e/fuIYvvyeB7UhMTcaKNAw7qCeyvLuBvYoAop2b4"
  "oZo+RnOPMIFzMJ5sj6XLz1h5VmOl7y//rTNyJw+GxlEPqfR9MuM+bsEkxKdnICUlBbdu3V"
  "JsuPtoHiST9KtklePu7u5YsmQJwsPDlZiR3NJO6fcn7BkZSEtLQ3LmbYRsWI0D1SthP+PI"
  "hwpqaImjdlYYz5o2RojVY8n2WLr8z/xtqD7Z03zM6iF71nhkdrNHCv2eYikQ360RrnEfEh"
  "sfj8SEBKSmpj6xQeYYyaTENOejK/uCx/XXxsZGYZT80k45Z5I9k72chj1fcnIy4vjOGM7B"
  "8c97YA+f8Sb/gRpVcK1pQ7jXMMIw5lPOQ8dRfOGocvg3POLnedVqDod96YycEZ9r/c41m2"
  "irh/DVrgiLvYnoa9cQGxuLRH5P2iBrlWSRTJJP+tTS0vIJv6zDkZGRim3Sztu3byt2S5uS"
  "uF+Ii4tDTEwMovjOy/v3Yp9pTeyuLLC9iqwJdXDS2gKjOQcjhAgYyX3ryBfwU/Zkv7+P6y"
  "ZrynCkt6uLJMZ9krXAzfZmbFmCEBwapsRDdHS0YkMC50HGivSjZJJs0oYd7C8++ugjtGvX"
  "Dm5ubkqMyXmSdkp7pd1/YI+KQgj7qOCISPzepQPk3/K2kX+HvhohNhZYaWyEwbKX4h5h2A"
  "v413EK1tJO+TfArK+7ItmGfqf/E3i+6VANIds34UpsPIJj4xCekIRrKWmIvZWB+NtZSM7O"
  "Qdq9PKQzL926z32jrE0FRcp1nnJdyOt8pOfeR2rOPSRlZSOettxI0yA6OQXhcfEIoS4dPQ"
  "IfOwtsVwtsJf+mSgJHaxnhgqUZxrOmDRHi0lDuEXT5Wac6r2Jv788+PGfaCKS+V4sxw5hn"
  "7MRxDmIZ/9edaiN80hCEzhyD0OmjET5zLCJmj0fEdy6IZE8UOXcSNRkRc6cgct5URH0/DZ"
  "FU2JypCPluCq7OnoIrMyfj8oxJuDDNBeemTkDg5HE45TIGxyeMhv/YkdjraKewS997MYY2"
  "k9+zsgpBZqbwqlkDA+n6b9gL6/KvEWL/RuaqlLGDkdGrFRIZM/HkjqMNsfR/DBXN3H+ttk"
  "Ak62Q4631IDeYIQ+YpA/bVzHnnuebO6AucZh4/xW+fYC70l/4jj5+KuZ3fPkQdoPZRPpRc"
  "q7upR/+jwTaV1u8Ku57W/2t5b7d+FVyuVxfT9PRkHJ3X5f9NiBhvS3PcGdkXyU3ZR9mrEd"
  "dQjZs837BjTbdV45oN16GVGuGWaoRSVy3UCGqgxmVzNS6aqXC+vgpn66lwxlSF0yYqnKqr"
  "wok6KvjXVuFoTRX8KF9jFeuTCgeNVNhvqMJeAxX2VFdhdzUVduqrsL2qivwq8qvIr1L4Nz"
  "Cm11EBXANu1apigBBJuvyMncMeBtWR0N8ZWUP7IHNIb2QM+gy3Bjgj/Z+fQvNVD6T1/QSp"
  "X3ZHSh+ujd4fI+mzzkh07oSEHh8i/pP2iOv2AW52aYvYzm1wo2NrxHzohOvtWyK6bXNEtW"
  "mGyNaOiGjlgPAWjRDerCHCmtgh1MEGVxtZI9jOEkE2DRBkZY7LFvVxydwUF+nvCyZ1cL5O"
  "LZyvZYxT5J/Gfob+v1IOf68VnD/P2jXxe/MmONSMtbBpYxxwbIT9TRpir4M9fBrbYU8jO3"
  "g3tMVuexvssrPGDlsrbLexxDbmuK3MW1ssG8DLwhyeDcyUPnijeT141DfFhnomWG9aF+tM"
  "62ANmVbXrY1V5PqN31tJthWM7V+Ma2A5c727kSGWGRrAjf50Yw/gxrj+mX6fxdgZoo3/Se"
  "XEj1gpxFfuQpxxFSL1JyHSl3IvuphaRP1I/UAt0O5PNdxra7iP03AvpJlNcU+h4Z5DM52a"
  "RrFH1LCH10yi2K9oWP81rPsa9jMa1lINa5GGeVzDnK5hPtQwp2j+RdG3mkHUgHLE+1fJPo"
  "Wq/O5/3u/0ThD/Bf+bvCs=";

/* 
 * Resource generated for file:
 *    help.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_48x48_actions_help_width          = 48;
static const unsigned int  image_Nuvola_48x48_actions_help_height         = 48;
static const unsigned int  image_Nuvola_48x48_actions_help_pixel_size     = 4;
static const unsigned long image_Nuvola_48x48_actions_help_length         = 5756;
static const unsigned long image_Nuvola_48x48_actions_help_decoded_length = 9216;

static const unsigned char image_Nuvola_48x48_actions_help[] = 
  "eNrtmHlczWn7x+8WshZlmyylYuzCGCPJkIgkEoWUGhSGGOtYpsjeok2EBsmaYcbSzBSVFE"
  "olytZmSVpp71Tn1Od33d9TY5vTPM8zfs/zz/R6fV7f45xT3vfn+7mu+7q/ABj+0T/6BGLD"
  "Av51DeU6wNgQQS3YYH89NtBvCevrc5D19rrFeu3NoWsJ60XS9ixkWh736HqG6XhtYL28TV"
  "kvn85Mx5sxbZKWF2M99zKmQerhyVg3D8a6ujP2mRtjnfd8pE/Hv1+HDfJfRcxJbNB+SctR"
  "wVA3u4J+ttEYtjgeXy1PwohlSRjmGI++1tfRfeoVKI86Cfm+/mAa7vlMw8Of2Mf8D/i7sk"
  "H7trMB+0pa6Aejj00kZnpkY+1Ptdj+G+ATBfjHAL7RgFck4H4NcA0F1oQAi47UYLpbAQbY"
  "xqK93kkQez3r5naBaXrq/1f4hxxYzvr7vmw77jSMnNOw6edqHL4FHL8DHLsNBMYCB4jfL6"
  "IO3mESePwmxu7LYmy7KMGWC/XYfB5Yfw747ixgd6gWX3+fhU5jz4F1dxezrm6niL/T/xN/"
  "W6br/yPTPYD+C29h/U8iBCcBZ0nBccROazgSW4/D0RIERInhf60GPmEieIZWYffFCrieL4"
  "NzSBk2nC7DmhMVWBEkxrLjgGMQYOUvprzdR8v+B8G67E4hfr1PzN+FDfKLVBxxBKY7n2P/"
  "TSAkGThFnp+IJ35S0O16QUdpHX5XaxuYS7ElpATbLlRgx89VAv/64DdYdbQQToGFWHywGN"
  "8E1GD+QWAuydAlH+1HnADruPMNU3eb8on4e1JfuaVseBa2+wsQnEjs5PnJO1I18nP/1x59"
  "hcnr4jHe6TqmrL4O0zXXYbwyCgZLIqH/7U3M3pmOtUHF+O7oaywJyIfDvlzY+7zCPO83sP"
  "QWw8IXGL+tFOrjL4F13l3EuuyZyjq7/R3+luT7tbbEvjS4AmfJ8zOJ77Pz676rIoxedgNG"
  "i0PhffI+MrOLUVImQllFtXDNfFEMvzMpwuf9rMMx1/058RcI7DZ7X2KO23PM3P0SZntEmO"
  "JBa9hZjc8MfwFT3V5OvAb/Mb+uv6/SqCDYHy7G6bvA6YSPffcJr4KuXTjcjt9DraQOTf3U"
  "1dXj4PmH0JrxC6a5ZsDeN5fYszFr13OYb3uKqVueYuK2SozfBYzaXIp2w4LA2m/PZJ32dC"
  "WxRv1L/EMPmFF/rOM95gTl5cy77LzX3KKs36yD/vJY7D6WLAWsryPGOhQUi3A+4hmOXUpD"
  "xJ0c1Iol/EPU10uEr0XSe5oWlzGdmK32ZBP7M2LPwuQfMmC0MRNjnEXQdwV0V2RDScuP7s"
  "OOENZxN2MdpJLJP7RxXwpQZgN8s3RsouAT/XHeOTvX6mO5lO9rDegS1NbWCq/9zj2Chnko"
  "pmxKwfBFlCuna3hVWCmsTSIWC9/xPfsAmlbXYLHzBUxdnmLSD5kw2pCOsWsfY/TqDIzYUI"
  "PhzoDO3CTIqe2kNew0Zmq7GNdf8uvud+C9ZmlwudBnPvQ9MEZC3tfDYsdjrPJNFHg4eyP/"
  "hahnGOoYi81nyrEmqAQDqd+u80/643t1EgkklDU9hzDorUyBiXMWJmzIIPY0jP7uMUY6pe"
  "IL8n7wemDwuhqofXUGrK1rHK2hBakJ/gNcbWl/Shv6bSIC499m/l32gKhaHKI+b7U7HUs8"
  "7ghcNTU1gvhPeHwO+ttfF/rMskOFsPHKwVinaFSJxOR/7R/f23QoGRpzYsj7LIzj7KuJfc"
  "UjDP/2AXQdU9DfqQx91wDato/pHuwCa7djCmvfBD+fxQbvt1AYHgiHI2U4nSSt0cbMBN6Q"
  "0N5aS/2mBr7hNfj+ZBG+WHQN2fkVf9SoqEaCOVtvwnBdClYEFsHBP4/6TC6GUI6e55ZTzs"
  "Sorq4W6uHX21QHs6NguD4Do1c9+YN9yOJUDFiQjD4L0qDtRBlaXok2/QLBWm+9zFR2yDfJ"
  "38/3fNfpV+B4BjgYK/X+XXa/q9Xw+k0E9yuV8PxVRDX4BHpLI+Ad8kTQlPUxGOxwG8sOF0"
  "rZfV9hvlcuBi2MRcLjIvpvJAJ/fb0Y6dml0LGOgv53b9l1OfvC++hjdw8685KguagEvZ3e"
  "QH1yGPG7ipny9gEy+XX3q7N+PmUjVt7DAuL/9kwdsdfhx4bM7OPsv4vgcaUKu2h/3UYzwX"
  "baW+19symzifhyWYLQF50OF8Fxfz6+8eX9PYf6/UsM+CYWT16Ukv+1EIlEwjXrVTm0aC4d"
  "4cTZH0p9J/a+9sRukwzNOYnobp2CzxfTfbC/D8XOnnwNC2XyD9pnrDDsEMx9irHgJOVuYy"
  "XmHxHh+E2xkBnOzn1vZHcOKcWm0yXYeKqYslQi7K3LD0sz08hu7fESptTXv1wSi/IqqvEa"
  "ESorKyk+YtxMLUR3q+vE/ugP9j72yQJ7z7l38dnMeLQwiYD2ggfotegRWvWmDLVw8ZPJ39"
  "9vZbuxp2BzVIx5x+qgsrwUbRzfYH1IFQIiqomdfP+lgf1sKXGXYB2fZ44VkeeFWEp7qqM/"
  "+e6XCzvvV7Dd+4ry9QxqM6LgcTZdyDxnr6ioEF57hqSj/XQ6Kyx5+DYzNnehST1TfVYCmh"
  "tfAxt3BepzE9GL7oHKF9SHmjtflcnfx8e369TLsA2qg+VhMVo4FoPNK0SHpUVYe7ocXr9W"
  "Ens5XBp85+yrj70WZrGlfJ4h3+fRPGDm+hSjVj/E5/bx6GYZiS1BT2gPq6PcVAnsoqpKod"
  "Ynb4hDV6t4DFqUir6c3VbK3s0yES1NIsEMr4CNvQjVGTHQcUyD2hj6t5LLI5n8n3td0JoV"
  "DrtgwNSvBvILisDsCsCs86C6OB9LfizBrp/LqK83+v6aeoyU3ZHYbalP9llwExPWxcHRKw"
  "XeP2UiJatU8Jqzl5eXC+I1fDWpgLyPRP8FKULee9lSZqzvoqtlArFHSdkNL4N9/QuUp0ZB"
  "a+EjdDK+CtbStUAmf++9Ydq0J9rRXG7kKYKcPbHPzyPlgs3NQSt78ta9ABtOUKaCGn0vIN"
  "9zsYBmGQuarY2+T0SFqFZg5KoTiwTmsrIyQaivQX5xNQY6xKDb7Dvo98199KK8axF7F4s4"
  "ygwxGoZK2cfRHDrmAtqYXIWG/QN0mhTJ+Utl8uvs/V3b8pqQH0P3SsjZ5YPZviLlgNm8BJ"
  "vzHGz2U3y+Mhu2vnlYGViAJQektcq9N6OsG29Opj1AjMqKcpSWlgoqI1WLeGbqkJZTgTFr"
  "49HB4jb1+BTB9x7UZ9pNi4H8hN+FvAvec/axNIManEfryeHoMT8VHSdF/BX/pZ4WYbA+Is"
  "EEz0rIc99tOHs21cELytEzWkMW2MwMKFmnY9jaZ5i55yXVag7mU+6nbqX5cdM9VIpqUFFe"
  "hqrKCsFvfh+KymoQEJqNnrYx6DgzDgMXpEKL+nsHi1toNonq1PBXsPGh77N/fQFsdIjA38"
  "0mFapG4ZT/rUVN8B9UN7kIy4BqTPWpRHM78t76xVv2ucQ+O4OUDjbrCdiMh1C0fAgNB9rD"
  "1mVCf206zY/3UVFFswT5XV4lwc+3C+ASnIWBi+OhTB5rWCeh57xEqsmbUOR+GpHn4xvZL7"
  "/PPuY8mP5ZtDW5hq7Er6J3EUzROV0mfy+vNSqjT8DcrwLT/Sqh4kD8cykz1k/pSppD7FbE"
  "bkXslo/oPjwAs0gFm36flAz5KQn4chXlp7qW2nsl7qSVQs6U12IUFE1j0NIsBgq8NnlfNA"
  "qTshv9Jpvd4JzA337aDajPS0GrAXS2ZJsiZdev93TFgQcwaXcBLPyr0M2J8mP1VJqZOQ2+"
  "C+yPyf+HUnaLFLoPycSfBDYpHsPf4Y8jfgWzG8QbTZ9dp2uElH0i5WBCWAP7rx9k5ud32M"
  "9A3iAEnWgf62SZhOYaAZw/UDa/jzbT2ls9dMldylANdDcVEm8mcWd+zD6Ts5PvM+6Bmd8l"
  "/kRivI0Ra+4JMxpNckjOKkcz8o5NJM9575DJflHo8++xU+6Z3kk0N7xI7IlQmx4HeZU9YP"
  "LOTk3wyzMN9zB1Yzrf+VZgolsJWtqS/5acPe0d9gcN7OS7eZKUfdodsMm3MGD5XSRklONu"
  "VgVORBeS/zHEGyn1fuLVJny/8D67/mmwkSeE7He0SkYbvcucvY4pOH8hO/8+jPyf37z/AR"
  "hty4OZdxk0naj3WHDuD31vyMy0BnazODDTW2AmsWg7Nx6d7ROgZEXvTbwu5X6PPbQJ9rNC"
  "brj3CpQdtRnxULNIQLNuBwhw4w3iV5Tdf4TnqV34s8kB9nEw86nAKJcCKFgRu8WDD3y/+z"
  "G7cSxMdzxBQmYFCktrEZFShmGrqD4MKTcTfv/rvDeyjzoF9tVxtDYOQ4eZSVAxjoKc0jYw"
  "uR9s6B7IPr/w56hcGp4/tNINxDjXPEx2K4bWMuqd5rxO38mMwB5P7PFS9omx0NvwEJV0fp"
  "FUl6PkDbVpSRVyi2uhvZh+Z2xTfSbkbWYa2JuN+Qmq5nFQJe9b9DnO6zaTyTm3b5KfPwOW"
  "qiNT35OraRZGNVBM6yiAmj3dAzOe9Q98nyrNDDO5hZOxxbTFViEvLw8FBQXIz8/nJ16sO0"
  "F92ICyM+5yE5lpYB8ZDDmSypTrUJ2ZiDZjaN2KWwjuh1nEz7hk8mvufaseHsvkenjSXH4f"
  "RruLMXLTK7SeTf5PTWhgJ9+n3ibvb1LdRguvLyTQ1i4uF/g5O78C1XA5VyDl59x/1mcaM0"
  "PcbCTPTTjtb3egTH9bQdWT5z6GsqNIYlwy+fmz67eSp3twqc3gQIzamI2x2wppXngBJQvy"
  "fsrtt+xTYqX8E25gyZFXwqxQ/LoAhQV5KC8pEmYeo+20fxiESrk/6jPvsH8VhFYTf0d78z"
  "tQmR6PZj3pvMI2lJL3Q0isUTL5u3u8I08uddZ5V1L74cH4at1zGLjkYdB3WWhLewmbTH3R"
  "5IZUk3mPiUAz8sw99DVel9eisqoaOW9qseJ4PuRNaH1jZLGfFDyX1zuB1o3s9HeU+vK9dm"
  "M1Y5tnv8veJD9/7v6hunoMZh12vFDWPYphKzOgtzkXX6x5hk7zkiHHfTeObBCfCWhvMrkJ"
  "TToP6rtkoosD9drxEX/CTnkfJe2RnJ3XqoppNGUmQfBdqT+9zzbXkhw+ZP+3+bk+cxvG1H"
  "ZktOoTQHN7Kr7ckCOsQXvRQ7QxvyVlH98wz/A58mvKigH1yDGXPshMiJRdj/JCfivQa94j"
  "eY/ntapCmWyuxTOzifM7/Rn7f8Sv7s5Ylz29meqO6GbdvaA5PQq6K7MwdM0LDHTKgKb9fa"
  "iYx9IcfBVyvL/zHkPnJn72YAY/EXNDXohXnq7Nx/2CtpOvCv2xw6wktKce2WZcOBQ7+/K8"
  "FxK7rSz2v8HPn/22YGo7nVm7HVWt+x6CpkUM+i9Lx8AVT9FvaRp06H70oPNIZ9p31Sxi0Y"
  "7O5ipm19HOLIpmyGio0Ro7CrNYIjrOTobarEQoG0XQXHYQckKP3BhOfH2aYv+b/Ex4Dqy6"
  "awRTdr1E60Dr3ofQmc572sTNn3Hw5wQ6dB7QWvgYmt/Q2cDuAbrbpgrz+2c0A3eyukvriE"
  "Nb/SvEfUi6r7KNacRlR72x2V+xfxJ+/hxYdZcc8U9krbcGkcoUOrqjVa9DUBlyCmoGl9CJ"
  "5h1+Xu1Ac5sa1TU/e7QeeBJKPQ9BoZ0bn8UkxB1HzItoT1KV7k1/zf4J+Rl/lkprYEx5ux"
  "Zr7WrLWmzZy5o7hzIll1Q6p+axVttK6FrCz3w0d6VTXUZRtn8kzlXEP5LUnM8Djfvq3+X/"
  "R//o39X/AamK9kk=";

/* 
 * Resource generated for file:
 *    history.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_48x48_actions_history_width          = 48;
static const unsigned int  image_Nuvola_48x48_actions_history_height         = 48;
static const unsigned int  image_Nuvola_48x48_actions_history_pixel_size     = 4;
static const unsigned long image_Nuvola_48x48_actions_history_length         = 6424;
static const unsigned long image_Nuvola_48x48_actions_history_decoded_length = 9216;

static const unsigned char image_Nuvola_48x48_actions_history[] = 
  "eNq9mQlclNX6x0+m/rNP1xY1M9LKtNLcU/+3RW/lWuZa5oqmlqYSXk3cQwQ1QUVRQUAQBR"
  "c2UXHYGRhAkFXURkBZZYdhGBAGZoZhfvc5ZwAlbVPvfT+fhxne97znfM9znvMsZ9gof8Ye"
  "Jh+cY2zMBcY+vcTY+CDGJgUz9kUoY1+GMTY9nLEZkYzNIvlKyqUTySA2M/Jrum/BpkUcZV"
  "+GB5JEsSnhMvqUsKkRx9n0iG3UZiG1fZ/kWfEu74P3NT2CsalhxjEm01gTgoxjj73I2IcB"
  "jI3+Hc7H4Z8Z+T6bEbGFTQlLYV+EaTp+HYWeS+MwdH0KxmxPx8RdNzCJ5BOraxixMRUmy+"
  "PxzJwo0Hx01D6LmPdQP5+QdPgf8ndg08LHsc9DzxKDttsCGcZZpWPjmQL4ptUiuViP9HID"
  "biiAm0qj/FoFXKswILVUD4m8Hpb+hZhC83qV5kpzMbDJoVFsavjXJF3+e/whnP9jNjE4iv"
  "43vLc6AXaSUkRla5BaDlwnzuRKIIm4k4j3chkQU2yUuJJ795OozTVqm1YBxObr4BxVibGb"
  "U0H9g/pNpjGmsckhT5q/A8k2Njbwbt/FMbC9WIK4Qj2SiFtGbOF3AN90HVwjVNjmdBtL11"
  "/B/JUx+NY8BkvWxGABfV+8NgEb7G/iiEQB71QtQvOBaHr3Cs0zsRRwjVZgBOmEjQlsZuOC"
  "XIj/xSfE/xobc1HSaZwESw5mIiRLi1jSqSQPOHPdgO0eRTCzSsH6n2Ox3ToKhw/H4ezpZE"
  "gjMmG35xi2bdkLabgc/j4pOOoUD2ubaGobA7Ofk7HZKRceSVpcor6iC4GInCasdc/Bi9PC"
  "wD66cJXGHvl4/BcHsH8G3Og5LRQHgsshKyI9ZwJeNwArrwosMouFhUUIgiXpuCnPR0lxOc"
  "rKFCgvV6KmpgEuLi6wsbGGQlGDiopqelaF0tIKZGUWICryBmysI7FgeSQ2Hi3C8VSD6DuK"
  "5uGVWIuBi2VgowOUxD/p0fgDBrD3/XJ6TQ3FiYRaBGYD7tcBu1A15q5JwrTphxHgLyUeBU"
  "pKFMRWTdwqVFbWEG8t6uq0xO9G/DuhVNahququeFZZqaJ21fReFX1WIVaWijnf2GPWMil2"
  "nFPhOI3hR/O4INdg8BKaw3C/emIZ/7f4R/u/xob5yHt9EQQXmQpn5MDhFGCdezlmLQyFz5"
  "lUOBy0x9atW1BcrBBsnJl/KpV3UV1dh8ZGPY4dc8fOnbtQW9sAlapePONSVVUr2iuV9Thy"
  "xBGbN69HyKU0mH4fhlUOhXBIBI6nA/7XNRiyKBpsiHchG31uwENZR/j+Vp5mg72De3x2kd"
  "hr4U792F4G5lvnYMXqEKQmZwkdyuW3sXDhQvj6+qO+Xif4amrqiVWNu3cboFZrkZ2dS+0y"
  "6XmjuMef8Ta8bX29FnFxCZg/fx5iY6+Ief16PQcbNoZhmnk6dssAxyTA+5oWA+dEgL135i"
  "axvfwA7xDv9jLo7NbOw7yxy78UrleB7dHAV5a5WLFSIvrn615RUUM6rselS8FISEgSrHV1"
  "DYJTrdagoUErpKmpGXq9oe1//oy3qatrFPxyeRb8/c+L/VFZWSv6zs0phJVlOCavuoqfpY"
  "ADzcE+RIlnR/ryOXg/wDvw9P3yAXvjZN03lulwvwZYhJLeD1Ri+aqQdux8/blNNzToyE50"
  "gonz8e9abRN0Oi564jcK/86FP9NodKJt6zsajZ7Wo070yfdHaakS+blFsLSMxIxtOVgfAj"
  "iR7f54JBusnyfYgNNL2zG/7dUqT7M3TsT2/uwCjsRp8G8JsNCtAVPmhuJqyi3BzvvnNs7H"
  "47Zwj0EnmPV6PZqbDTAYQEJ/Wi7+nQt/ptc3izlptXzu2hbbUrftD7EOZUrk3LoD0yUSzN"
  "xbBXNicUsDPlhMe6GPRxGxvtDG3feEUd48MZaZuBt+csmDdQxg6g2MWZwM71MJwk9wbi58"
  "b/L9yMfl43Odcu77ef/s4m35PPic+Zpxu+L7w7gO9/xUUvwtjJsrxRwPnbCFXy4q0bk/rc"
  "EbJ35o4+7jQXL8KfbKMZ/+EwJhH6vHQl/gs+0K4SPtbPfhwoUI3LpVQNzcbjVCuN6NOm/G"
  "30C/bw4Q66HV6sX6qdWNQi9cPyqVGnl5xTju7orFpnYYuyYXc84Ce+KAiSsoZ+rhmkXc/x"
  "Dsr7ox1sttGOvu0vTj4RyYBwETnJrx2YJYBPiGYtOm3diz5wTc3QMQHBxN+lGJsbkN8L35"
  "uBefA98bxn2koc8mJCWlYvnyFTAzW42gwBDMN7uMcQ56fOtHcdNPgY693UH6ni3Ye7oy1s"
  "158/PveGJHUCO+PAkMNi8WcbWcYml2diGx+2H79qOwtz8FT88LSE5OF7p/UpdxDk3CHvk8"
  "uF/y8joj1kCprMG+fTK8930OJrgBW0IM6Df2HNgLTucE+0tHO7Muh9JGTg3BqgvA6EPAqE"
  "WpkIami7jK/STfX2lpcri6+lI8daV5eOH8+XCyqZwnOIdmsZda7VOt1omxeS6SECPHyJlR"
  "eH+/AYv9gSmrroA9c6iO2Puwro6DWMcDTV9ZpGPmaaCfZRO+WRWL7Mx8kRPwOMl9Q6udxs"
  "enYO9eHlfdKXaehUQSRe0qnsgcuD3yNeDxgcc5vpcrKlQoKSzBqp8i0XdDHT51BcyPleDp"
  "5x3BnjvyFc1jdseujjB3r8Cow8Cr5jXYsJWYSsrFu7wP3hfvk+uHX2p1A8WuSFoLF5qLF9"
  "mXPxITr9J99R8DNjb+Abue9K4WY3B/xP2z0Z/WkB1X4pBDLEwW5GCwPbAhUIcefY+DdT64"
  "lXWw39D9NTesPa9Dvz1AjznZcKQcuLxcId7lffC+eJ9c/9xWW6+iomLKcXywa9cxHDhwmv"
  "bGeWRk3KY2+gcBd+yA9tSp+3ibBO+dO8VISbkhfNzp0xeFH+LjcH/KfRFff25DkoAU9JyQ"
  "gN67gBXngPc+8gNj+2gD27n0H3YGy3ya0X078OK4Kwj0Sxbv8Hd5H7yvVn/5MD+fmZlNtu"
  "QFKytnODr6ws8vWHDV1JA/p/0HBweoJ01CTVER5XtliI5OQFCQDGfOBMPZ2V/4N+4fdu1y"
  "ojVXCH/E8xFutzwu83w1JSEDA6bI8Ox6YM4Z4OOpwcS/hwpNu4tDPz6HOaSaThZAt3/FID"
  "EmU+TvdXU6kUfy/MbI//txSqfj+VgyfvnFlcSD1uMk6TMQhx094TzTFBdcvRBwKZZyan+y"
  "OU9qc5zm60S+xQ0BAaHkH67TeitEXOb6N/rSZpEb8riTk1mEj+fK8NRKPSYeBz79Rsr5Ex"
  "jbHz1qggTTTwBsNdn/+BgcsXelcVzJ37iJHPj27dy2XObPrupqFby9JTh40IP2SDjp9jCW"
  "rNqMLZYO2L/vJK3Tafj4SCjnTER+fgExNvxmHzQLPZWRzXt4nBQ1BGc55uSCcabEvESPD5"
  "yBcYsuE//edMYcYkZODMVUD+I3A0yIf7fVXlhbW4vag+fvcnmGyCX/Cj+/NMRg7+SJdeu2"
  "Y/16a/K3zhRPbChuXCX9av7EBzWLsYqplrO15Rw7SWxgu3u3kX8p8R+l/GAR+VB28BpjTp"
  "LBn4RgFum/ywbS/2cyJMjkIqflOSa3o9Y87Y/sp91VU4Orh10QHBqNGMrtPT39sYXq4L/i"
  "Z7mOWmMxtxseA7gfyaL6dJypDE+v0gsfOmYe1frsSCJ72tXjrVESzPM0wMQGeP1z2lvnU1"
  "FJ9aox16xv2b+av8ZPcchAcb+a1i+H/PZN8kclJaWilvmzd1vzEmMMaCA1GH0o9+OpiVn4"
  "YLYM3TZB2Pro6bHE7xzOnjmx7aW+57D0VBMG2AHDl2bgpFs8+dyqB/wn9833+8+HXvb2UG"
  "3aRHPVPXIewdf6t/4zlOrLwdPiMMCWahIv4J0xVJN1PH6SPXfatFN3HyxyqsX/U+7wyfYq"
  "/LI7WpwTtPLz+MVtiPsFbp+/e3l7o27ePDTU1T1i/G1+aPziZxoerpcxZmUmRjkAy07r0f"
  "2dQLBnT9mwF3xHsC5n9ePNczCdcrd/7dVh3eYY3M4qEH6X+19uQzz+GmvC37Gh8HDUL1iA"
  "u3l5j5w/3LP99vlDUWEpdlhF4UvbWown2593oBodu1H86uozj3UL6MKe9b014PMkLKa4MN"
  "0dWLAuGTHSG2S3VWL9eK3KYwDvl/vnB9bg2jU0zJ6Nmps3Hzt/M9bIWpG/cX6uw6QrWZi7"
  "TIppLgYsoLrqwyUZYF18NMTen3UPZOzFC7Zd347AspNNmE91wjyrfNjtjhTnTVVVdeSrE8"
  "Q5grHeNcZhPp64qqqgXbkSquhoPGo1wNezdd/yNc7LK4RUKhO1tlJZC9ejcViwSY6FxP4d"
  "8fX+KJ50HxBF7B3YyxSCXw4ay7oHYbp1JX4IANZ66/DD6kjIZKk4fNgR88im/f0DRCxurR"
  "t1hG9oaIDewgIqT0/oH5ndaDetNRiv57m+TE1NRfxJuJyMny1jYOGjwfdUvyxyUqOjSSjV"
  "YEHfCfZe4Vw6sm4h0b0/TcOPlF9vDAa2OpVg4Tx7cbbEz2d4PDD6UqrbyUY1vO4lH1nt6A"
  "id4fH0bmTXttTA9SLupKfLYbXjZ3y/xAbrdmdiEzH9dAkYYZoN9lJIBTH3FOwmUUZ5VTqL"
  "vSLFVJtqbKVa2T6qGavXSCEJTBV+gO8DUQuQT66lNFp36jSUNjao02ha6l/D3/aV99g1LT"
  "m/um0sPoe01GyqIyXYJ2nAtjDSvXMjOr8VQ7Wj1KqNu3dMq3RhPaOv9fgwHWbeeuyLBZyD"
  "a2BuHkrbM6ft/ERB+VTjxUuo2bARCvJrmiaD2HfGeri57fzk9+r1e+cnxnqR28z9eufnJ2"
  "VlSuTmFGHThjAcPFMMh3ie8wP9Z9wCMVYSq0kb9+vx90nCF6xnrH7k9yXYJQVOpgNHvYuw"
  "dUsY5XCFKFGS/UhjUGu+BoUZ2dA0o+38g7O0ngO15nqctZXXeI7V1MJ9/zv6ljz5bgt7Nd"
  "UV5Th4QIY9h+Q4ewPYE035ziYlmAnlbH3iN7djfjOpvfRJdO38bhpm7W+AYwJwKROwtksX"
  "Z/vFVDs2brBA3uUkqBr0VHOltpxvGte/9ezQWIdrW87dmtv+v/8Mkb+Tn18ozkBbbYbrva"
  "ioDEcd47DWIhZBGQa4JQOLnTXoMjid2BPjibFTO9630tpLv7QXWJ+U68//MwNL3JvglQbE"
  "3wF27b+GXWt8kSEJRxnlVHl5JWSby8U5gVrd1O7slucufD/yGo7XK8b5NbQ7w+X+nfvIRY"
  "tMyT5vCtvJySnGAfsYrN8Yi/gcPfxI9z+dM6DXpFyw11IUxDbkAd7+1x+Ut68PZ2+kK58f"
  "ky3mcF4OpJcDJ3zzsMIsDDExt+Dm5gozMzPk5haJHNF4Jnq35fypnuyiWeTvtrZ24lyKM/"
  "Nnrb8FGGNrjfCRO3ZYIjUlm3LsMBxxkSO92IDQW8A68oUmUwvB3kyvJ67xD2V9OD9j78on"
  "sr7y+ufH5mPZcT0uZQC3VUDUlUr8e60U8+fvpbophDhqRH7F43zrbxfGmK0T9Q/P3Y3zM9"
  "oIb8Pb8rjKY9Nl8u+LF9kIPxMYVoy8WkCaA1iQ3l+dWgxiAHtHvpy9fYP9Zf7+gp+xgVkT"
  "Wf+sgufG3MGUXxrhlQLRf4GC7OpsNunuMuxsZYiIkKOgoJR8VKWYC2cz/n7kKviNvx+pxD"
  "OeixUWlpHdZ+HQoTiqIWU45p6JjPwGFNYD58hmTI/q0H1yCWjsejYgawV79+bfY+fyjuBn"
  "bFDOQPZujpwNysOgH2phLQGSi4Fa8j3lyiZ4+/F1jyIOKdWMsTh7NoXidgauXy+ist2Z7u"
  "+mWJQveP39r4rf96x3SLHuJylcjv2K/BLay+RbMxTAfvJ5I9dRfB11h3SeXc4G5U5kA2+x"
  "x+RnbEj+K2zwnbNsYAFemKzApJ1auMQBWTQmPxHSUvKQm1+HgPPZ2GGdQLWWDJaWMor7Um"
  "z7OVJ85/e2bYujWiwDmVkqqDXGIFFQQ2k3+YhvHJrQcwb5yIHEPqgghg0pGEb87AnxMza0"
  "kLFhxd+xQcW5bGgpesxQYeJOHezDDLhSQGkclbX3Z6U6mlRjg1E0mvZnpSotcLUEOEYx8q"
  "sDTTCZdxdPjSwDe6+4hMbYwoYVdSJ+9sT5h5cwNqKsGxtesYoNKb/JRlSi07+q8frCeozf"
  "oYP5KQPsQoBTSUAYxY04KgUuk0hvk45TgQMRtC99DJiyuwn9vlWjyzgV2PuVoL5K2fBySz"
  "aivI8YY2gR+y/yMxqTsZGKrmxk1Vw2osqPDVWo6BPsQxU6j6/FP76sw8uz1TCZr8ZrJK/M"
  "UaPrtHr834S76PAxZyY7GapoYMOrpNTHcuqrl+hzRDn7H/IzNqqKRMnldTZSOZO4NtM8XN"
  "mwqiA2tCqBJJ3kGkki3Qsj3hPUxprazqV33ja+W2Xs6xH5/wP0PRNW";

/* 
 * Resource generated for file:
 *    download_manager.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_48x48_apps_download_manager_width          = 48;
static const unsigned int  image_Nuvola_48x48_apps_download_manager_height         = 48;
static const unsigned int  image_Nuvola_48x48_apps_download_manager_pixel_size     = 4;
static const unsigned long image_Nuvola_48x48_apps_download_manager_length         = 4024;
static const unsigned long image_Nuvola_48x48_apps_download_manager_decoded_length = 9216;

static const unsigned char image_Nuvola_48x48_apps_download_manager[] = 
  "eNrtWHlUVfUa/S4g03VCnGfNAcEQNEUTFdFIEUUR5zFRnyIGigM+xAE1J1RkEAQVQXFOxB"
  "mVyuHlcuiVDZZlpd7KyrKcQEDYb597DoItX6HcXuut1V1rL/gD7m/v37e//X3nABD8jb9R"
  "TvzhRx+nF5s1s8Vm1SnicxVRpsAXKlaeFuuIcLFwrcfTKkgZP2Xir4+qJhVjssQ2GmIdB7"
  "FaZ3pYx0Js1xILz4lZnTY81dZk/CtHR5I/pMZe1Oh2FU5+N+DQ/zocfE0DxwE3YNfpCsRu"
  "O4zn2IzaylMdylKHP+RfdZ25VF57XvTJ6Db5Fi5/B3zzK3DtZ9Ph2zvAuauAo+813n8CpF"
  "LEd6Kr4M/T7cvN3y7BRqquvSZ2OzAv7SHuFwKGX0rhVxOA33P3ETBh6V3efQqkyvIcMas8"
  "h6c3JXTl479CL3Zrv5GauzEr5SFu3geu/GB6fHsPGLf4DkSfBqm6LFfMKi3l6U7l5l89Si"
  "/2sQapuweh5H+N9/Xht6bHl6zB6Ejyr0z+9ivIv+JKnu5cbv61VumlZpxBGuxFcEo+rtwC"
  "Llw3PS7ze0csIH+7LZCaK03Hv85qvdSKN0jjDARtzscl9u+ZL02P928CQ+bR//ZbIbWjTM"
  "e/brReaicYpFkmAlMLcI53lX3F9Dh7A/CPIP8a28A7Mx3/+mv1Ui/RIA77MTHtEU4x5w5/"
  "bHq8wxoMCCf/WpwBddeYjn+DGL3UX28QpwMYl1aI458B+y6ZDhnazxNXNf51dkAaROeKeS"
  "XT8G9M/o2SDNLmIMZuKcSBj4Cd75kGe94HMnn3GR8C2y8UwWMq+7f+Tkjjtabj3zRWL02S"
  "DdL2kJG/cmbauefHlvPADnLfxe+Jyy7C65vy4Tk7BzV87sLM7UdIy12QpjGm498sXi/NNh"
  "qk/REj/608P/lfz44N76r8lZ8RewvRZ2k+7Ic+gPSkZ9zvqOh0C+K4B9Is1nT8W6zTS4tN"
  "Bl2no0b+yTw/7mTZEEvEE0lngIRTQGB6EZzC8mE94iGkfw50vg9g0fc+zHvfhXnPezDr+h"
  "PE6U1I8zjT8XdI0ItDisHCPYv8i4ycVmWXDTFvA6v5c+J2oM2iQlhOeATdmHxYjs6DJTVY"
  "DslFBb8HqEANFr3uw8zzNsR5Lz0Ubzr+rRL10irFYNlN5R91Anjj6O8gC1h+DFhxHJi6G2"
  "i7ArCeDlgEFcEmqBA2kx7BejxrMFbTMDgHFQYodXgAc69fIC77IA7rcsXCRPxbr9eLY6rB"
  "xvO4kf8Scpx/6OlYSEQeBmZlAL0TgHrzALswFZVmArbTimA7tUSD1Zg8WA2nhkHUQD9ZeP"
  "8KaZvJHkg0HX/l/19Mu17R6zhGk3/EQSA8E/hnKYRrmLEX8NsIuPDOmy4CmkQCDRcAtecC"
  "9nNKNNgUawhgHeglq2G51JALi353oGu/H9I6MYfnLiFeLDP/dml20m7bdHFNixaXTXHisj"
  "FeXDfGiWvKenFJv1fV+wT6bSzCyK3c0+nnwJ2qP4J2qf4emgp4rgParQJcowBnami1FGi+"
  "GGhEDXUintTwuA7jWIdR9NLQPProLnQdD7AGaQXSPOyitF6VbuRRGm2S3pAXprmSurWi7T"
  "H/DjuTxI2935bzo832J+G4FRW9sjAwtQgD0zgnyXXAZqB/CtB3E9ArGeiRCHQn/65xwMtr"
  "gfZrWIeVgNMyVUPjhUBdTUPFYg1KP0wsgPVr1DAyHxUG3SN/+v+ldEh7zuEOGtyKQW5uzF"
  "eXxAuat/SP+bvt+ko6vokGo87BNfQzOAdfRpsQDcGfoNPcrzGS9zyKGL4NGJYODN4Co57+"
  "1OJD33hTxyvU4REPdI4BOmgaHJeV1EHxktIP+hnUEEIvBT6CzQRqGEsNw3Jg3usyzHp8AL"
  "PuRJf3oev8b0jH96jjA+Isf8+gttT75B6gbGcl/klaLZ32onLvY/COuY1g5kjgAWAK/R7E"
  "vpzC3ye+CYzfAwTQN6/RN2N2wKhpKD3ln6bWw2cD4LVerYV7LOC2RvWToqEZNTSghlrhQF"
  "VFQyhKfBSg+WhYASr4FzCP8mD+ag7MPB5A93Iuud/kfHsL8jLz1SHsBrkrz5fNH/PXN64n"
  "zkv2KDWw6n4AXsu/wXRmzevkPTWzBEHElH3AJPbqxL2qFkXHCNZkCHUMTNU8laT2g6LhcR"
  "3YDy+wr+vPB2pSQ+VZWj9P0Xw0tjiPOBd8ORN634N5D/LvYuB8PgLpQn+3nndTLKttI/cx"
  "ytNJqfyxVPSIU1i6dN5dYN4tE56LvkIYszyMtZjJXJx5hBnDn6GsRwjr8vp+1mifWpdx1D"
  "F6h+orRUO/0hoUL63mDGNPO7zBXohUe6HaHM1HwdQwWavB6OK5xjz1yYVZz6sQj0OQbvSN"
  "Q8h1MbNMI89ALZusf5OflsZn/pZTYqTL7jxxz4Db7I8RcaIQC9/h3sLZNZdzKVzTNIt6ph"
  "9SdUzOUL01lrk0PF31U7EGxUtKP7SjhtZKLyxRe6EWe6HKbPLnfLMJKl0D+mjQQ+4VVyDd"
  "OQ+67yuSZuOukFsyMZ5w1N5v6Z6S/8o7o4bS0G+mdN1+R9z3odXkC4jMLsAK7mGLqWMR94"
  "IF2aqeOVptQg6ovlJqUazB6KWNaj8oPd0xWu2FVpqPlPlW/bc1GF/APsiHuc8liCe5e+wu"
  "kHqvvkdOccRIo0dErP5gflkQtaWh7z+k65bvhV5qEvAuFmXnIfYCd4PTwNJTqhZFh1IPpR"
  "bTDqoaJlDDGGoYxn7wYzb1YU/3TFR7QclVZTa0pI8aLXyyBrZTYayBuS8zpyfnmMf2PKne"
  "/gy5RBEDjPf6m3dyvzN/zYzvv2p19hf3hE/FYz8ajj2DOfvvIOkDYM1ZYOUZVUfk26qvZh"
  "8t0aB4adQONWOVXFJ85EEfdYouySNlRhv7IEydCdaBuTAfcAHixRnWZf1dsXd9S5vDvY33"
  "qd7rs+wPyuyuKrb1ukrnmAvieRDVhrzNPeE2NvKZL5bPAqu4Ty87rXpK8ZOiQfGS0g9KTy"
  "u5pPSCMh+UGnRRarBarUGLJep+UYsa9MHcn/ufhvQi986xt6VigwM8O4LwJGpo9/l8+w/T"
  "1TjvOiw+JL0Ow6rfMQxPNGATn/vi6afVZ1UNSh3Cj6v9oPT0RM1Hynww1iC5VB+sVPugKW"
  "dCteBbMPNltnszZ9yW3BQL/U6eN4PoZLy//8K9zO+f1Y+yb7SU9vO2i/dR6IjB8deMdVh3"
  "kRqUOtBLC95Se1rJpcAMdT4oNVDmdB/WoEeCmkUvsQYvUkOd0B/J/QTEh/nuEvq1mFmk8p"
  "wphLLjVDTB/ln6o+arS0iceGfmSJ8seC37HIkXi4waophPS06qPlL6ubgGo7U+6McaeNFD"
  "XZUacEeqO+0GzAaQe78jheI47lN+d5K2F7QibEz2/v/Jj9L/jaT5oFnis++u9DmKduEfIe"
  "58IdbxuXw5fbQwW62B0svGPtilzjVlT/LeoM6DeiGcS/2PQ3wPP5ImPsX5OIJ4oXQ+/gn8"
  "S/K1uf8k6bPrR/HJgvPsS1h+Ms/Y04u0PghlH0zhvjF+t7rzDWINeicXok7QJ+R+jJ7JyJ"
  "PGvc7zu1YTfk/Lxz+Jf0m+1nUfJF4pX0jfLNQefxYzMu8h+hww74S6b0ylhyYwS1+jhn4b"
  "8lB9IrPdNwvSe9sDqWHMx2WEj/Km8mn5+CfyL8lXu5Y9xDPhojCX7MacQcDWn7CUPgpjlg"
  "YzS4OowTfpHuwDztPr5N4t+pZUaXKQ/zuf6EHUJMyfh0A5+RdrUHLCRdyXHRHf47Dwz8bg"
  "5B8wn1k0m7PZb8Md2I5gtlMf/+Z7MbdK59+Havlo93v5+D/gXzpfHaTjgh30dqHO7wSfI7"
  "7DwOSfYT30pNqrHebeEJ1us7Y/OmtzRVeeQ03IvyRfnSdFie+RfBmYDZ0/55KSkU4Bn5ba"
  "H1tpesv9MTH/4nxtIK3HzxevzQbxSr0tLYaUzsdmz5KPfwF/0XqxDvEKMZUIIfoa58Yz5u"
  "NfxL9YQxWNc2Oi2vPkY1n5/7/iP91W2vg=";

/* 
 * Resource generated for file:
 *    mouse.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_48x48_devices_mouse_width          = 48;
static const unsigned int  image_Nuvola_48x48_devices_mouse_height         = 48;
static const unsigned int  image_Nuvola_48x48_devices_mouse_pixel_size     = 4;
static const unsigned long image_Nuvola_48x48_devices_mouse_length         = 4324;
static const unsigned long image_Nuvola_48x48_devices_mouse_decoded_length = 9216;

static const unsigned char image_Nuvola_48x48_devices_mouse[] = 
  "eNrtWQdQlOcWDclLDBoTYxI1EgJiQREVsKFoNMYYWxLbC5YoKlKMYK+IgEqiYqFZaIIKUq"
  "UpTZoUsQBLXViQDoJKV+ntvPvt/6/tPWOe0TfzZtiZOyzD7v+fc+85997vB8A76I7u6I7u"
  "6I7u+D+M132NHWvYc/Ro/QlKSuvWKynpnhkzelPs+HE78iZO3FOhrr73nrq6cdnkySbpam"
  "o7Q0Yqb7RWVNTboKi4boa8/E/96ev/eOcNvF4Hv4qKrpKysradqqph6ezZBzt/W+8Ka6s4"
  "+PpmIzKiFLGxlYiLq0VcfA0sT0ThpHUqTtumw2RfBFYsd+7U0DCvHjVqZ+zQob+ZffXVvO"
  "F0yR4UUm8bv4rKWnllZS2HSZM2N+rrO8LGJhhBQUnIza3B40agsRmoqwceVAOVNUBIaAZ8"
  "vLIhEgJFBUBpMZCX24WbCfVwc82GqUk4Fi0882iE0vbAwYPXLu/Zc2Afus17bwO/isqaua"
  "NHr65YtuwYzrrcgJt7CEzNTLGf4tChP3DJNwxZojqIchtRWAJERObA6kQM0lOAzHQgN5vj"
  "UH4XqK4CHj8E6uuIU0knPD2EWL3aFWPG7LouIzN/Nt3uo79aD4bfzs5uwalTp9aZm5vP3L"
  "Jly9e6urq9nv0+5XyJmppOm/G+QNxKbkN2LnA7qQaxccWIihYhMkqIW0kVuJlYgehr2QgK"
  "ToSZmS+CAuuQfBtISwayMlnugZIioKIcqKrk8Dc8BtrbuPdRkUVYvuxs25Ahhl69eskq8L"
  "p6JX49PT0rwp1nZGR0nzjUWlhYlB0/fjzJ1tbSWU9v10Fl5bXVpmbhuCUAklKB5DQgIwsQ"
  "3aG8Uk4Lill0IC7hLny8c+DimIdA30bERQM34iDmkEHfy6EaFOYDZaXA/XtATRXPoQFoIe"
  "11dTJerbCzu4Vx44yzBw6cs4gg9v6zWvD66dOjR4+pvXv3Xjts2LD9U6dOdV28eEHMmjU6"
  "hd98owtt7dNIIAwx14G4G6A8U/4FHA+hiN4n18DVVQBbyxx4u7Ui9ArpJ4TyGQbEX6O/03"
  "dSWQ0yqAY5QHEh6aiMfHKfOJBXHpJnGnkO7e2EqAu4dq0Ec+acapSVXbyL8PV7mS94/B9Q"
  "sJ6mSKFKMY3iZ1nZSfZTpmxGQsI93MkDrt8EoimfsQkQ80lOa4O3TyqsTwhxzqEJfl5AoA"
  "8Q5A+EBQGRhD8mkj4bS3W7BaRTDZiXC+5wXmY6qnwA1JLXHz18yqG1BeggHvl5DVi71qNL"
  "VnaZFeGR+U899wX/SvGf6UnxmaLi0pgtW86igmqdTXlOpBxGxgDhlNOI6DrYnRHAyqIcrk"
  "6AxwXAxx3wJw5X/Kj3XKbPhFIeI6hm9PmbVDtBEnk5jfMy01FpyfMcWB2YH5qaOB4sCgua"
  "sU7bo01GZuFRwvTVixxe1n+o38iMGrX6sdPZeDwgr4mo7okCLv9XQqvh53cbLvaNcDwJnC"
  "f8F88BXm6AryfVwBcIDuBrcJWrwfWY53V0R8R7gTjc4zlItPSYr0VzM8cnK7MBCxc6tvTv"
  "P30HQRtA8e6r8I8Zo6WhMXlDp7d/AYLjCQtpIJb0Exl9j2ZTKtqoaTyk+wQRTgdbwNUZ8H"
  "QFLnkAAbyGxD7gaxDLezmRrpEm4PrRnZzn6yDxQx3Vop7xeEQ8Grnf42JqoKFxqEpa+suf"
  "mF9fhX/kyBVzZ8zYjNDwfFz0fww3v3ac827Fccs4ZGbWoaMD4lczaTWeuLnYczXwvgixDy"
  "6zGgQCV4PJx3wN4qkGN+J5L6TwHPg6lBRznmZ9qeoB15tqazlfPKQeVUFzw8kxCwoKKyOY"
  "PCS99WX4lZSWzpw2bVOXv38KTpyIg7V1LOzsBThonkTzKhfOzkUoLGqC5HWb8nrOkfOBpA"
  "bMB6Hkg/AQjkNsFMfhJs8hleogTOf6aj55uriA01OFhEclN+tYj2X6EqZ3QfOX8219Ph2z"
  "m/ez1MvwDx++QJn2hRZLyygEB9fDyakANtaZsLQU4YhFDvbtE2Lv3kxcvFiK2vp2MQcBaf"
  "sCecFT4oNLvA9IR+Gko+jwpxxYHZiWmB+Yp1lfkuippJCbEWJN8TyYvxk/l7P5GDpUW0AQ"
  "p7I+8yf7wwdKSpoh388yhr1DDtzdK2iuEAebPFgQ/oMHs2FklAkDgxSYmmYhJbVezCElmf"
  "PCczoiDqFBnBeiJVqinpQQx3lakMjpSZjB1SJPwoNm9d1STjss/8wntxI6sXCBU8tHvRXY"
  "XJD9E/xS/fopq44YoVkwZ64pHEkvLufKYWWVy+PPEud/x4506OklQ0cnGaFh99HRxeWXcR"
  "D3U2+OQ1AgV4eIkKd+eKIn6q1JVIuUJG5OM1+IedC+UZDPzTtWj7ukq3TS3N498Rgw4LvL"
  "hHHiK/Y36U8++fpbRcVFuT/8sA+2p0Wk+wc4fDgbBw5kwdiYw79xY6oY/6qViXCwL0JDcx"
  "eiIzgOzAuMg6Snsp4UHszNNqYncW8iHtdjWW65XYNp6kUeknow/M5OZaShVUI2Y1+Bn80z"
  "Wiu+/Hbo0J9Tp03bCvM/EuDkUkX5F8FoT4YYv6FhClcD7WRorUiCw5ki3K/sEM+wiy4cBz"
  "9vzg+sr4YEcrOB+TqCeETxPCT70r/xyHi6OzGtBQW00H60vZywaf+F/Zlx6CUl9a6agsKs"
  "sAkT9Lp2G4WIOZiZ5WLr1tQn+HWpBnraAqz6JRmnrQqRn98p1hDrq5fop6/X077EasH4MV"
  "+wHsu4SGrCZoXYGxIeSdzMSKaeFRvJrtOMb6cfqiNcW/7i/s84SLO2JCMz0XbUqJUty1fY"
  "wMG5HIcOl2L9egF0dZN4/MRldSq0lgjgYFOMu+Wcj1lf8mZ9SaInqsVlP27+sTnB+izTVh"
  "jPh3FhPmF1YZyY96/S386ffQTzA4WY9f3RR4TH6L88P7I9T+7zz4dvUlRcUDxvvhmOHBPA"
  "5uQDbDBIh/aaRHH+9dekQm9lGrSXpMGDOLLzWHQkx8H9PNebWH9lmmL1YFxYTa74c/p6MS"
  "77dcHbowWn6T7btmXSmalAgt/kNc6/bH/q9/770jMVFGYnMD1t3+kHO8f72L0rD9paVAet"
  "FOhrpUN/OXH6OQOuZ8rxqLELQiGnIdezxIOf1cwbYi5eXF38eT5BAR0I9GuFj2cDzd1KHD"
  "tWBBNTEbZsTceRQ2WYPt28/jXxP/E1xej+/VWO0ZyoX7T4EE7b59KsqIOhbia0lwrE+Ndr"
  "ZkLnx0wc3l6EosJWNNGoE+VyumG1cHPmwuM8tz95XmAcuhAe3gR//zo6VzzAmTN3xfj378"
  "/F9u2ZOH6kHBqTjWvp/sZ/5/kJv4PIUX/6dbDCnJSpUzbBaG8ALrpXwvrYfRisEkJnUTp+"
  "W5wF3blZ2KGZBx/7apqjbWgkHhXV3DkugXwaRToPI92HsBlxtZPwNxJ+Oue7VdHcLH+Kf5"
  "sQ5ntKoaa2qZLuvedv4n+HPxf1pZgwcOB4+xHDNR8uWvw7nfHTEOj/CEdNymGoKYLuvCzo"
  "z86B7jTCML8IF/6oRlJ0E+1sHaijHbme9sx62gUf016Yk9eJ0NBG2tGf4j/K9GMigoXxPe"
  "gtj4T8oEX5dM+tbwD/s/1p8Icf9lkmJzcjRlVVu11rjRXcPbKor7figm09di4txPrv7kBP"
  "Iw964wqxUb0Ee2ZU4KhmFRwNCOvOBvjsa8K1oDZERDWJ8+/qWomTJ8tw9GgRXM9V4/jvaV"
  "BXN+3o3XtQCN1P6w3hf9bbn7FHc337DjEeNOiHjPHjddt1dE/S7nGb5lQtQjxb4GhaB9N/"
  "VmDrlDJsUKYYUg4DOdLbF5XYLleHyCttCCf8l3zq4eFeg8DAhwijM9OJ4/GYrGHS0a/fhF"
  "S6x2G2w71h/M/6gp31pvfpI39AXn5WprLyry0/LTClfnuZ9qQC2nUaER/cigCbZrjtbYGD"
  "fhNO/tIEpzWtuEmzLJGd1+LakZzYAC+vdKxceQojRxq29O2rdJOue4LtDuws9pbwP5nbzN"
  "+Mh7T0p9sGDFC7Mnjw/LsTJuh3zvtxHww22uOYVRAuuN1GQIAIV8MKERJcQH01E6ds4rB7"
  "tyedGy2gqrqZzr8z83r0+MSXrmVGMZdiIKv3W8T/LA/2PECWYryUlNSSjz+WPUxcrsrKTh"
  "cqKMwvHz58ad3YsTpN6pMMWtTVN7SoqOg0DRu2rFZObn7JgAGTUqSlv7jE62U1xTheo++9"
  "7vPbv8HjA75XDaWYQsGeT2mzPYb1cooDFL/zwfLMdnx9isVsV+Zz/tyz3v8h/he5MByfUn"
  "xJIc9zGsGO3uz4ynYt1s94H/V92TPq7v9/dEd3dEd3vF78C7l0oAM=";

/* 
 * Resource generated for file:
 *    folder_blue.png (zlib, base64) (image file)
 */
static const unsigned int  image_Nuvola_48x48_filesystems_folder_blue_width          = 48;
static const unsigned int  image_Nuvola_48x48_filesystems_folder_blue_height         = 48;
static const unsigned int  image_Nuvola_48x48_filesystems_folder_blue_pixel_size     = 4;
static const unsigned long image_Nuvola_48x48_filesystems_folder_blue_length         = 6164;
static const unsigned long image_Nuvola_48x48_filesystems_folder_blue_decoded_length = 9216;

static const unsigned char image_Nuvola_48x48_filesystems_folder_blue[] = 
  "eNrtmXdYFNf6xwdbmi2JaKwhNlAUxRKxXWMklmvDAoolkiAgGq4SigUUsAGiYsGCCoIVsQ"
  "GCooB06SpNpAlIEUUQdEV2Yfd73zMzSzDl3uTGm9/94zfP831mB2b3fN56zpwBwOH/9X+q"
  "d3nMnj37kyVLlvg6ODhIVq40idfV1bUfN27cVz16dO9A/27FvePjXfPPnz/fKTb2DthRU1"
  "OL6OhY7N9/QG5mtip71qzZbpMmTZqmqanZhW5t/b/GP3funFa2tusTGxub0PJQKICXLyXI"
  "yMiGv/8VhZ3d5koDA4OQadOm/TB48ODe9NW2/wv8M2bMGOzt7VOPf3PU1zfg4cN8BAaGwN"
  "V1d42ZmXmknp7etilTpuiqqal1+iN59m79r+eQmJiEP3JIpU2orKxGVFQ8PDyOKNats8zT"
  "1zfYS76YM3r06K70s23+Kv7vvzeOral5gf/0aGqS4/nzWqSmZuDixUCFo+O2p0ZGRjeppi"
  "x1dHT60xDtSCr/DX7qO597eByqwzs8amslSE/PweXLwZRne+pMTExjFy82dJw4ccIgGvI9"
  "Zsu74p83b55VbGwc/hsHq/+6unrk5BQiJCQcbm77XlO92NOwXd8VP8X5RmXlU/wVR1nZc9"
  "jYbCijYae+C37KHVV3d/fn+IuOp09rYW29oYaGXvcu+BcsWDAnKiqa/225XPGHpSBRlryV"
  "L791LzvS03NBva6Ihrb9t/zfxqtwK+Lf52Z6t/157SuPFStW7Csrq6DfZ/2w8ReSyRrRSG"
  "qieU3e1AT+RshFZpJCjjdvZKiseYPMkleolcj4e3/5O00kBfWmIGhrayfS0GZv8Rve6srp"
  "39Dh5l/T5+YHW3ILQg9wiyNucStii7glEfe5Gcd+oLs+btmTDRcZtLe3ty9kcxIbo+GNFL"
  "IGKeQyGSE2sq5IeMLfa1++wZPnr5FeVIug1Kc4fKsUWy4X4bsT+ZiwMwtqNnfRYXUK1p0u"
  "QJO0gWyS8nOdUlKpjPrrS6pf90ZVVVV/Gl6P518eq8IZRmx/zzix7otN2XKdXUVY5FWBzc"
  "HP4ZX4CqG5UhyIfY1Oa9LBTXL2oO/1VtpgMH/OlIBL5/jA1kvq8bxGgseVL3HnQRWOhz/G"
  "j2fysORQDqa4ZGKI3T30tkzFgA3pGOdMOXC4BCvPVMAxpAqnU14hvqQJruG1UDe5grj4ZF"
  "Q/fwGJ5A1evarnVV8vRW5uMZYuXf6Uht5NGsvzG4Qb97bOwOWsRqQ/Ax7WALmkLKrIu5VA"
  "dAmQ8gT4zk8CbrZfOde5nyE3zkGH0wucOMRgh5/pwTh855mP6a6Z0HFKh7ZDJkZtzcbXu/"
  "Mw//AjrD5XBufQKvgmvcTNPBmSShXIrgIKamkcmu6y6HNKBY3zGPBIkEJ16Xn4B4bhcXEp"
  "rZvq8eIF5VQtUz3Cw+MxZsyYNGK3JPUV+SP+cfUF4ssA77vA0RRgXwLgEgNsjwK2hJPCAH"
  "1yM/dtilxlcZjkk9XJMjXbDMXknfdg6FUGi/MV2B9Vh6AHUuKTo5Dsr6KVUHUD8OQ18IhY"
  "KSS8PxJonMhiILQACM4DAh4Clx+QcgD3BDl6G1/FQd9gFOQV0Br2Faqqailv6vi+4+V1Wt"
  "69e/erxK5P+lTgv5m07PxL2BHjmgDA5BLpoiBjf8D8MvGHAvtjgeNJDQjJaURyOXC/XIrE"
  "vCqUSoBnxFr2CihiPqW4ZdBUkEo+TSolXtId8m1ciRDL24+AsELghpI/R+C/kA24kd/Ufw"
  "iF3b5LyMl6gGfP6vDkSQ3Pnpv7GBYWa+tat259kNgnkt7n+fWuXJq4r5L38ZF44OJ94Cb5"
  "JI7GuUe+yqWcyic9qibGl0AenTPoOuphNW4/qOHjn0m898m39yjP7j4R2FPou0mkROKPJ/"
  "5YYo8iv0fQ794k9pB8ICgXuELsF0mn0oE9yYCWdTRMHM8h4+59lFdU03xVRTa8QExMMmiu"
  "eUTcbO4d1Lx+mHrWdcqeR3xHoxaBYuLLI76sJwJ/Eo0ZR/6KKxJ4mD/jSSF3K8hG6nl0bz"
  "qx3/8Vdt73pFjij6bfuV0k+p7Yr4m5w9gvZAGeqRRj0ljHFMy18kVKQhKKi5+ipOQZ2VCD"
  "CxeuQkNDPZK4jUk9mtdvut4WWpsf8LmaTnmRTOOk0Hipj4VzIvktoVjwY4Loy6hCGYLTKp"
  "BcpuDZm7nZ90mJLexkfm/JHprfIu+zBXbm+4O09N5Ptad3qABjTX0QHhaNwsJyFBVVIi+v"
  "HE5OOyTt2rU9TtjTSR2a+b/2nNtnXZoiizgesLym/pDBuEh36XMKMSSLOcz8GEO6kVmLGx"
  "nVSHvyNntLnzM7Y8ScYezhYt5cJ/agh0K9+hP/2QzqGcz3iVS/ZIP5xRr0NfTGpcuhyH1Y"
  "goKCCqSl5WDZkkWPCdmJpKV8/uT5J+3X7mgUI71TQn2jkrhLRfbHxE5KJI74krdZAqihhu"
  "e+5vn5Oi1/Oz5xj4VajRTznfc7Y1fmvMh+PlPoeYeSBf69VL8bbknRTd8Xx3wCkJGeh/z8"
  "SoRcuwFNrVEJhLyKe09V7a31/5f2Xbn5oTXBOTKUUu+4R8xpJcROSihWIJ4YYkiRRWLt5T"
  "XhSnIFYovlSC1v0WNKBW5lvkS28DnL95C8n9hZzjP2k/eEfu2RLPTs3fTov/m2HH2+9cdW"
  "dz+kJGVQ3ymjZ7Ojio6DDAu50YfS2n7tl6OiaTOX8Dvx/J9Pb8vNuHzP684rUJkjpUhBNU"
  "DsdI57pEA0MUSSwsmHN0lBWRIE3q/mmRN/xs3sjCr6yec3RZ+zWg1Usot+96E+dyyNeh7x"
  "HxB9v4v6nxPNOwPNrsHCwQfxMSnIzsjH6k170Ms8EsMPy9Hl+xRwvfT2EP9wcf2jwk0547"
  "cpoApl1L8TCxW4Q9xxdI4uUOA2KaxAqLvrdL6UVo2QbAk/D8Ura6JYyK1mn4v5wnrkNeIO"
  "FOcoVqunqVZPUs4cTxPynvnenfjdiN2Z5pidZIeW5W0YrPVEbGQiIm5FYIr5Xmg4l2LUce"
  "CDb85JuHad2RwwqXn9NunE9kWej1FM/o/LVyCWmCNJEfT5Vp4CN8h/IYwjR47zCRUIy28U"
  "+mKLumDsyh7D5zkxXyJmP/L1GapRn3tCrjPuY6mC31vmjQs9vm2nZfhOsmXc5mTorvRAZF"
  "gMzbmnoGnsiSG7KjHYpQYqGmvYHLC1hf85bvwh87Hbc5FP835MnhyRxByeq8BN0o2HCgQ/"
  "ZOxUc/fq4ZdYyfMyfsbOcoX5mfWTc5kCJ+M7nCwqRchxpRg3q1fWL/cR6x5idyXf76C8cY"
  "oEtpIdcw8WYuyKowi+eh1WDrvx+Uo/DN9XjT5WeeC6ToolYlNSr2b+sftmqlumKti8E5sv"
  "Rxgxh5Ku5yhw7YECAdkKPv7nU2pxJe05IonbP0vg2CWOzcTiz/y4O56tZYSeciBJYFWKXS"
  "t7jZvo952MPYrVLonOJv4vMHL5CZz2OYOpKx3Re/V1DNtThQ7zQqTce11OE/FMUsdm/jG7"
  "tD5dfrshjNhZ/oQS73XiDqLz1SxiJ7F1ik9KAxyDyuAaLYUj+cqOjUdnBxpza5RoQ5xgE8"
  "sJ5lvGyWxxFz+zv7H/7aL7XGKF77DvbqHf2RRB/ZO07noDhhufw+69h6C1eCv6WUZg0LbH"
  "aDXS+RnRupJGsX27Zv5hNl1VZl6tvnhfinjK32uZcgRlKnAlg9jZmfidwhTQPQGM2C/B3z"
  "0rYXT2KdZeeY6N1yVwoJ7nRLm7jcWB1WCsEAvXOEHMHl7iNV+ndO82+o6j6HfGbnsLsKF1"
  "mM2tJgw0CoCppQPUFrpA3TYGX9jmQqXvt1lEa8XWzm/tn2j9+AE3+dzDI9G1/Prh6n05Lq"
  "creF0krb4ox8AdTVDfJYfWAVAfA0YebcRXR2sx27MCy33KsObiM1hfq4P9LRkcIgVbtscI"
  "tuwQ/czqkzFvVXLTffbEvZHW6LbEbXWT2MmWqfQM1f5rX/xtsS16GezB4M130cM0sUmlQ7"
  "8A9thHUv3Z/pUKN977tsPVJ7hPNeCfJqd1qMC+/GQTPt8kw8BtjdBk/O5yDDuowIijwGjq"
  "Z+O8gL95NeEbLwnmeFVjsVcpjE+Xkj1VsAp5g/W35HxuMF4WI5Z37Nqe+Zy41/P+BiyJ3Y"
  "qu9U88Q6d5Mfhk7i10mbwJvRe5Y8j2Anw8/UQNp6Lirlw7/2L/7cujZ01PFCKb1sJnk5n/"
  "5bC+1IheVlL0tZNC3akRg3c2YYgbs0EBbQ/Bhi+VNpwEvvIFdH0VmHHyNeZ6VUHfuwJLfc"
  "rx/ZlKrLpUB4vgRvxInLbEuUFkt6brdfR8sZbOpgFSdFkUjTXeNRjyQzrajHeB2jIPaGwp"
  "wIfDLHKJcgNpoHIv4S1+bXfX2S5Z/Pr+XIocXnfk0LZvQM91Dei3UYoBm2XQ2Eo2OJMNuy"
  "kG+xQYrrThGK17yYaJ3mQD2UGhxzengWmk6aeaMMv7BfSOlWLB0SIYeJXD8HQ1jC5LYXqN"
  "npmuAxaMn2zRtEzH9C35oCkGQ61yoDJ2L/qb+6OvZTba9pwcxbbKSJ/96v7ncNeVo2yS+O"
  "cn/7sKmHjJoGpajz7Er2YjRb9NUgx0aITGNsGGoWSDFtkwjNlwBBhFNowRY6G0Y7KPYIvu"
  "KRLZ8o2vHNNO1GHG4VL83eMRZh4pw8zjVTC4IMMkt1J0M4hBGPXsjZRbw+wfofV48v2GO+"
  "ixPFza6gPVU2ybXrl2/gX/ELsxat/dlrE1zdlkBUauf4MuxvXobfEGn1s2UP03oL+dDAMc"
  "ZM02CLlEsThA+XSI1TTVRAs7xou2sNxqqYlMXnJM9HyNvx2pho4r5cfc29gTLOH77EJ6Zp"
  "11sALtdM9hoF0OOny5qYQId5BGtNy/eYu/r1GXDnOuVgU/lONopBzdjV+jK6mn+RvBhh8b"
  "0NdWytswUGkDqweq6aF7WCzkGE51rU29ieXUKM+fbGHSOfGT2DWrG1b/o+j6A8NELHUr5N"
  "d7C/yA1VTPZn4v8MGMIBr/Ltr2mc7WzqtJfVruo73F39/4fW6Cb7ZvmgyugU3obChBV6PX"
  "6G5Sjx7mFId/CDZ8YctySYb+W2R8TQ+ivspiodlsh4KPB6sNFpMRzJ4jQmyUYtfs7yPJvp"
  "5WxRhokoYbND+aBAJGQdRf77C1hRSdZwXi/W/Oy1Q+7HGeCOeQOv+L/X8VbuThcOeQKriH"
  "KPC+3kt0WSZBt+8EG5rjwHKJ6qHvRrLBnmLh2Aj1raIdLmI8qDaG7hVyi7dnv2ATkxZ9Hr"
  "qf2QcMcKpBZ/04nEqQ8XPbfD8F1l5vhHVgHVZ5leDjWQHgBluzvWYX0mjxHcZvv78Y4rxj"
  "qGkUbKgvdP++Hh0XvoLq8l+3Qc2abFhPsaB86r+Z2UEiO9QprzR2yjHIVQ5NN+LdS/OdO/"
  "ma5j0disc40gSKzfj9MnRaGIVPF0RiqMU9fLYsBl0WhOKjaZfQZuIZOTfqqIwb6ljNdVQP"
  "IjKTn+fOr/KrTujNDd11d8CadEymHv/ZtxJ00n/Fx4HlUjeqh+5mlE+r36CnRQP6WEopnx"
  "oxwK4Jg5yIdSdxulFeE/doVxlG75RA2+EZhq4vhsbaB+hrmorey2PRdV6IvP3kkw3cMOc6"
  "btCGSu4Ls0dcb8NM7rMZd7hPdW5yHQb4c207eXIqrdhax1xc73z0O95/teO66eq20nav1N"
  "5YjPHOCnRd9hqfLCZ2I/L9qkb0W0frCBuq3Q1SDLWrh/bmVxi+iRhtiNGCGI1T0N0gXNFx"
  "6gV5W53D0tbDdxLj+kqun1kR11M/k+vyVQzXvt8lrs1HnlyrNrvE/Ry2H2hGWs5eI4t7DG"
  "ye1SapiT1T5Xe+v2vPdZu6uNXIg3WaawswZqsMQ6xfYtC6cvQ3e4BeyxLRbWEEPpl9De2n"
  "nJe3HXNI2mqIQzXXz7yY67Ugg1PVjeM6j7jBfdjnHNemwxGuVVvGuJn0o8i4lL32aMGnTv"
  "qCrefZOyFxj7u9+I6r9W/t2/8LfhW+zrvPWdVGe2/lh5N8G9qNcK5V0bB+wqkZF3I9FhLj"
  "lHju49Gh3Ed9LxAji7OLOLebi3zz2Psd0jiRUUNcMyoZO/0evj/x/pf95qekr9h7GvF5zU"
  "78zJ59lolxnkaawGZv0oAWfJ3FfG33Zxn/xPtf9h68o5h/GiIf+9yzBWP7d+HH//T4J9ZZ"
  "RSs=";

