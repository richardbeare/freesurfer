/* 
 * Resource generated for file:
 *    accept.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_accept_width          = 16;
static const unsigned int  image_Silk_accept_height         = 16;
static const unsigned int  image_Silk_accept_pixel_size     = 4;
static const unsigned long image_Silk_accept_length         = 884;
static const unsigned long image_Silk_accept_decoded_length = 1024;

static const unsigned char image_Silk_accept[] = 
  "eNqt0+tLU3EYB/D+jp1txzaQQEYUIkgItVdBIrFpNhTzsixNd/dKZzOGzbQoI+dljJTSMk"
  "utNufUpk5tbk0pE5cdJcTcmy5UG0YX+/Y7g4mB9MoffOH34nye5+Gc5wDYhz1Mof+oOG/m"
  "CJPjTWUznx2KyEYlEZk7iZW5kpgMxwHx/2y+L02u8KaEDV4F7oSs6F/pjqVrqQWl7pOQ9t"
  "FhaS8t382SnvKsieTojXkTXGsDsL+5CfN8VSzc3bnWj6bZahy2C6IpdsE/NXK9qaIsT/IG"
  "Z7nnaoPlqAyUQjd7HgaSCpIa/wU43j3ElelKSKz8DcktvijuFZ5ko2Y8O9aXs5zT+M5CNV"
  "ME1XQhtNNF8KwPwehTw0lq5PUeR+J1vjHuM0clbFeoBbZQMyr9JVA/VxJXAPUUibcAE+/d"
  "4E44uo72V02wzzchoYHPxv0JR+Lm49V7qAvqoPcVkzkGsfR5AZrJIoyvD8fs761faH95Fc"
  "bJEvSHuiA0UZtxL31Ebw6s9MAU0KAuoMfXH19i5tP3D9vWOtcArTsHjOccBkKdENbu8L00"
  "e3uhGR2L12CYUsLir0H057eY3fqzBeuLyyh3ZUNHfGuwHh0+C+hqanv+tLtCo3IwHY7VB6"
  "iZVELrOYP6mQosf1xE+1wjyoZOQeU8DYMrF463PciwHQNdRW2/vxSbQHSQfBOLV4cn7H1U"
  "jeVDP5ILzbACaicXzubg6XI3TMMlEGp5G7SWEu3cgaRmvjyhkYqaPeVwkhptQQuYsWJcHF"
  "GijczvIJZxFUNQxosSu+sO7m/ky2kzFZZ1StERsKDvtQ19CzZYfWakt6ZBqOKFac3uNh76"
  "El9MGymGrqVYoZ4XEWp4EdKPJWHoMkqMPf5f/wISU6zl";

/* 
 * Resource generated for file:
 *    add.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_add_width          = 16;
static const unsigned int  image_Silk_add_height         = 16;
static const unsigned int  image_Silk_add_pixel_size     = 4;
static const unsigned long image_Silk_add_length         = 808;
static const unsigned long image_Silk_add_decoded_length = 1024;

static const unsigned char image_Silk_add[] = 
  "eNqt0+1PkmEUBvD+FvhSm1usnFnTTU1XbtZ0lGHo1CmakgihU4gHJEEEVBYpwnypVjAFFk"
  "vexBcWOjMHaikt9YHpWrBaW1vB/Hr10AbTLf3kvV0ff+c+99m5AZzDGUY730Hv9wkIhYdH"
  "9jhbE5K3zYmuNw2k0FZH8Kaq6adbIVM1K4i/3hhGML6M8M9NbPxYw2zUAZmvDS1mVpzz8g"
  "7zZMtPzkccOPgTweI3D8zkGF7sGuDYN2Pl+ztolkSonSxPssfKjtXQzAlplI1596yI/N7B"
  "xI4ez9b7MRRSwBDWYiSswdBWL7wHDhA+LiqNN2MVw8W0tKesdHRViS+/tqj7RjC8rYH6gw"
  "zpo1wXQbLMhXS1He59O+5NlqDsaYE07XvdbaQnaqf6tGAgKEffmgSiRV7Gt9rZ6Fqog3Cu"
  "GqZPWuhXenBjKI9Me+lMy6H/qwejn7WUFeOkw5+tgjTQAmt4AkXa3MO0Fzs4h87oNDSbBO"
  "ShzlM94W+GLTyO/P7sjO+015PGkAaGbTXE77ngBxrAsd095lJ55GNjNKTEoP8xrioZmf75"
  "0zXSBzYmXFErRIFGCPy1/9571PPcLHR4q+Has+C6LhfZT7Iy8+NaqmhNrypjhK8VM+RUZl"
  "Yp1+5OJWXZcO6a8dB6P2VjDNkF2tEdqH9ewawZv5XsdjXCTdUwhlQgFpogmWuEMdgHF2W5"
  "Vhay5VlJyv53B1mmUibTUBIvNxVCt0TA8tEAy6YBan83igZzUjZ+kk3ntr6QXqrLJ4oHrp"
  "EF6pxEnupS4oriInlZnkUwZOfpOOP/+hfbS8sf";

/* 
 * Resource generated for file:
 *    application_xp_terminal.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_application_xp_terminal_width          = 16;
static const unsigned int  image_Silk_application_xp_terminal_height         = 16;
static const unsigned int  image_Silk_application_xp_terminal_pixel_size     = 4;
static const unsigned long image_Silk_application_xp_terminal_length         = 788;
static const unsigned long image_Silk_application_xp_terminal_decoded_length = 1024;

static const unsigned char image_Silk_application_xp_terminal[] = 
  "eNqlk9tPknEcxvtTgAkDxklAEBDkpLixsckZBKvlOiwTD8hEW6s1qq1ZaZZLyzRdYknLVj"
  "ZrtRRadlBG5bJSrl13bd66J34/9ttyedHmxbP35vt5n+/zfN8XwAHsQxdmN5f65za3+6Y3"
  "0Hu/pKkfSN5bR3JiHYnxNXSPfUXXnc/oHMmj/dYqYjc/onXoPXpHctsd17NLqdnNndWN3x"
  "hf/IXBha099XZ5ZdcTLXZM57YQu7a4Q32nfiI5WfbtmfiGxN01xMe+oOt2oew7vIK2G2Xf"
  "kwPvcOJqDsf6szh6+Q1lKysroVQqoVKpoFarUVVVBY1GA61WC51OB4PBgJqaGhiNRtTW1s"
  "JiscBms+HIxVcl3++U4XA44HK54PF4qKioAJ/Ph0AggFAohFgshkQigVQqhVwup3719fU4"
  "lHpBd2Z8Pp9HOp3+b7753HPaMdmRzReLRcTj8T0ZkpHlczqdiJx5Ru9DcolEIhQKBWQyGc"
  "hksn8Y1kd1dTX0ej1cLhfCp5/Qjq1WK51XKBSUYT0ShogxpEfiReR2uxHsfUzv43A4djGs"
  "d8aQ7k0mE+3ebDbT/n0+H/w9GcSGP9EsxIMxf9+K3YvsSGS321FXV4dAIABv9yzahj7QLG"
  "wv5sMYcmfGkM6JGhoaEA6H4el6gNbBZZrF4/HA6/WW9/L76fuJgsEgQqEQnW9qakIkEqGK"
  "RqNo7JzBqYHs6PEr5W+x5dJrHE69xMHzC2g+O1+6z1PacbBvDoHkI/gTmdLOD0u+M2jsKK"
  "l9chT7/H//AJXgQW4=";

/* 
 * Resource generated for file:
 *    arrow_refresh.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_arrow_refresh_width          = 16;
static const unsigned int  image_Silk_arrow_refresh_height         = 16;
static const unsigned int  image_Silk_arrow_refresh_pixel_size     = 4;
static const unsigned long image_Silk_arrow_refresh_length         = 752;
static const unsigned long image_Silk_arrow_refresh_decoded_length = 1024;

static const unsigned char image_Silk_arrow_refresh[] = 
  "eNqd09tLk2EcB/Bgf0bMDlqSSBdWyDpnmazlicyg1ebjmo48NLDMuVjT180d2va6k5pjw5"
  "KMSnihaERltY0N12H5EnTtnQjehnfffu/oYo1p0sVz8/J7+H7f34cHwA7841x53DTUOqOU"
  "YRuzpU7zdIOonDgT2Wqm/6NOfvOt1qh/pY5rF9rXrj5pwaWoCo3hehiedqDzkRpHLYf5Un"
  "f7FjsVhjcagUua4M86EfkeRHQ5hOkcj+DnB/AtjWM8ZUVbqAnVfZVjhXd733XIu19fE7xL"
  "Nsz9mMHUNx8e5vwIffGAzzrgTnOwpSy4/8mEi54G7NPvdRXep75Gy4c7mBWnEMkF4cnYoZ"
  "/X4LRdIfXFocGDaOaVuOCuR4Vud6C4u+Z5W9yZtObzXCkO59wnVk5ytZ7CmcqucrGc7YqV"
  "+vfLs42rtN8N2u+vOsex9ePWI1zxzB5tmblMvVNGWYwsGVkyVeAsoyxG+2XnvacY9WXUl1"
  "FfNpDulhkTN8wlsjjKWv+TtUFZq5tYxshSLPxGlh7KWvGm7eThwODLW9Ju4iUsA7aMGSOJ"
  "u6C+oL6gvuh5oYM7yeUtnelRtE+2SJbGIksXlzJh/mc0bxkTJ/+yHE0M5y11c9dR1bNfIE"
  "t5keXYvfcDiC2H85bhrz5MZF1wZ2wYWRxG74IerX4VDhgqBLJUbPJW+H6hC4ZnTLIEWaLW"
  "XIOa29Vr1DdOlkaylG/1FqS3QvsV//e9kaWMLIe2M/sbazyImQ==";

/* 
 * Resource generated for file:
 *    attach.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_attach_width          = 16;
static const unsigned int  image_Silk_attach_height         = 16;
static const unsigned int  image_Silk_attach_pixel_size     = 2;
static const unsigned long image_Silk_attach_length         = 368;
static const unsigned long image_Silk_attach_decoded_length = 512;

static const unsigned char image_Silk_attach[] = 
  "eNr7z/CfRLhUes7LKae6bZoMsckuVpz9ctL1rkcNW/v+59Whyy6Snnl/4saOi3VB/xlyLJ"
  "K/ocrOF5lxr39z6/pafxAvQTviObLsPPGpH3q2tMyvDirkzjwY3xK21QdJfo78lLfdG5pm"
  "VaQWCKUdje0InuJ9000UJjtbddKTrvkN08vj8jhTbsV0BS30fOQqCZOdqTjxQceMuu4y7x"
  "zO5JuR9QGLPF65ysNkZ6j3v29dXstYvCbresKziAb/BR5vXPgQNve4tzyqlgCx4jvDYnxm"
  "ut92EUJ2d5NexcsCsEuCVb0Xu910FkP1dTl33taULTGqQdael13vOclghmkyb6RXwHmPp6"
  "55jgL/GagLAckF+iU=";

/* 
 * Resource generated for file:
 *    bin_closed.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_bin_closed_width          = 16;
static const unsigned int  image_Silk_bin_closed_height         = 16;
static const unsigned int  image_Silk_bin_closed_pixel_size     = 2;
static const unsigned long image_Silk_bin_closed_length         = 344;
static const unsigned long image_Silk_bin_closed_decoded_length = 512;

static const unsigned char image_Silk_bin_closed[] = 
  "eNqN0b1Kw2AUxnEvwJvoTekodAiCgqIuKjhUKXaog5BZSqWIjd/agktdopsflFIaqlUwtY"
  "vdKqgkfx/j4Pt2UR5OOPDj5Bx4GeGfqaU81wtOPipUOY/L97tuLWX6fsPnhqKyw6E6H69h"
  "+l7UpiPtKFVVGy8yvRD3eaXLk9JV16eA6TlKXNNjoPTUlVizfINjXDIss8Qqebb1tecfk9"
  "2B6lLTFVYsz/MiuVLVuWWTMxaH5n+9rv+fsmB5ltDwdY6YsTyT7P/xO91+wJTl828XUZjc"
  "970/y1Y8PjDdKbuBrx0hzzzo+tx7umi/kNN04jlmmWaSsc90a2L071f9AvETW3A=";

/* 
 * Resource generated for file:
 *    bug.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_bug_width          = 16;
static const unsigned int  image_Silk_bug_height         = 16;
static const unsigned int  image_Silk_bug_pixel_size     = 4;
static const unsigned long image_Silk_bug_length         = 868;
static const unsigned long image_Silk_bug_decoded_length = 1024;

static const unsigned char image_Silk_bug[] = 
  "eNqdkttPkmEcx/sbulaB9wXU16CS0/uCYjjTCwMPuZDyFCoZSop4zLKmomNDO0yznCcQTA"
  "hCUWetpmlrttXqpq2LLrtra9NWk7nmt1c3HRfCRRe/7fnteT7f7+/7PA+AE4hRWStKZC0x"
  "mv115nNFcUZAvoM45zWvVGR0rw7TyAwpwuYhHaHyyWqVs9Jf8fhz+37LTMthnxFURFR++U"
  "/TnVxvYb9yRzkh2Su1qhyxePUivZW5QEcO5g3Q28o5GRivFIxLiu6NZmx8D6HDWQltbXrr"
  "cTybUZPxTA61j97KD5xH8MskXnz1YOitHaJ7KahcKYD//SjODp7CGUcaxHYK6gV6m814lJ"
  "vNuJflZTD36T76XhrRFS5FW7gK6lEaIkcqjB49cgqF36Iy7rIZoXwqc6u99I9LwUJ4Pw7i"
  "7nIFbMEClM9kw+Avgu/DGEbWhiDuTYXKIAhFz814pJu0SwJ6UoLA52F0L5WhOaBDuUsD/a"
  "wOj9ftsM3p8WS1H6JuClSn8Hdqm8ASrUGPSyIGXzGcry1o8mtRNpWNEvcFPFrrhWWmCNUT"
  "eSzvANUuRIqNv5fcRELYQOCQV4yk/6kLGvFgtR3l0zm4OJUP51IHzG4djON5sC9Y0ThtRr"
  "KVj5QG8uQ+Q5q4t47u7aFsIN0pQs9yO0omtXAudsLs0qJqLBd981Ywt+UQ3mA968maWO8v"
  "GTi9TrZwMfFmGD2hBlxjdfrmm3BzthWCegL8Oh7IWm6EMHJaYmmIu6h1cSeFRlcdbO56iK"
  "3UAScw8WpYTsOrTNriliWCczmBjKWRZhO6ki3EX/511s/EBVHNeRfv38cr4ipnk1eRBO6V"
  "RPJ/NTiGhN0kfcL2cXv/AGPJcRM=";

/* 
 * Resource generated for file:
 *    bullet_toggle_minus.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_bullet_toggle_minus_width          = 16;
static const unsigned int  image_Silk_bullet_toggle_minus_height         = 16;
static const unsigned int  image_Silk_bullet_toggle_minus_pixel_size     = 4;
static const unsigned long image_Silk_bullet_toggle_minus_length         = 200;
static const unsigned long image_Silk_bullet_toggle_minus_decoded_length = 1024;

static const unsigned char image_Silk_bullet_toggle_minus[] = 
  "eNrtkjEKxCAQRffIaUTs0giCVWpt01hoKisjiHquvxmLsLuVxZYZeMXAvPmMCOCFh5ve+1"
  "lKQUoJMUYcxwHnHPZ9P2f8nDNaa6i1fmGMwYxPmTQfQrihfdu2Tfne++F/FvVKqSn/unPk"
  "0R6C8slf13XKt9aO+d834JxP+dedXmsNKeXIFEKAMYZlWfzzP//PG69F/8I=";

/* 
 * Resource generated for file:
 *    bullet_toggle_plus.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_bullet_toggle_plus_width          = 16;
static const unsigned int  image_Silk_bullet_toggle_plus_height         = 16;
static const unsigned int  image_Silk_bullet_toggle_plus_pixel_size     = 4;
static const unsigned long image_Silk_bullet_toggle_plus_length         = 200;
static const unsigned long image_Silk_bullet_toggle_plus_decoded_length = 1024;

static const unsigned char image_Silk_bullet_toggle_plus[] = 
  "eNrtkrEKxCAQRO+TLQKClVUQrKxNaaqAwSI2EhEi/tbcRbjjLtUWV2Zhunkz7LIAHrj1UW"
  "ttL6UgpYRt2xBCwLIsmOd5p/A5Z9RacRzHj6ZpAoWPMXb/uq6nH977nmeMIfFv//eceUop"
  "Eu+c6/y1X0pJ4q21ve96A845iX/t6bXWGMexdwohMAwDGGP+/s//6wm83wG3";

/* 
 * Resource generated for file:
 *    camera.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_camera_width          = 16;
static const unsigned int  image_Silk_camera_height         = 16;
static const unsigned int  image_Silk_camera_pixel_size     = 4;
static const unsigned long image_Silk_camera_length         = 848;
static const unsigned long image_Silk_camera_decoded_length = 1024;

static const unsigned char image_Silk_camera[] = 
  "eNrFk9tKm0EUhfsGhT6GhwuJQURRI6LghQiCioacTMwBNSgqIsEqNSp4ICTm4B+TlKYRFB"
  "Sh0lSR4oU1CiJRGvOnVWj7BqVQ6IV+nX+gfQUvFjMMs/Zea80e4BlPjFgs5g8EArnl5eX8"
  "0tLS9dzc3O3U1NTd6Ojod6/X+2NycvJOnAf+3TcajTqBF9o+HA4/F3wuLi44Pz/n7OyM09"
  "NT4qGX/Pn2ll8fDfh9bkKhIMPDwybB+ymAwKOAXpx93dvb4+bmhv39fdLpNKlUimw2i1Y3"
  "mUxycnLCzs4OY2NjuN1uPB4PTqeTrq4udWhoiOPjY7a2tuR6f3+PqqoUCgUuLy9lvfn5ea"
  "LRKAcHByQSCVZXVxF+aGpqkvU07tHREdncF9zKZ0yRAkaBgeg1b959IhKJILJA06lpcrlc"
  "iIxoaGiQOuLxOMViEY/g2jZuGYwXsW8WsYj9QDTP7u4uJpOJ7e1tgsEgZrMZn89HXV0dDo"
  "eD9fV18vk8pqjgJkp4UiXcyRKOuIo5dksmk6G7u1t6EW9ET08PExMT1NbWYrPZWFtbI5fL"
  "Sb5D9NW4ntclnAkVm1KU+jo7O2WWfr+fjo4ORkZGqKmpwWKxsLi4yOHhIfZIHqui4txUJX"
  "dQrC7lipWVFdrb21EUhdnZWdra2mRuer1e+pqZmZG6wpkPosYVFkX4Fhm4Nq54FUrT39+P"
  "wWBAzIr03dzcjN1uR6fTSS9ixmSO09PTUquWcSgUYmFhgd7eXvlO2n0xo4yPj2O1Wunr66"
  "OqqkrT4hU+fgstD62trY8tLS2yV2NjI/X19VRXVz9WVlY+VFRUPJSXl/9HWVmZhvdP/ff+"
  "AguPnVk=";

/* 
 * Resource generated for file:
 *    cancel.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_cancel_width          = 16;
static const unsigned int  image_Silk_cancel_height         = 16;
static const unsigned int  image_Silk_cancel_pixel_size     = 4;
static const unsigned long image_Silk_cancel_length         = 616;
static const unsigned long image_Silk_cancel_decoded_length = 1024;

static const unsigned char image_Silk_cancel[] = 
  "eNqtk1tLG1EURudVFBQtsVSk0qtplYQk0hijhcQyMQmtTS+GWin2Qi//0wcv4N8oZgZJwm"
  "TuZ/WcScdOsLUvPizmZdbe8+29B9C4TjTNkBATjmL8x+3w+AF8fw/fdhFf3yG+tBGf3iL2"
  "XxM8vIOvab0r3R97oFcRhQIilyPMZgmXlwnKRYK9F3j3b2Ord//l7rbh9BTRahFmMoRLSw"
  "SNBuLkBL9Zw9/Zwr07j5WsobKq75V9lUu/D6ZJ0GwS1OtgyNi9HuLoCC/zCO9lhb5yEn6U"
  "NZ8n3N6O3LhGhHJlDW9jA2d2Fvf5U7oJX81WfN75k1V+b+xFSNddX8dJpbBnZnAa5cv+xz"
  "fDrOk0Qa024qvebqmEPT3NYHISp1a85IcfWgSLiwS6fpFXPZVLt4s4O8OWO7HGx3GerXCe"
  "8H3ly934T3KI4+Nhz04Hd20NZ3U1coWsER4cMJi/iV3Nj/iuvCu1V79dx9crhIeHkauyDq"
  "amsNVcpWuvZLE3C/TmbmBq2s/kDcibMNRevVebuOl7F1mtiQmssTGsuVTUt/sXN0behGEt"
  "3MJtlnG2Sjh6McpqVwvYldyVboycq6FmG3P+G3OIyTX/r78AW5y4gw==";

/* 
 * Resource generated for file:
 *    chart_curve.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_chart_curve_width          = 16;
static const unsigned int  image_Silk_chart_curve_height         = 16;
static const unsigned int  image_Silk_chart_curve_pixel_size     = 4;
static const unsigned long image_Silk_chart_curve_length         = 792;
static const unsigned long image_Silk_chart_curve_decoded_length = 1024;

static const unsigned char image_Silk_chart_curve[] = 
  "eNr7//8/w38KsUnZsf/R0++GUKLfvvZYmv+ku8uRxd9HRHUB8YP34ZGXgTgOp/7So/8t2h"
  "8Y23fe++vYc48TJPbRN+DwJ/+gX0B86kNg8F0g/g3Ej4BYCUN/yZH/ag2PmHXqH/w0aHyw"
  "7audY/sXB+d/n53dbGBqPrt5Kn308P74zivgm/fkBw3I+o2LD/9Xcm+QlS572JWesP7XVy"
  "OL79/MLKeiqKl/0GveeP+vZdP93zZt93/addz/B5MzKj70H8Z+rWX576Gh609kvQr5D1ao"
  "FN37rV58b/53I1PVb8Zm/5dFd0yH6y86ANb/W0xq6U9Jmd+2fru+cyU+mMSb9JBZIOn+Ds"
  "HEez9Ek+7WwdT/1NI98F1b7wOMb1C473+1QYD+X17Bf3/4hNoYIh60MIQ/+M8U/uAvc/iD"
  "f2xh98PRw+ynosovuP78vf//M7L6/2diu4OshiHgTrnXIofp3ktszngusTrrttgcbs5vce"
  "kNMLZ+3u7/PxlYQn4zsIjDxLxmWnp5zLR84THL/IHbbIu1rnPN9rnMN/3itMA4HiQPdKsU"
  "TK1e7s7/c0Q1HGB8xw6jaY6dRh8dugwXOfQY8sDEHfoNO+wm6b9H94tu9vb/liU6khal2j"
  "PNS3UfAem3FmU6GejqLOq1OSyadO6ZtWhPRtGfte2/UYamv2GGupt6gKUrkAanQWEND1mY"
  "GiFVJzDbKF9dSiNKJ8O0WAPuLu3MLf+1Mzb/18rYBMQb/2ulbQDi9f81QTh13X8NEE5ZC8"
  "Vr/mskrwbj/1TIuwBs1nGM";

/* 
 * Resource generated for file:
 *    chart_line.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_chart_line_width          = 16;
static const unsigned int  image_Silk_chart_line_height         = 16;
static const unsigned int  image_Silk_chart_line_pixel_size     = 4;
static const unsigned long image_Silk_chart_line_length         = 548;
static const unsigned long image_Silk_chart_line_decoded_length = 1024;

static const unsigned char image_Silk_chart_line[] = 
  "eNr7//8/w386469evgVfXD0efLZ3LiBH/xdn98d/Zk7//8nS7iHJep3c2D7bOt39ZGH7/q"
  "OxJcn2f7Jx7P1obrPrg5EFMyG1rvUXC1xqzz10qjoNtueTtUPgRzObJx8MzUVhan5nZ67/"
  "nZ76+1dy0np0/c41Z5/M2Xjhf8H8vf+jsteefWHh+K03qLbZPHtbm2nGpgfGaesKfqel/v"
  "63ddP/n7Gxf39ERJoh9J6xd6w8+cG+7Ogbt4Ld1c/NHW+vc03dZpa9dbVJxsbfPQsP/DdI"
  "WvXgZ2LC+p8xMb9/hEdc+h4Ucu+br//JFXFNi5zKjz20KztiDzILGE4zP+iZboSZbZSyps"
  "AgaeUjvfilKOEH9Ctbf8rk3Wd8kz59sHV+BQyna8Bw+vNe1+Trew0DfnxhBfSrhGPVqWP2"
  "5ceW2pYc4gSGkwEwnP7+mzbl/zt1/T84w7juQgHQr8+Bfn0D9Gspstx7baP179T0fr9V0l"
  "6PS79T9ZkHk9dc/A/060ty0qJDxfECu9LDD2yK9hf8H4C8RCkGAGqpuEE=";

/* 
 * Resource generated for file:
 *    chart_organisation.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_chart_organisation_width          = 16;
static const unsigned int  image_Silk_chart_organisation_height         = 16;
static const unsigned int  image_Silk_chart_organisation_pixel_size     = 4;
static const unsigned long image_Silk_chart_organisation_length         = 476;
static const unsigned long image_Silk_chart_organisation_decoded_length = 1024;

static const unsigned char image_Silk_chart_organisation[] = 
  "eNrFkrtLQgEYxftTTMNAgpykJYRAauihVCiVj9AhogvS4pJJOhRkNvQAoyUrsLiVN0yuZW"
  "YPougxBVpbbQWFQ/uvDLoEQSQkDWc5nAff4QOqqADmcq9M7hYJbD/hjT9Qrn8yXeT8psjR"
  "1QuuxULZfn/ikdzFM/LxE5ap67L9wso9zmgec/iKptETqNBOPyGVSiFJ0q+6s9ksmUyGdD"
  "pNMplEFEVisRjRaJRIJEIwGMTn8yEIAh6P51umLMu/vtFut//ZHt5DN8KBi8F9BwN7vUqu"
  "c6cLm9SGeb2ZlmWjwuun69BN1KINadCOqRnKOpHuRLZu13DLVkVnTbQyfxkhfBbCuNig8L"
  "pxLT1bndg2LdQEqt87+9gsxBHzq5Q6P3XtcRMTpwFGcsMYZvUKrw2qsW6Y6RY70PhVeGQb"
  "/aluHMlOerfNis601EjjggHDjJ76sE7hS501o6oPbwn/8Vdf8QZ1HNor";

/* 
 * Resource generated for file:
 *    chart_pie.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_chart_pie_width          = 16;
static const unsigned int  image_Silk_chart_pie_height         = 16;
static const unsigned int  image_Silk_chart_pie_pixel_size     = 4;
static const unsigned long image_Silk_chart_pie_length         = 1104;
static const unsigned long image_Silk_chart_pie_decoded_length = 1024;

static const unsigned char image_Silk_chart_pie[] = 
  "eNqtk21QywEcx91553rDCaHzdEdv/u6IC5lC4RQu1kSj/LGKpjKT9LDmFq1sWstqlZTVLH"
  "ShxqTL4XQ9zKa/pxbWKrZq1tPfU3T3tTnuOodXXnzf/T5338/vfj8AE/AzUkrgdsaQlCZo"
  "4jUmPjg0Fle/fyxKG964tyo0dd/lsxMT1G8nYdz8+JxtS/PL0J8w335dizpLPbRdd9Dab4"
  "DaUA6mKkgRV94TE3Ox07xf+drvdzbrSUqI5nkp7lrqUNpxGfGGVPAeC1Bluo7tZZsd4ReK"
  "FkSXdDpKHtjBu/QGTHFbyC9WbEyZcqrlGN3Q1QDxszyQLUcQ2XwE+S9KoLgvx0bF2hhOsV"
  "khrbVB+5RGwd0+BKW30oGJj6a4eKerSNtRg8L2S4ho4SKskQO+Ph0qgwob5H5GUvls6V65"
  "aexm2wgkd+y40jyE+OJ2MLj1IhfPvx9t1HXWgas/iV1OltN0FKoODbiaaDBO+6zek9v+UK"
  "q14pp+CAnqdxDd6ENmdQ+WH6g1uvjDusjRG5ZbiNMnQ0zlotJUhWydGKtEyy+Ey16ynK6f"
  "KpsGwVNbEVXUDU5BN87V2LCYfXXIxUdWs4aaeltw1VSNvHu58Jescqw8tSxNlyCcKuOXz3"
  "C6UvLbNiSqbdiTYwFbakZmlRVeO1S0i2dVbDHK7+W4XPv9slYc1SYwPb9ERCR/DmU5PgZt"
  "JQL4D6ns62/BLe4BM+MNohTd4OZ3YH5w4Y/+wYUBvAAZg/OUT84a5RyUfGGzaTotBR/Cdm"
  "FkzTrCN7aOEmq6cCDXguAkE0QaGzbHN8AzUPZjf9+OH5v8NfawcpQkRz9kiDCoUcFRUYrh"
  "4G0Y9vYhlpE1VFKZGeFiMwTOHbDPPMHswBzawz/L3cV/PRTj7uxLjyjPY+BKBazCZNgL8z"
  "HoH4ABr8UEsbuSile+gqDcip3prVgSqsaMNZnM8ff3aTuTSZMkBgSpsCvz0CeT4L2PL+xz"
  "FhKLQsooUvoC6zk6zFwnMU9nnN70p/sf8fUPHPZeYbazwmDjxqKP8Ebv9DnE3KACyuna7L"
  "E2WziNkeH2t/9xxdnXzT7PS9g/a35zr7snbJM9iH/N/498B1ezm2s=";

/* 
 * Resource generated for file:
 *    clock.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_clock_width          = 16;
static const unsigned int  image_Silk_clock_height         = 16;
static const unsigned int  image_Silk_clock_pixel_size     = 4;
static const unsigned long image_Silk_clock_length         = 1016;
static const unsigned long image_Silk_clock_decoded_length = 1024;

static const unsigned char image_Silk_clock[] = 
  "eNpdk2tIU2EYx0cgQUTfor4EQR8iioLohlIQREVQEPTBMgOhC5YRlmal1gZZapZmJs68ax"
  "NXrdKVZZfN4zy6zOZamqeZC+dtbXOX4zE96v49rzgQD/zg4Xn+v/ec83AOAMX4G8USQklY"
  "iS/EUlB/IdRbNT83E+vDfZ9OEUFkj3fEDMoeAwIdJ13m+sOmpI+ykfDOY2yvP8oFLfGeiZ"
  "40L+XNxBrmu2oVqQFz7NDU6Bu42+J8X7WRYqbJg4IOF0q7RuZg9QOuH13arZLfppLErit/"
  "yeskIpwVivSgNc072hLn42sip/PbBlBnHYaG+4NCXTfyn3Wj4lM/NJZBlDUb8LP+wOyE89"
  "nM6KsNArnrf6sVu3uLlwmtJZulbEM/as0D0Bkc6HMG4AmIcAfGIQwEUN3Uh7IWB+pe58Cq"
  "2TXZU7ziG7lze0gqbbiX8sKGYpMDWroXu8b8fvwaGsE/qhliCCjS96HQaMdNLYfz5XxGeI"
  "cx6k5j8nMbihoF9NB9pekQREnC47JyuOic4OQkXrz/DO6XH3e138GyzAn7x/I4b6LmG7Ke"
  "WuGakDE2OYspGlxXqlCje42UWyo08WbY/DIuF5rBsswJ+0fuNnrPlpihLLdgQJTpjFk4/U"
  "Hczrk/53KW73BPA189Mi7mtYFlmRP2D958bozONUBV3Ylmux/D9MLOoIy3xlb0ewMYnQEc"
  "EvDyhw+X1e1gWeaE/b3JlcpDyle49IRHplaAm3Y1JgPBWYJqH/luqm9UC0hQc2BZ5oT9qI"
  "uF24ju/ekNSKR5lrYXFocPIu1ClGRYqc6o/YmEgs9gGZZlzsLve8eZnHPxmdXSvmsvcSrn"
  "AxIfcUh6aEJibgsS8gyIzX6H43f0OJ1RKbHs4v+D5/m9NpsNnwzcTNSFEmxP0GDnJd0crD"
  "50tRItptZQK8+HKLtnoavX61cSot1uR31Dg3fLiTTVpuhUI+Gdh9VKmgUFQQBlp4l1Yb+q"
  "qmo50UtMERsXP9uC3FrCTwwRq1nvP/Gl5ds=";

/* 
 * Resource generated for file:
 *    cog.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_cog_width          = 16;
static const unsigned int  image_Silk_cog_height         = 16;
static const unsigned int  image_Silk_cog_pixel_size     = 2;
static const unsigned long image_Silk_cog_length         = 528;
static const unsigned long image_Silk_cog_decoded_length = 512;

static const unsigned char image_Silk_cog[] = 
  "eNplUUsvA1EUlvkB3fcn9H/MxkaiNg02VCJIiQ2hqaiaiJB0gQUVIaUVRqJNENJ2qOlUjS"
  "mVEuKxUHJjEl3NduZz2kk8cxf33POd73Fz0ICvo3rzkixJXjT8PSVX0aFyef0NrxD1fS7p"
  "2HH9QCNF85wpzix7xhOSLOEUWdyMRmz0yv+IDzwga2SsW5Sxa4mGCoYDzPhr+HlAth6pf0"
  "8zt/X7GirOMGINBmyFnFDGBQo4wjLWkIWCE2JPCzXsTJMrx9U7aEhhQhnmx/iwckozGmar"
  "U5WQJpvvpFpAERuY5GuMJV6ETFoKZe0zJfOF/BSaT2Cuji/wm8Q/wDH1O8yoFq6sVi9p4g"
  "IryiI/T/on5HWIrqqn0qLVGKKQo0Q55LGFOFUZ7FHVI9jptwMx64ZQFSXKkSedHNL06re6"
  "6/9b96fwjBhChmDJ5Oyz+o0YeY/D7bcVgpEBs4sNOUNMJX4na3V6WJPZGPnewICr1zHKBf"
  "U0kmjTW7l2R5Pr/xZ9Xo/ULLl/7fcTjHhdCA==";

/* 
 * Resource generated for file:
 *    color_swatch.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_color_swatch_width          = 16;
static const unsigned int  image_Silk_color_swatch_height         = 16;
static const unsigned int  image_Silk_color_swatch_pixel_size     = 4;
static const unsigned long image_Silk_color_swatch_length         = 124;
static const unsigned long image_Silk_color_swatch_decoded_length = 1024;

static const unsigned char image_Silk_color_swatch[] = 
  "eNr7//8/w/9BgP/lZ/+HYbDYquL/cAzkf7ia/h+GB6N+SvGF15v+wzCIH3Am9z8Mg/gJG1"
  "7/h+HBqJ9SHFG14T8Mg/g3Z9/9D8NgNeUb/8PxINQ/VDEA+uL+JA==";

/* 
 * Resource generated for file:
 *    color_wheel.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_color_wheel_width          = 16;
static const unsigned int  image_Silk_color_wheel_height         = 16;
static const unsigned int  image_Silk_color_wheel_pixel_size     = 4;
static const unsigned long image_Silk_color_wheel_length         = 1100;
static const unsigned long image_Silk_color_wheel_decoded_length = 1024;

static const unsigned char image_Silk_color_wheel[] = 
  "eNp1k21Mk1cYho9aERw02dTEmGVx/PTHkpmNLCZb+KHbH5NlRKfgYtzwYzqE8ZECtiGm0i"
  "FMyOwGBZk4cLLFBErElSGjZAiSuSrlo1hAPkeRrwkdpbR92147IcuiS5aTK+e8yf28932e"
  "PAcQ/INwxmzYYlcdeLMn2nywd9tQVv92z6WB7e4a55b+5uGYmsGpiH08o38WlWNPbJR9p/"
  "ntR3vQTZ/h5vJFOvxl9CkmhlcLGF/8FNeTHYF5x+ZyT8vGl3jO98ROtWN/9+GJLCq81dRS"
  "JZeWej6nS/IHOgLcQPGUs+I8iL8pxhIsFi+u1Y6ej4gaym44NPkNV/0tpFKEhlxM6LFQSA"
  "8FLJBHWDkLMxqCY5Uodw7g1W8qWasfK0t4a+I7TN7fSZGO5/ieYq5ynUo65HmMGnzybywa"
  "oC8VOnMIdhrxpG71LiWI3ZHTt+pOzd+T6hHS6OQSd6nGSiPNdNPKUwm+BhitgPY8uJ4MrV"
  "X4LiQyGbehSD33YFi/MiVrXTL1OKUSs3Tt4rE8PSYQHoTZTrj/A9wsgC9PQ0kOyheZjMRG"
  "WtULcx5jwM/xUACtpDzk5ye594UDLEpYXgSHHRrNcLkY0lLg9CmUC3oGY6KG1UNu91d/wS"
  "ezoJmBr59Ag+T+NLhcEBoNwr0JqG2H/Go4Ke9wXINXexFH5A5nVNuK4/xImJQe+KwLDJKq"
  "Dmknr21vA7eEBg+UDUCuBY6WQnYFCyf02FW7mkStUnXMGuJbGfHIDUivkTZXoFK2vO0ajE"
  "sUYxh0MtTJ3+D9HwmVWhmJz8Am4nKFPvDOCzqfUtKscEbWHMmVOdKhUAN1OnighT/lN8mr"
  "kCB7qetmIbMRW0TivE28G7s2Ax8uGfdmL2GsDZIm9Yc/kFGTZIaj8MtHMHQIVvdLpdaN2z"
  "BA9xsm2sXHaf/O73vzarFrsj4+YZZ8g49rZbLVWXDlGDRJnDlyfIxB5tJnsO220CoKLz8U"
  "Zzc+9wZecUULVZ8hWtXvToyfID/5KdWZy9xKX8KSNMXtuF5ur7dO3xF1qTZhWv9/73CTsL"
  "/2srib97pos+xdZ3UkiZbeDNFcXyR+zjCLX1/9r/5vdM7gOw==";

/* 
 * Resource generated for file:
 *    compress.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_compress_width          = 16;
static const unsigned int  image_Silk_compress_height         = 16;
static const unsigned int  image_Silk_compress_pixel_size     = 4;
static const unsigned long image_Silk_compress_length         = 968;
static const unsigned long image_Silk_compress_decoded_length = 1024;

static const unsigned char image_Silk_compress[] = 
  "eNp1kmtIk1EcxgM/V/ghRIpFpGgSUZrRBz9kGpSFoJim1tqSmThtm7fl1OncfDedyrygNu"
  "e8NJeuvKF5QZnYh5LIC0udUnmJpEKosFejQJ/+GwVr2Icf5+Wc93ee5xwOgH0gGhtrPAgv"
  "vb46qL29abmtTY/W1gcwGuuIWhgM1WhoqPxF63UajfwA/ngOnjX7RVqNQdYnHbqfZrMRfX"
  "0WjI+PwGodxtjYIEZHn2JkpB9DQ73Q6UqgUuUec3ETiJ2Z52Ho7qqCI7e5ud6Z68jU66to"
  "rEFnZwsGB3tRXslAoZD6uPgTSzPhWFmOgM0WjOnps5h6FYjZ2RBMT17EiOGcvamKx9NWlv"
  "7oH+iCtpyBXJ7h6mN7Kwfs9zgihogiIokImk+GY51hZBxtjY7t7bVAW6lGfr7Yzc/E4mIw"
  "WPYRYSZMWJj3wTZ7x+krlVKOSsuw3T0dYNQK5Oamu/kS6n8e9oWTsM/7k3sc797SPMt1+g"
  "pFNoep0LJdXWao1EpkZ6e4+feo7zXiMnEJ7OYFIoT8BKdPfTlyVSFreWxCkTIPGRkCN19I"
  "uX7U+yHRSrTgtc2T/FinT32PKhjVVmdnG+TKfIhESW7+XeobgLm5I5izeTndN0uHyI92+l"
  "Jp6vHiYiksFvLlEqSn8/7xv35KpH95xC0inrhOROHLxyuwNgUgKyslWKm8j46OFuTliZGa"
  "etPVFzv2+MtEsz/GDKcwrD+NgYZAlBTceCGVCu21tWVwvE06C1JSEn1c368rMpnIs7paY1"
  "Or81FSIkNhYabjvnbq6ytgMhmQkyOEQBD3X5+yPHhV8wXcmtUP/IqXZSIR/4xQyL1Kd7ZL"
  "vXfpe/e2drKUW7u2Rkj22iO0aGVV07OB8EL7N3IYQpecHL8uEMR+TkqKXQ+Tz28y3RsILV"
  "pe28v3TVsUE6sn0mw5dNb95B4k15vPjznM40V7BwinMn3T7O8JyW+uWKA0";

/* 
 * Resource generated for file:
 *    cross.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_cross_width          = 16;
static const unsigned int  image_Silk_cross_height         = 16;
static const unsigned int  image_Silk_cross_pixel_size     = 4;
static const unsigned long image_Silk_cross_length         = 708;
static const unsigned long image_Silk_cross_decoded_length = 1024;

static const unsigned char image_Silk_cross[] = 
  "eNqVU/1PUlEYbm1tZ/0NFeVqLm9Oc32ZAl4VIaZpm/ItCJdETUDgDoYSq36orb+kv0uzMr"
  "6M5F64nMvji1vMEmj+8GxnO+d53vd9nvcAuIJLoL4mXe95L2cMBKEnNxASVO9qvOZwm7py"
  "M7topbPQ48kLGnV/UKgHw2hsbOH3q+Uv1YXF+/9ykX+PFkFPyGhubnc01NU1gWqjGY0DuT"
  "za52OrPV6etlw9e5NKs1ZC1lu7b4FPn6Fnc20+GkFJUH0BgWpD244BdK8Ggjiee8HL4uy1"
  "8/3psQTjb2JclzPAh4/gqTTqoTCoNrStKJDdOztXLDbizrBu/jQjm6whrfNmdIdmeQfs5Y"
  "mXAzJZqD4/KrNWXp6aZn3z8QeZ4lnVkaVZvH7A5QXkNCozc3rJLLL/5au4fe2MAMoBDjew"
  "7AR2kjSzDYXxSaEv1+UVFI8PWjgCJGXipYAYzULeqStOlI1m/Bgd66pRc3oExe2FJq0DlJ"
  "/i8oB84sVJk36ysARENlB7uYTCoyc4HBz6S4P2SaDa0EKvqWYCCvVNPvHihIkVno6zo7HH"
  "vGqxAiEJJzY7joZHcHB7oKNB+yTWHC5oQQnKigvkEy8+N3a8+j48yr4NPeC/zCIU+zx+jj"
  "zE/k2DeL4H2iexOr+IkmlKJ58u+Hx4b5B9HbjLu3H/oGQ0i4VnEz0zOjDcYfs3bom45J/t"
  "h1NpfKTH";

/* 
 * Resource generated for file:
 *    cut.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_cut_width          = 16;
static const unsigned int  image_Silk_cut_height         = 16;
static const unsigned int  image_Silk_cut_pixel_size     = 4;
static const unsigned long image_Silk_cut_length         = 716;
static const unsigned long image_Silk_cut_decoded_length = 1024;

static const unsigned char image_Silk_cut[] = 
  "eNr7//8/w38cWDVrppZd9fJ5komTWP/jUYcL21Uvy2xfd/qJSOwETmRx8YRJTMTod65bmT"
  "d3z9UfQPv5YWJK6TN0fVrXbSVGv3vj6pJ1J+79l02ZKgfiSyRMVp+87eKT9Om7txGj36dl"
  "bfWBK8/+y6VOUxGK6ZedufPynek7Lj8UjZsoQYz+gPb1Lefuvf2vkDY9uX/zudOHrz3/o5"
  "A2zZrY8Avp2tR5+dHH/32bz3+78/Lrf/OyRTnE6OO1jQOHb2T/tu67QH1bzj76nzhl5wJC"
  "+oRc0qSMMueudqrbeEknY96S9Ol7zl548OF//MRtRwWDG1nw6nVOkwDqu52w6s7/kHkXPq"
  "dufvV/5q4b/x++/vE/vHPdHl7LcEd8+o2y5qyJW3rtr5RvgZ2Ed55/wton/2fvvfN/6dn3"
  "/9O3v/8fu+zGf1nPtBRc+r269n1yrFsBjlejvGnT0zY8/1+y6NS/9I1P/+vGTTno27vjsn"
  "XB+i/cBp4c2PS7NG19HrXk2gvHpnVH07a9+W+Wt/yGec6a14FTj3wGyauHlZU5VGz/L2QR"
  "JI1Nv1xweVjg9ONvopbd+GeWs+w0l2mghGnGiofhCy7+4tRylDPL6ptjX7rlD6+xrwAuP4"
  "i4pkuIeWQpwPj6cfOPJW96/t9/0v6nSavv/jdKWnSDlPzHY+jFbpi44Lp92bbvJqlLHvAY"
  "eYugqwEAtA2e1w==";

/* 
 * Resource generated for file:
 *    date.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_date_width          = 16;
static const unsigned int  image_Silk_date_height         = 16;
static const unsigned int  image_Silk_date_pixel_size     = 4;
static const unsigned long image_Silk_date_length         = 684;
static const unsigned long image_Silk_date_decoded_length = 1024;

static const unsigned char image_Silk_date[] = 
  "eNqVk0tLolEYx7WkC1FRRi2KWgSSiza2rOUs5oO5cueAMCAUfYHXRRkijoIXXm/VMFBJ+s"
  "7rBR0HTRnE++Xf85zxleZi0YE/5/Kc33M5FwA6kKjpzWbzB7vdHjeZTB9pbuC1sQwWi+XE"
  "6XTKvIfXMOZYGZ0OMinhdqNUKiF2cSHmmbF4fOPxCNv11dXEpsXl8bf5edyHwygUCrij/u"
  "vsLJ5mZoRu9XrcRyLCxntux7yWH48fl5YgnZ8jm81COjvDzcYGcuvryK2sILm4COn09LeN"
  "+of/8JXVVXw5OMDnnR349vag7O5C3d7G981NPJAf9/IyPi0s4HJuDiXK52++YTTi5/Exyk"
  "dH+HF4iAL5yu3vQyU/CvnJbG0hTTll1tbwZDD8wcdiMQwGg6nq9/tot9tC3HiNmWl8s9lE"
  "IpFArVZDPB6HLMvw0PlzG41Gb/LMulwuEbfb7aJcLiMYDIp5r9dDp9NBNBr9h2e75kOSpM"
  "len8+HYrGIVquFRqOBer0+ldek8Rzb6/WKu1NVFYqiIJ1Oi5re4jl3v98vWOZ4z3A4FHOu"
  "UXu/zBMzfMmzOHfOt1KpiJjM5vN5cY7JZHLCc31U0y/28fIcOT7XXK1WkUqlRFxufI+cv8"
  "Y7HA4EAgGEQqFXFaa3H6F/wHfBjMZbrdYw/Vu8RzabjZPRPQMoeMhA";

/* 
 * Resource generated for file:
 *    delete.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_delete_width          = 16;
static const unsigned int  image_Silk_delete_height         = 16;
static const unsigned int  image_Silk_delete_pixel_size     = 4;
static const unsigned long image_Silk_delete_length         = 792;
static const unsigned long image_Silk_delete_decoded_length = 1024;

static const unsigned char image_Silk_delete[] = 
  "eNqt091PUnEYB/D+Frho5eZab2uu2WqrmagghwgERD1keoRGa6bJOMw028rRkOZFU0vtVS"
  "tvMo0ZK7Vsqb0yLY+VSpyCFYHn8JruG9JwudQrf9v37vd5fr89ex4Am7CBmTMYhLNUhfkT"
  "VcZM60huSlfMfSQ1zASpMrtKFML1rFtvIL5QFPvTbkV0yInY+zHERofBP+jCnLEUbwsJ9p"
  "VGQqxlZ8opfv5eFxanPyDuuI94pw3x1ov4facFCyMOeE1GjKly+JeKrBU1ZvV6QcJ6uFud"
  "WGRciF85j4DNgqC1BtHLFsSaaEQbTyP68DbcJ0iMHD3oeSbfL0j5hKV9dWYsuMaT70XsNP"
  "wXKhGu168Id4ZEtOc63ogzMSjLpFP+M3WcCfXcQLy7FYHGKvzQylbNfBUJ3loLr6UaT4gM"
  "JuWZcl049qgHcbsFgXNGrHW8ylz4qUIEW5vhFO8Op/wUqQ1HutsRbTAifLZsXe8rVSPY0o"
  "wByfZlP1miZvyNtYjYaHCnNMl7q0YlRqDOhDlTJRyi9OX/u4oUNCMXIdzdgYBODn+p9D/L"
  "KnLAFkgR6ryKYclO9GdvXe7fO61M8LqY8LgrihG6257slU8t+euUeWDlCSuXgO9ow0SRbM"
  "l6ekVbBP/OwHhBLjGqPMzPHFMjdLMdvxpoeEkVvmmU8NebwV9rw6QmH33ZaXzCrjqDLxSH"
  "iOdHDrBj0r34XlMJf9OlZL5Wn8TT3B1Lll3LpjIk2ycclGSYncQe5nH+Lm5AtI3rz0tn+n"
  "LSzL1Zm4XY4H39A64kzrk=";

/* 
 * Resource generated for file:
 *    disk.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_disk_width          = 16;
static const unsigned int  image_Silk_disk_height         = 16;
static const unsigned int  image_Silk_disk_pixel_size     = 4;
static const unsigned long image_Silk_disk_length         = 868;
static const unsigned long image_Silk_disk_decoded_length = 1024;

static const unsigned char image_Silk_disk[] = 
  "eNqNkmlPU0EUhv1LQG9FTfwVfjYsLbQUDCAim0YTP6gRJBqNUAQFAgVEUSxgW9CgCIWKLQ"
  "ZTlq4IXaA79F66vZ6ZGuInwocnk3tznnnPzBy5xlQn15g6CQsRJlJyjTFHQF6V50K1CZeu"
  "zeJijRHFGmPkcq1xRVBPXQFwjuq1NncSNrcIKZ2DSCSPs4geZRCMphCKp/m3mMpiP5aGKy"
  "DlZq0H6asPzAeCWl9Ovt3mSuLOaADJFLlUp3i0hHAijSDVx5MZvm+MVu/BMbZ8EgzWMGgP"
  "UB8S+VEr+bd1fl7DYH4glkL4MM1zWb6fenH4JWztiWgZ8ODregSCejrHzmtxHJHv4zWMin"
  "YzArQmpCwk6ilymKG+WbaIjV0RTf1ujMz7IKimwO7KvH2IW8M+eKg/xk7omLIzPDshZrEb"
  "Sp249t0kbr5yYnDuD2SVH5mPxQ3yh/Z430rKruwwo/rJCmoIdecylPRf8R8NPZvoM3ggq5"
  "jk77Ngj6N1cIfORdDaOuhF6wDDg+Z+D+W50NjnREOvA/U9W2h4uY1uvQMy5Xvuz6/H8y6R"
  "97x8D+Y2vXbzfm/0Orl3XbtJbODZxCaKFO+4P7cWJdf7D89JNncpt7HPwd168uq67Kjt+o"
  "2OsXUUlY+Tb4DRGkFLv5e/81moef4LD4fXUFg2xuYRM6sR3qtIb3X/S9mpsFmoevoT9wZW"
  "UVg6iuJqI6YsYcrP+/Pbn0+F+arOH7jbayFfh/MaQ25yOUS++8z5yvZltGnNKCgZzglVBu"
  "f4932MLwTPfP627iU0v1hkfoju77Gg/qQX1DNhQTVNM6nncyWr+IAi5QS90VsUlr+huxql"
  "fkfI0fHcgpKhWEGp7ttfGIYU7Q==";

/* 
 * Resource generated for file:
 *    door_in.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_door_in_width          = 16;
static const unsigned int  image_Silk_door_in_height         = 16;
static const unsigned int  image_Silk_door_in_pixel_size     = 4;
static const unsigned long image_Silk_door_in_length         = 976;
static const unsigned long image_Silk_door_in_decoded_length = 1024;

static const unsigned char image_Silk_door_in[] = 
  "eNqV09tLk2EcwPH+gKKgCLqIrrqLopBCbJ5qLt1qrUbNNWtlGUZlc1umbXPmQqesOVNzR6"
  "fOTlJmWtmJMkMrrTwMIzsXHRjUP1Dw7X1faNBdXXx5Lh4+/J7n4X2BWfxn8dAh92TgwM/n"
  "Z4p+/I+bjhx5JVhmek9y06dn9LQx8WfP6XTicDiw2WxUVFRQVlaG1WqltLSUeMTEdKSE11"
  "dr+DbVzZfxCww06Bg+lZ/0drsdv98vFQgEpILBoNRUuISvExeFuvkw0srbBz5ueLcx6N6S"
  "9OJM0eb7tuAP+CUXCoWkxgMH+fzsHO8Gvby+6xaq57pnK3dcyqQXzyvOlNfJUNflSi4cDk"
  "uNtRTxabRDsjM3q4VcXKvXcN2xLrGxaT1KXzYbPBnI3TL2xQrYHdWjrJYTiUSkHjca+TgS"
  "YWagmhf9dl70Oeh3q+ktT0vkNWTRNtlEYNxHy1MPjaNuPI9c6Fo15NiEvbY2Hp7S836oVX"
  "A2pnssfH+4k75aJd3mlEROfTr+Z15qhu1UDR3Ddt8sZKHqQTnqhly2V2q559by5l4T8UtW"
  "PgwUQlzJQH02Zw8vS2TXpCVn1g47qR46TuVgGRu9CjIsabS3t3PLpeLVbQ8T5w8zcbaId/"
  "276D2poL14aSL9xBrSHCmsKV9JinU5m325qLw5yMypku3o6KDfIefljVqed+5nLLKbsbZC"
  "eoX3Ce1dknx/o9FINBol66iMVNNqyYl1dnZypVwm3P2E4PbwOKDnSXAnPVXraDUuSnqDwS"
  "DNyzSvFdao5MRisRgXLauJ99gFu4ORZi2PWnRcdmbRZJif9Dqd7q+ZohPr6uqiq2QFk93H"
  "mBKaOGfmabSYy5WZ+PLnJsRvzmQyodVq0Wg0qNVqVCoVeXl5KBQK5HI54f1LOW9ZRY9Nxj"
  "WXglt1m7jkSMe7fXbiX/67YOHihcJdU5sLFuxp1M+rbdDNiTUa5v8S/PffJwOoIA==";

/* 
 * Resource generated for file:
 *    door_out.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_door_out_width          = 16;
static const unsigned int  image_Silk_door_out_height         = 16;
static const unsigned int  image_Silk_door_out_pixel_size     = 4;
static const unsigned long image_Silk_door_out_length         = 968;
static const unsigned long image_Silk_door_out_decoded_length = 1024;

static const unsigned char image_Silk_door_out[] = 
  "eNqV02tLk2EYwPE+QFFgBL2IiLJCOiPZSe3AGqm1rGHTpq2siVHa1LW0ba22yrU8zNTmTj"
  "ndtJIyy8oOZnay0g7qMLJz0QGhvkDBv2cP9EDv6sX/1c2P677gvoFR/Gdh7277gHvnz2cn"
  "tT/+xw3597wSLMNth7nmzKD3hGbkz5nFYsFsNmM0GikpKcFgMKDX6ykoKCDs1zHkz+f1xa"
  "N8G2zhy/MzdFSqeFCeLnmTyURdXZ2Y2+0W83g8YoO+fL72nxVq4UOPi7d3nFytSKPbvkHy"
  "kZmuOhfpzg2S9Xq9Ys/du/j8tJl33RW87rQLObhStpGbtmTJR+6rrFyL7Fi8ZH0+n1hfrZ"
  "ZPvQ2iHb5mFbJx2ZHKFfMqySvscnKbNewIZpJwKI6l5ljiiucTq5/DoyoNH3v8DHdYedFu"
  "4sUlM+12BW3FS0UvP544kNO0hdonZVT12il7aKP0gQXr3f3M2xPDvfIM3t91Cc7IUGsR3+"
  "9lcak0mZbC2JHVjoSANpRFdZ+DI/dNGG8XYujMQ3cjF2OXnlm7ZtBlV/Kmq5rwOT0fOrIh"
  "nEyHYyVNebPE+YnWReFMX5o080C3geJbBehv5jMzZxrXbSm8ulFG/+k8+pu0vGvfQtthOY"
  "HcaGn/hL2LUdasZb1zDbPzZhKzczoztFOJzp5Cu1nGy6ulPGvMoc+/lb5T2bRZZXi3T5a8"
  "RqMh0bCEFXvjCQQCNDQ0iDU2NnKhOF7Y/ZDgtvHIncFjTxatB1fh0kyUvFqtpr6+nuWFyy"
  "QXKRgMcrZoIeFWk2A301Oj5GGtivOWFVSroySvUqn+mhlxkUKhEKH8uQy07GNQqL+5kCf1"
  "uZw/sBxn+tiRyHvV6XQolUpSU1NRKBSkpKSQlJSEXC5HJpPhy4nmdNECWo3xXLbJuX5sHe"
  "fMCVRsGj3yL//Okz1pgrDr4prM8duqMsaVVqrGBKvUUb8E//03ao2lZw==";

/* 
 * Resource generated for file:
 *    email.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_email_width          = 16;
static const unsigned int  image_Silk_email_height         = 16;
static const unsigned int  image_Silk_email_pixel_size     = 4;
static const unsigned long image_Silk_email_length         = 764;
static const unsigned long image_Silk_email_decoded_length = 1024;

static const unsigned char image_Silk_email[] = 
  "eNrFk8lPU0Ecx/1/PHHzwIFgXFBJakyMCSExarzKwUAMagxgqyw1HizGqDFKolJjKrjESK"
  "ltaWmhxMYKBbpRXqHt6+tGl7fOfJ33qomcPXD4JDOZfL6/+c0C4BAOkJtPAq6RqdVK32RY"
  "vfIgRC5ZQ+SidZn0ji+RnrEguTAaIOfvLZJzZj8xjfhI99CC1j3sFk/emOEOn7W6HtqjcU"
  "khtNrQIGvYh/IPqg4BNEatqYIvS+TogD02+CxC99jc9pFDPCej1KDYzBPEeYKkQJAuEmTK"
  "FNkqRVMBtngZd6e3sZGpwjQeoH22MGQW/GGlCtsnDsm8jKpI93l8jUJkLifIGH2/jUdzFQ"
  "h1Sfdx1Roy/MgOwUyolaHXaMgwvGKdsnVgpyhjwsHhubuCL1ENxVrL7zEHDT+aI/i1S2D3"
  "F3F/Om7U0j29992SDMubOJ66ivge0wz++qZbPsNfZz2H0zJmlwp47RPw+DOHRFZEMidiko"
  "2nvALe+nh4NiX4U3/8iQCO93sgMf8nJ+PrD4FlSFjLEjhX63jhyuMlwxmpG3sLJkU4WP5C"
  "TIKwp9cPov3aPG2wy5oLC1jLyEgJFKkCRZIRY8QZCZ6N2X2ssx5XtiTMLvPgCjWYxhZpW+"
  "+rZKkmkYzQoJWGys5eRY1Rl1TouTpNhqijtBCqIglt8GJnvz2hv6G2y47ykb5vSvvAvNox"
  "6FY7b3vUY3c86okhr9pl9qqnGKctLc5YvErXsLPecf1dWndxwP/nf/kNlpo/Jw==";

/* 
 * Resource generated for file:
 *    exclamation.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_exclamation_width          = 16;
static const unsigned int  image_Silk_exclamation_height         = 16;
static const unsigned int  image_Silk_exclamation_pixel_size     = 4;
static const unsigned long image_Silk_exclamation_length         = 808;
static const unsigned long image_Silk_exclamation_decoded_length = 1024;

static const unsigned char image_Silk_exclamation[] = 
  "eNqt0/1LE3EcB/D+li1MeyAkgvAHzSli9mDszIf02JNzs5ZTJJPy5p4kVyRqiEnEtsyhEB"
  "RYQaUmEhIRRllEXUZqt7UHH+ad82bBu7uDuwrEn/zA56fjdZ+H7/cLYBd2MH93nFNveuup"
  "tNtCbzjN7LrDxLJtBjp5WUetXCLV21nBEWm3NbzsaQAX6gX/KCAlG+pBlLIi3lwVjjaVE1"
  "vZtMdK8K46Ltnvxa/xEfCD15DynZeSv+vD5tgwEr3t+GHTcgv1pf/9g3dZVKl2M7Pa75Hs"
  "utskpRyswwC2TY/00xBiN67gW20JQxuLVbIXZnQkXLa/1mUE5zQqXpgdq606rLSQ4B8PYa"
  "6RxCeywCF74TstzsgHOyUn15NDdMvNNUg0ViN5043ELR/eV+bSsl9qqU7xT4LgvBbJyfXk"
  "EF284SxitipE7Tokh29jhshJyT7aVJHaGA1gzWlW+hTrbX6elbzoftZXImKpQMRGIjk0gN"
  "elhxXPXNDSq/4ucANepU+xXvJON9gHIcmFzeVgjGcQ91GI9HRguiRb6X/eesrxvVmPjdF7"
  "Sp9iPTlEt2gow4KOwNqIH+8MpzFVdEDZ31fTMdUXfRET7mzF+sNBpd5Sr084807JzZNayc"
  "5RdkwW7mMmNFmqf+/AxxoNMVuVxy16L4K7H0TiunBXLDVYrKtG7Col7EywbXa8KMjixvP3"
  "bHkH35blEG+0R8IfarWIdAu7CPRhyd8HpsuDGfIExvMzw8/zMojt3sCrk4fU08ezqZfFB+"
  "mpov3sZOFedkKTSY8dzaCe5e5WY4ff6x/cH9Qa";

/* 
 * Resource generated for file:
 *    eye.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_eye_width          = 16;
static const unsigned int  image_Silk_eye_height         = 16;
static const unsigned int  image_Silk_eye_pixel_size     = 4;
static const unsigned long image_Silk_eye_length         = 860;
static const unsigned long image_Silk_eye_decoded_length = 1024;

static const unsigned char image_Silk_eye[] = 
  "eNrNk01PE1EUhjUxcSfGj4Uh/gD/A3uDO1fGxAQXhpCIidQYooBale4EiYBIqTBIG6CgDC"
  "2lH9AW6AdtVWhrq4VCO53OTKczzBRTwaamr50mbog/gMXJSe59ntyTe84BcALHJCiKasim"
  "fiwwcd8Bs7kE9qsVbMgMNkCCC5p/czG/h2GYhv+5NE0T7NaXUi5qhxRzgt+wIOHUI2YdRd"
  "Ixiv31aUhrH5BfGa/wyej8EdfGRt0Qow5s2giYxnphJLQwTJpA6M3QEvMw6LRw69QQ7f2Q"
  "rH0QI66I4qbT6R427oUYXoTL+BbeYBxTHhkTbhk6h4QByx56SAHdRh6kX0bCPoHszAsUSA"
  "3oqH8sm4zmmNAs4sFllMtlzAf2Me6SobVLOHvxMuou1OPldB6d+lw18zWGi3jAGDoQHm4v"
  "p4JkJZdJ4vDwsHZn9BQwZBXRZxZRd74eZ85dwuMJDg90DLqqWWEUVkxG8Lm3Bdn0zh9Jkl"
  "AsFlEqleAMF6r18tAYOTwxMGgfy+K+lkbLIIX3DqHGKKzi7JD9FTqyKvHp7ygUCrXzZPYn"
  "hhc5dBCZ6psUWodSuPNmF53jGWxsyzVGYblYCCniUYnajr3Lrc8iX/3/PTYNWZYR3uJB2C"
  "i0j2yhbSiBgbkUAt9yNU/iWfCBBWQGm+HTqn1KDxIbfh+9NALRrYMQdkpCMsoKXDYtCMLu"
  "v8jn87t8LMBypj5QVdfeo2LnVNdO/puB0Iqd9E71l3emu8GbX4F3aMG59WBdenDLBGjyNe"
  "jhVqxpblcsg8+Dn9oaTx2dQe+A6rRJ03xj5mnT5NyzJt6ibvplU986WOy6Wfz48Pqq/l6j"
  "ynD36hUco537C7pbGnI=";

/* 
 * Resource generated for file:
 *    film.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_film_width          = 16;
static const unsigned int  image_Silk_film_height         = 16;
static const unsigned int  image_Silk_film_pixel_size     = 4;
static const unsigned long image_Silk_film_length         = 772;
static const unsigned long image_Silk_film_decoded_length = 1024;

static const unsigned char image_Silk_film[] = 
  "eNqt009okmEcwPEYCBMU9KAHPbiDCm7iH1AH/iH/4JyobApTSBlakzRedVvBIoomdO0QMi"
  "iiEbZj7DiWFYPcVqBr74abzto0V5csOlQvm4f31+/S5bX31uG5PO/7ed/n+b7PCwAX4D+M"
  "ubm5Wi6X+5nJZI7Z7gmFQoeBQODc6/XWmdfQnhEE8TidTkMkEvnnQAvj4+P3XS7XAdOjBb"
  "Tfk8lkjyh9oW68+kZl17tUaq1L7VQWqa/1Rcrj8fScTmfVZrMB06dSqT209xKJRM20cRfS"
  "W8cw+wbg6gbA88oqnLdT4HA4Dq1WKzE6Okoy/czMTCsej5djsRjp3pwAdckH8dcNuFwCSL"
  "4AuPPyA1gsln2TyVTW6/UtpkfbRFvEfe7GKhNwqx6Ba3tOmH47C5Pra3BxtQJoSbRFtVrd"
  "ZPpoNFpDm8fGO8udeVg5vQ1PT2/CUvsKLH26BIXOFOh0OnJkZCSvVCprTB8OhzvBYJDEDq"
  "z9h4eHKYVCQQ4NDXWYHm3N7/fnsXE1u30GC+8A5rcAiE2A3cZD6H5+BHK5/D3avFQq7Xu/"
  "z+drjo2NFbHxLlt/mUxGSiSSolgs7tu/2+1u2e32MjZm7Y92XyQSlYVCYV9/tCRaAhsfsP"
  "VHW0dL8Pn8vu9vNpvBaDRuY+PfT1pZ+ll7gV5uX6cLx9N04WSKfnAySQsEgl88Hm+Fy+X2"
  "nT+DwdDTarUJfAZrf1w/DA4OTnA4nB9Mr9FoGiqVqoeNq2z/H9ojtDAwMPDx79wf7ZpgDQ"
  "==";

/* 
 * Resource generated for file:
 *    help.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_help_width          = 16;
static const unsigned int  image_Silk_help_height         = 16;
static const unsigned int  image_Silk_help_pixel_size     = 4;
static const unsigned long image_Silk_help_length         = 892;
static const unsigned long image_Silk_help_decoded_length = 1024;

static const unsigned char image_Silk_help[] = 
  "eNqtk11PkgEUx/ss8BFaq7latVp3tTUuuujCqfkKNLVcLYPlLB3mNEtKzUyngpo6p6LAk4"
  "AIoonyJgg8mMgDKC8D4YFHzbZ/xILV5rzq4nd3fmfnf3YOgHP4j+jIY7bWfSTQOA9J1RZD"
  "f7WnaIWNJuctCcGs6YB9lqt2MpwFRzroCR1je5+BO0Bn8eyl4fCnMb4SCY4uhzinucRmii"
  "O3JlM74UOYv8cgXaQgmnSiaXwLvcQ2DI4IXEEan1VUqpfY/aeHzJxgzWzEA9shBsvOKBoy"
  "Tg/hARVl4IumMbniR73UCuVGEHZfAh0zZKBtysXK+ROrEeEmlcK6Jw7hiB1P+s1IH51k+P"
  "mHEzSMWFA/ZMKSPQztZhiNUqsw5w8uBklXJmcfsYO6fhNq+9ZBRdKYXfNDbdsDk/HVtgC4"
  "XTp0zDpg9cbwtM9I5vxuhZdxB5IQSiyo+WQEr8eQqdVjzuhDjD7CfozBwIILFZ1a1HzUw+"
  "E7AE+sZ3J++5SLcfmTeDZsAbdbj6oPOlS+1yHJ/MBumAZfrEVpuwoPMvDFGtipOIpa1Xn/"
  "pdRG2nbjEMtc4HUZUCleQvm7RZS9UWcpeU2gpEWB4hY5mqRrMHrCuNcoz8+fySJUGP3QO8"
  "Ko6TbkvWjiEOEDBoWi+SwlIhmIDR8kmSy366fz++OLl1lVb5cCq84wlOsUuJ0aFLcq0Tll"
  "yvLbLWqexpjGDY3Fj1t1k4EbjyZYf99AoWiBc7+ZSOnse1BbA3glWUV5mxylLXN4MaCH0u"
  "iFykzhWvWX1JWHo6fe4F2hjHPn+UxwkNjCN3cIFm80y4pzH70yGwp40uClKgnnrB+4+XiC"
  "fb12XHC1eoy8zB+hC7hS+mLlMHmhYkhwvmyQjf/8r78AhdMFog==";

/* 
 * Resource generated for file:
 *    hourglass.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_hourglass_width          = 16;
static const unsigned int  image_Silk_hourglass_height         = 16;
static const unsigned int  image_Silk_hourglass_pixel_size     = 4;
static const unsigned long image_Silk_hourglass_length         = 832;
static const unsigned long image_Silk_hourglass_decoded_length = 1024;

static const unsigned char image_Silk_hourglass[] = 
  "eNqNk7tPU2EYxh0ZHF1cTIxbY+JKHPQ/0MHBRQYl0RgTYqODSLwnAgmRBiiXgoJWKANiSY"
  "H2SILYC63QK4WCwmlpKy29aaGn957z+Hr0kGIIYfjlfMP55Xvzvc8D4NjqoLyGaCB0BEtw"
  "BO/puw2b4hpmX17idU0XudG759g3N0/rlHUnGtqvHq8Bufjrmzf1zYjMKxF3vUbS+xYJzx"
  "C2F/qxZexG6FM72IlmLKsbYVZcx/iDCyDfLPk+9UOP5Mcc/cQAotY+/PiixKbhFVhtK1Y1"
  "z+DqvwdjW53oK+pOeiTfshSUOSxz2NCrsDLyCAvKesw2XwbNDJoZg7fOoLf+FFR3zkLz4g"
  "pUXS3oGtbLJP8Ps+slgyNcRDJTRr4koFAWkMpWsBLJwx7MIZAsgk0UMelMoGs6YKh2JRhf"
  "7iPjywqb9C9X4BFJl7EaLcBPnuX7LnqYkNA5FRg/yJXQunZqJ1xp9iubQehnSXSn3Sl0M8"
  "H1jil/7WFuNSPzcZMzyMEeyEBpCBqP6kmMzses7jAHB/kdk37Tke+1xM5rF+PBpVAGKa6C"
  "6E4ZU/YYWsbWNp5rlg+dX23a1o7ZYoI/nhd3UKwI2M3zCKVK0LsTePzOIzQOug58vyFjlJ"
  "nxprCVLiFb5FEit8IL4OjsCufg3crDQ18Vw0Leu7Bvf5oZr2zYFMGc7xfiu2XRJVX007kK"
  "vm0XRNcZyuGDLYKmISfkrRpZdf6XmV6YrRZY15IIJ3LYydLuohmMfA7g6Xs37qsWIe+xoa"
  "1TjYEnN/blv7o/R83/f/5ef6mzLHWW+9dZMf/UWZ46y5HDEjpir7+/AYaCBa4=";

/* 
 * Resource generated for file:
 *    information.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_information_width          = 16;
static const unsigned int  image_Silk_information_height         = 16;
static const unsigned int  image_Silk_information_pixel_size     = 4;
static const unsigned long image_Silk_information_length         = 884;
static const unsigned long image_Silk_information_decoded_length = 1024;

static const unsigned char image_Silk_information[] = 
  "eNqtk91PklEcx/tb4E/oebppbXrRXFsN8km7yKxhmqitdBVmg1W+JOIboIANwVDzhfINSl"
  "KEBB7JCHkJTX1yYAZtbXUDWcvy25GGs8155dk+d+dzft/fOb8D4AgOkVzdMv+MJiI9rQpz"
  "J5v9yWyFL5mlmOeyFF7piYcs/yBXoF1iTilDibKeIHqcMYywG2mM9ihE2tegpTMJWmZn9n"
  "NJTSanJZBqnliBzZ9A91QM9eb3eDC0BKVlBWbXOhpGIqDLx1P09fH/zjitDvNyWhfiO67l"
  "TQJS4tzpD2HQ8xGD7nXcNgUh6QvBNLOG+qdB0CXmOF08xMv4OcoFWaneD6vvM2r6I5CQ/D"
  "cNAXz/uZWm0uBDZbcPksd+9L+K4kLTS1AFfbKMn93q44z2GNQWDrd6Aqgy+FGp96HXuQYT"
  "obyL/YfOQ3oKQTu1DDrfwGX84/Xs5tj8J9T0Bkmdt6h45CV7WeysbYJY40ZpxyzBhWs6N8"
  "xsFBTTuZnxaZlzc9S7ke5zp06Z1kMcDyKxb0j92EJJuxPFbQ5cIYhVDgzPEV+o2uPbOb2d"
  "g/zZIip0Xog73biqnsW76Ffi/0KRYhpFpGdRkw3V3SzUtjDos+27+elqm6xQ6cSgK4YKDQ"
  "ux0gWbbx2//2yn8wc/fEFhvZVgQdfzCPLvjhC/bff+6BujPFpsjt8fDsBkX0WJ0gFR8xQu"
  "ySdRWGfBxdpxFNSOoWXYT951jmSXx2mhnLd3BijRAHM0z5iSDvhgnF6GRO8meV/gcoMVVR"
  "oHtJYQJL0saEFdirj7ziCVb2SovK7E+XsTUE8u4ombI6yi3RpGbo0ZlKAhQQsbmYP+AH1O"
  "y6eYDimVq+IoYVOSEjQmST2OID0mrOPjkP/rX+9Ly+w=";

/* 
 * Resource generated for file:
 *    key.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_key_width          = 16;
static const unsigned int  image_Silk_key_height         = 16;
static const unsigned int  image_Silk_key_pixel_size     = 4;
static const unsigned long image_Silk_key_length         = 652;
static const unsigned long image_Silk_key_decoded_length = 1024;

static const unsigned char image_Silk_key[] = 
  "eNqVk8tPGlEUxpv+NRBc1PE5vpJCjXVR03/AZRdduXOj1YKhIhMNJkpM+tJ0ZSTGmBiNmB"
  "obbQArjYYOxEcRhRrBzgDDzIAgX++MVRMFwUm+zeT8vu+ce88F8Aj36HjumZ0I/2VHifpC"
  "bC79W9VDPK5Z0YtM7BOyya/kd171CM7oP5TLpk+GkTmbusqG8gWnaLjG6dV7eLVfhZXDfU"
  "ifjhGtXHo49MjnOBxMUEU9lDqlX4VVFTGqHtnECoRdBuJBOy7Sa9i1PUHRfPkXyR+68VB9"
  "TEiybYh768lss2B7tSjAPlbmj653kfq3SGw3Q9zrhBR8DcH/EvxWNbK8GWy/FsvvqgN37n"
  "m+FdGNbpxzDpJFE/YFyX6FpLcJvJtSWb9RB6elxne753wuQWZ0Qgr3IL6jgeirg3Q4gOPp"
  "FuSESdLzNPwmHVaZmp+F9isTnYEQ6CA5OghsM+SQFR4rxS0NVO2zb7QImCuwNlK7eTc3Tv"
  "qdQypgAOfSIOV/CvloCJsM9XfeUv+lxK4kz3knOSca3IYG0n4HYc3wMBS3wNDvy9hTZFPf"
  "kWAN5KyeQwyZ4LJUxheH6Yly9jzk0G/JsXVIoX7Ifz7DbaX4ZVvDaLlvzPOxpWfbXhv5Ya"
  "uKKfN+G28cfMgb/Qcp2f9E";

/* 
 * Resource generated for file:
 *    link.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_link_width          = 16;
static const unsigned int  image_Silk_link_height         = 16;
static const unsigned int  image_Silk_link_pixel_size     = 2;
static const unsigned long image_Silk_link_length         = 304;
static const unsigned long image_Silk_link_decoded_length = 512;

static const unsigned char image_Silk_link[] = 
  "eNr7z/B/wKEdd1Zp67t5/2se5pjnSNTcnfe/9V1WqR03RNaIzadr4v8X/+/+P/i/8V71oZ"
  "s/7v4/8n/if58uIzaQvKFf8Yer7yK2ef9J/T/pf+X/1P/efyK2rXhY/MHQD6y/q+n75HR/"
  "LvvPe/+f+3/o/9r/9p/9uSanN3036gLJ62amv59WErTT8Zfb/0AgdPvv+Cto57SS9Pe6mS"
  "B5TU3f673vV71d93/6/8L/FUBy3f9Vb3vf+17X1ATJqzHbG3jdT/mS/T37Z3hcuHP2p+zv"
  "KV+87tsbqDH/ZxjsEABGRQ+k";

/* 
 * Resource generated for file:
 *    lock.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_lock_width          = 16;
static const unsigned int  image_Silk_lock_height         = 16;
static const unsigned int  image_Silk_lock_pixel_size     = 4;
static const unsigned long image_Silk_lock_length         = 988;
static const unsigned long image_Silk_lock_decoded_length = 1024;

static const unsigned char image_Silk_lock[] = 
  "eNp1kltIk2EYxwuSDkgQEUQXeVEXWV1Y0OGiLioQojMdKAuqi24kOlCKgq5mA9M8TKbOLT"
  "QPM2bi6Gg2p8NtLbOVK1MrD2ua1Ug3zQ77dPrrdRcfMujiz/PB8/7e//95nw+YwyxVV1dH"
  "V1VVKcvLy82lpaUuvV7v0mq15sLCQqVarY4m4vxsGQyGuMrKyn6LxUJbWxsulytcbTYbdX"
  "V15OTk9GdlZcX9h42uqKjocTgcNDc3I74pLi5Go9Eg/DGZTGGpVKoepVK5MJIX55PMZjNW"
  "q5WSkpI+kTemoKAgKi8vLyo7OzsmMzNzyGg0UlZWRnp6elIkL2Y1zXjP+ArP2Mh+RkZGrM"
  "hOTU0Nqamppsi+TqezO51OhC/5+fkLIvsKhWKB8KW2tpbk5GT77J7XfhZj+U1EXkReep8l"
  "4Gk4Sv+TQ/Q92Edv3W66jfGkpKTMsOQqzvFBtwGZt50hNP6SqfFXTP95D3+64dcHCH4W8s"
  "DvT4TGXjMxYmPiR1NYXZp1Mv/ZekrwrUieJKa+ZsG3IhjSg/8ejBhhUIfUeZVx1wnGWg8w"
  "4WukM3e1zHsaj4v7XyD1XmSk8RiBprPijtsM3N2E17AHBtT4xAyDhq2MOnYjfW/g/c2VMt"
  "//9DChUSfBj4lMDaTBdzX4dHjubOThrSOCz0ZyJzL2/CCjLfFI3+rpuLFc5vse7mcyYCfY"
  "dY7h+r3CPwF+FNGnjaM2Yx94VfhqduAV9wWadyINPeadYqnMz7zvpL+Fvx2nCfWcF7NfE3"
  "Pnw0+tqBrwpBF0nRRsPH7zNqTBR7xNXSzzPcZdTA5b+d1+guH7OwiY9xOwJRBwniHgOEVA"
  "ZPpavQWvfi3+hq0EBx/gTloo85+qtoudWAgJTfutYndOsbc3MNEhqlvkeEHIZ0b68ojgwP"
  "2w2i9HyfzH0s3h/6G7cD1d6jV05qwKv2+HagXvri/jbdqScF538iLar8yn/dI83lyYG+b/"
  "Aa/W8wc=";

/* 
 * Resource generated for file:
 *    magnifier.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_magnifier_width          = 16;
static const unsigned int  image_Silk_magnifier_height         = 16;
static const unsigned int  image_Silk_magnifier_pixel_size     = 4;
static const unsigned long image_Silk_magnifier_length         = 672;
static const unsigned long image_Silk_magnifier_decoded_length = 1024;

static const unsigned char image_Silk_magnifier[] = 
  "eNqt001o02AYB3Cp0LOCB9GDsMsEL8Ob4EXw5tmLIoLoPIggghMZsotOHIq4qsG5bFKd1I"
  "12KtZN28zUubW1H6uWtXZdEptUW5euTNI0Hxj+vun0toiTHZ7De/j9n/eB5wGwCRtQEf6n"
  "6+2iSYUKhjSZa1ovsw1rfO6HNJaoU09mZdffLEvsVNFkU6IBvmZCrBsQlw0sfNfBzK9gmK"
  "2wA2HJMYMpmlRS1CHVTeQqGtJiE4lSExmpCW7JQHCuBs8rgXLyr/OaxMtGyyaJ+/BFRYxX"
  "McOpqzmiihvPipKTt2ctkf/aNi6oiBL7frGBd8UG2IUGydXRO5q3nHwgvWIJNQMxYmdJz2"
  "liI8RNFRQweQXZbzp6RrKO3herSfnff//Tk/msIESs/Y7zCrqHUxUn752uUhOZZRSqemvu"
  "ls2t2k9lDXRIQP8dWgtfOdS+ln/AlF33JktsIF5FqqQi+1XDR1IxTsHgGwG3fVHMB3oRvH"
  "xAHr+4b82MWy84V1+gQF19mpPsWbsfZqyuwVS5z+Plk94LqCbGkH7cBd+5DvnRmd3t/7qX"
  "Ez0H3c8v7ffPUCdRjtCI3u8EfWqXvJ7dHj2/1z1ydo8/fPMwuOB1UMe3Y733MdTZ5h44sd"
  "NPn26D5+jWa/9zY3ePbdvcf2TLDmzQzdr1C2jGCng=";

/* 
 * Resource generated for file:
 *    paintbrush.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_paintbrush_width          = 16;
static const unsigned int  image_Silk_paintbrush_height         = 16;
static const unsigned int  image_Silk_paintbrush_pixel_size     = 4;
static const unsigned long image_Silk_paintbrush_length         = 572;
static const unsigned long image_Silk_paintbrush_decoded_length = 1024;

static const unsigned char image_Silk_paintbrush[] = 
  "eNr7//8/w3864yMzBaWOzJI9vHeCSAM5em8fLH357sHK/zu7xN6TqFcWqPf1p+d7/z8/m/"
  "R/a4v4HxL0yt8+WPL2M1Dvh9uFYL3rqqU8SNL7Yt//Hy/q/l9cY/cfqLeISL2qQL3vYHov"
  "rXMA6Z1PpF6NWweKP3x+CdF7dbMLSO+xJXlyrLj0bFo7n3nTmjkch2dJa4P0fnm5H6z31m"
  "5vkN6HQL2COPQxblo7l3fTmlklm9bMuH5ghtznN7cmgfU+OhYG0vsNqFcVm97eJSuYVqya"
  "JwbUu3XTmnk/Nq2Z/W/L0pp/O7ul/t/d5///4HSj/0C9zrjc3L1kmWTzwuXrJs5b+f/8pb"
  "P//3y6/P/T0wP/N8/Puwe1NxWX3t7FS9ha5y/Jbpi65P+0XVf+ty7Y+T+1a8v/yklr/he1"
  "TNq6IF9dGl8Y109furZh9vr/bSuP/e9cf+1/5dyT/6N7rv73LVz2Prl8ghqhOMppnfMvqW"
  "b6/8iSyf8Dcyb8907r+R+QO2tbbNHEIGLT5qbF5SybFhVZbVqY17BpfqbEpnmpfJvmJfES"
  "oxcAxoPGvQ==";

/* 
 * Resource generated for file:
 *    paintcan.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_paintcan_width          = 16;
static const unsigned int  image_Silk_paintcan_height         = 16;
static const unsigned int  image_Silk_paintcan_pixel_size     = 4;
static const unsigned long image_Silk_paintcan_length         = 788;
static const unsigned long image_Silk_paintcan_decoded_length = 1024;

static const unsigned char image_Silk_paintcan[] = 
  "eNqVk91Lk1Ecx7vaXXlR/0MQSjdCkEHghQh5GXZVgkE0974ka2LqKqZFbuHabCUibEP3om"
  "7Ss5fcC1vPs8WivTiZc5sMtjHmXtjuCsRvz/OAXoykdvHjHDjn8/t9z/f8fgAuoC2G5qnJ"
  "wVeB3/1Tno2+cYKDv9w5L2iWQ7PHM+YEhmY96OVt9nfC02zXwIwXk4YoBp470D26dqcTnt"
  "bcdXvCAaEmhFvCTTx5u/GpE97lDyluCLYwovCh9+E6Ppv8sFqtkv9hw+GwPLmXQp/Aiu77"
  "Bly9t4q9TBFrdjdMLurXKkF9X9wMzr0xBS63s6FQSJ5KpVCr1TCl9cBHxfBU5USxWES9Xs"
  "eSYQsWKg3jtwxeGgM74mVvzyOt5yLDUhR1xh4cHMCwHca09ivWiR8olUooFArw+XyQv18+"
  "mTcFThYcKYx+2BkfVrovkSQ5zbCtVgvZbBbpdJpdq9UqyzF75tzlcsHhcEAqV568sPzE4y"
  "VPZXDOeYXO+3p3dxeVSgWHh4fI5XKsDoZnciWTScTjcRAEAZVKBalUSnE/esE3xnFzlphg"
  "9NvtdmUkEkGz2USj0cDR0RH29/eRSCQQi8Xg9/uhVqshkUgooVDIebC4A1r78fXJLz2n/u"
  "n1+nfBYBDlchmZTIatGY1GWV6n0zF1SYFAwPby3QU3+uSEs/0PNBqN0u12I5/Pg3kT46XZ"
  "bGbqknw+/2wOrj3bHjmvBxQKhdJms7G+WywWiMViksfjdTRDMplMubKyApFIRI6NjXXEng"
  "bt0zCXy/0n+wfiSeJQ";

/* 
 * Resource generated for file:
 *    paste_plain.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_paste_plain_width          = 16;
static const unsigned int  image_Silk_paste_plain_height         = 16;
static const unsigned int  image_Silk_paste_plain_pixel_size     = 4;
static const unsigned long image_Silk_paste_plain_length         = 796;
static const unsigned long image_Silk_paste_plain_decoded_length = 1024;

static const unsigned char image_Silk_paste_plain[] = 
  "eNp9k91rklEcx6O/pIuuuuiim67bxNyjzaVooiHscYautRbDgohewFKehTE222LtRdRWWw"
  "yab0TEoIsiYtnai9t0L9XwBea7oAnt23mOTVx76uIDB873c36/w+8cAEdAGDYcO0GAADn8"
  "yQhB9k8RZvmsx3Iae9kgitG7FH7t6j65f46XoBTwt6O+a3s7c7exNdqKX5kAcksWCr/eHJ"
  "Fi29+NLd+VnyRbFPCxM3cHm7NmrI8wiA2JEHvcTGhCzNmEqPMMVsbOk/0u2oeg//YWNmaM"
  "iE2zWH+ux9rkxQNExhVYdbP/9H+8uYnoVDvWvFpEJpQ0/zf/87+/vk7rrHo01F8eU+JFXz"
  "tc9g64bB2YeGDAuM2MeyYGnZ2dnMlk4oxGI8eyrIH3v4V6EXFfqLmjbQg/UeDloAWVSgWF"
  "QuEQ+XwepVKpqtfrrby/HeihPa48bcPScCvmnXJM9ffSXCgUQjAYrBMIBCiZTKaq1WqpT2"
  "aDZeIuEndhUIpP/TJMOnqon0qlKMlksk4ikUA6na6q1Wrqb766jMWhc/g6IMWXRxJ8fMjA"
  "23eV+o01/X5/Hd5XKpXUj82YsTDAUPdznxgf7Gfhtnchl8sdqNkI78vl8po/bULYUXPnbc"
  "14bxXBdd9E/caa+/h8PurLZDLefxfx8u/GiLVnHWSGLBbGWXgcFmSz2UN14/E4ZXd3t9rS"
  "0sL7DCHc+OechuOw92pQLpdpD0IUi8WqWCy2Cv1JMtejOp3uhkaj4VQqFadQKDhyV470yz"
  "EMw0kkEo64nEgkuvQbMJfMIQ==";

/* 
 * Resource generated for file:
 *    pill.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_pill_width          = 16;
static const unsigned int  image_Silk_pill_height         = 16;
static const unsigned int  image_Silk_pill_pixel_size     = 4;
static const unsigned long image_Silk_pill_length         = 804;
static const unsigned long image_Silk_pill_decoded_length = 1024;

static const unsigned char image_Silk_pill[] = 
  "eNq1k0tIG1EUhitFjI+CJRXcqHXRKuLCQBTdiLgRKwgRxEdQxE1AXGSRhVSkC20RETcWSs"
  "BuikpVpMWVVmXENmbRlthCJQ/zdiaTGZNJkxBDgv17ZqBFpBI3XRy43Hu/85//nHsB3MF/"
  "DJ/f/ygQCDz1er2vXS6Xjuf5u7dl7Q7HVIjnIUmSEizLwm63czabTZ2L/XJ8/JwNhZDJZJ"
  "BOp5FIJJBKpRCNRkG8ZLFaVTexjMXywhsMKmwymVS0RVFEOBxW8rjcbnw6OjL9k2WYGSed"
  "y6x8V9aTWfKt1C+HeH4O5vAwcp11LS9Pc3t7yND9eDyOSCSisCHycXZ2Bp/PBzfllve39/"
  "dxlQ1NTk4n1teRPTjAxdwcYgwDQRDAcRyC5IX6j9PTUyUfzQSbW1uOv7oDAwZpaQlZynkx"
  "O4vE+Dh+jo5CWFkBzQ4ejwc0O/iJk3uwvbODN6urFTJrqawscI+NIUt7qZkZxGkdGxlBtK"
  "8PYnc3gvPzcDqdSu0CsV93d7FpNvf/0d6urn7sNRqR2dhA3GBAbHgYkd5eiF1d4NvbwbW0"
  "gCU/AvXv29oarBMT/Vd9vy0vf3hCWmmzGZJej0hPD4TOTvBtbeCamiAQH6PwkidmaKj/es"
  "8XS0ry3tfWfheNxl9JkwlCRwdCra1gtVoIxEuNjfA0N+NzXZ3upveyWFr64EirDYh6fSY5"
  "OAiB+DjpRzUa/Kivx4eqKl2u97pQXHx/uazs3UlDg8RqNJfumprLjxUV2VW1+slt/8uz/P"
  "y8BZVK+6qoyPSysFC3UFBwLxfzG3hK7B8=";

/* 
 * Resource generated for file:
 *    plugin.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_plugin_width          = 16;
static const unsigned int  image_Silk_plugin_height         = 16;
static const unsigned int  image_Silk_plugin_pixel_size     = 4;
static const unsigned long image_Silk_plugin_length         = 720;
static const unsigned long image_Silk_plugin_decoded_length = 1024;

static const unsigned char image_Silk_plugin[] = 
  "eNqt011P0lEcB/BeQy+mTQtTmmWPTJwkECAPfwyVCChARMeDpCIogjwtdEEu18q1NikRUE"
  "inARLqdOAb6KpmF26tC/12/De58b81Ny/OzsXvfM5357sdAJdwwcteNu1aS88xUNAfmzee"
  "LpzPGi/bSybM7UcRr4ZhWFP/OG++Ja87jFdDCO14oMuqlv933rHVB9s3AwaLz9Cf18K0rj"
  "mOVUKY3vPjSZr61b0o+9mVkBzIPwoPmLyV2Df7LzFbjSBeCSNWCWJmL4Dorh/h7QkEttyY"
  "Krsgnn8IJj9Q1OM1sSeZw8U+GFdV0H+hoM0pyN4FbVZJ/BgEb9sYPekYxjU1nHkLnanLUd"
  "BkZehdlkCVEUGZEsBbHoE6oQQ3dg8PpltwJ9J85i5NRonIjhfqlU50Z8R4nBZCkeJDusSD"
  "ZoXC2KYDowU7RgpW3Aw2nfE9STmC2x6o0v8y5Usd6Ey2Q/SZi56MjDgbnF8HMUQW29dQ86"
  "RjkI5hzurgJ+9UpDroTMliG4SfWsFPcDBMMmXvH6F5qvEPe5KF6+P1NX9iA8T5SMe6nArj"
  "pRdwbw7BVXTQmcqUiM4klrE/akGMSdKPNMmDp+REb4Kie+LM3IZ8XgTHhgW29X40ea8xeu"
  "kHQS1ztOCg7ensVpBNrBmWVQNYnjpGL3rHA3+Oi/ZZDlpf3cX9aMvv09kNX8NR48TVI5a7"
  "7rDedeX7Rf/VvzOyxnc=";

/* 
 * Resource generated for file:
 *    star.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_star_width          = 16;
static const unsigned int  image_Silk_star_height         = 16;
static const unsigned int  image_Silk_star_pixel_size     = 4;
static const unsigned long image_Silk_star_length         = 796;
static const unsigned long image_Silk_star_decoded_length = 1024;

static const unsigned char image_Silk_star[] = 
  "eNqdk0lsUlEUht3YuOhCjdFFJUILNB21syDUqbZg2oQYFRu1atx360IXdaWLJrozcaOWKj"
  "YxaEfaWjrRgUIBxYIW6AgUeI/Hk1fA6MLfazHGmFKHxck9yT1fzv+fcy+AbUgTlKW6jJqR"
  "n8EWNVtFeEbmCU8fYf+LNcnUjE0BxqpAcPxwy7/yoSlplHOdx7qrEYGRyi9+Q3nGX7OT0h"
  "bGpkR8/vIGT02ehG+gVLtZLW09mknmdI141RKvLsImUuxFcO/q8NEiRcx+DqGRaqz0FCeX"
  "O4s8S7oC3eKLvOaFjlweZZbPsc4GcN4LSCw2kbiKpPcK1ucUYGeKEJ3IAzNRQXIVyetBD5"
  "9CUC/H6qsyeJ6J6B9eF6KOeiRXriPuOg7OXkr6FoOdygczJgY9lA1KfwDhHj4iw3Xwd1XC"
  "81TIuttydn/ng0ZJxtpYlY+xnUbC04SY9RBYUyGixlxSLwTVzyfsfkRGlYStgqddGHe3Ze"
  "/7dQ6B4YpM/1B5mHM2gntTm9I9KgL9OhvhPh7hBaANtXC353yafyzgbTZLX3/JLWqqBpxD"
  "DWac9DbkpHR3Z4EaqMRatxQfHvF16fa22ntQEzEpEZtVgjGWEA0nyFkLqq8QoU4xgj0yOB"
  "9k2dPxy11F01FzA2K2s8S/CqHBYwj0SjZ004M1CHVXw3FvbzAdv/SyYIW1qBDQS+DVij67"
  "24Wa+SeC++8f8hILmnwEdBLY7+5KpuPJm4h7O3LjZK+tv9+9bd3TbL+zMzJ7O/NrOt77XH"
  "zpT2/bfHOH2nRj+8+/8A2U69US";

/* 
 * Resource generated for file:
 *    stop.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_stop_width          = 16;
static const unsigned int  image_Silk_stop_height         = 16;
static const unsigned int  image_Silk_stop_pixel_size     = 4;
static const unsigned long image_Silk_stop_length         = 808;
static const unsigned long image_Silk_stop_decoded_length = 1024;

static const unsigned char image_Silk_stop[] = 
  "eNqt09tLE2AYx/Gu/EMKIUqkIxGFaYXOzVOogRYq2RDDQzaLCU0bTkuXps7DzJxLmVFqYQ"
  "Qd7EDmRTcWW/NsKrWpmx3GiKJt9u21ObGyrrx4Lt6Lz/v8HngeYAPrWM7WZtlCh8HywWR0"
  "LbS3OhaMLQ6nQe9yNNVZZrXlifZLpUH/svP6eqmr96bN96Yfhp+D+Qm87oNXD/G9vM/HNj"
  "3viovOrGkbddGfejqnfdYB6O+AO1roqoAbGjAWw+1avC/u4dRdnpgpyJX+ZpvqpJ+7TTaf"
  "WfR8ZoRb5cKVQbsaWs+DXgk1+XC9DO+jbua1pbbp7MyVP5xXG6y+wcfQdw1Mar8zCNcsnK"
  "4QqoWtyIYLGeKtxNtjYCZHbg14h77OzeADkVPl7/fLKYTL87tSORQLq0yB0/Ein56ZU5nu"
  "gJ+r1ToZ6BU5z63h0qEoFRTJkCdslkTMUcPUiVRnwM9Wljl42gVVuX+7QuHyEyBbBpmRcP"
  "wAtFQyeSzREfB2jcpNXyeUpP/Rb9mdFC4tAlL2Qfx2Md9FJpJjV/K/VxYM+e62wxWFf76l"
  "nKtd6n5I3gOyEJE/Do9Ow6gkfCjgp+Rpsjl1kd3b0wbqLGHC/ZWy7BJ2shi5mUW5lK+NFU"
  "ylJdmtu0Jkq3dg/GhcrO1szrTH1ChmFvkTdois2/gRHYLnYDDfMyR8qS/nbcqRSXNocOxa"
  "OzgiiYix5WTaPE1i7xo0+GpK8FSr+Falwq1VLVnMWzYq/nc/wxF7Y8Zkhy3j8VGuMdkhx4"
  "gk3DEaFeYaCtttsYQGJ1m2bgpaz3v9CRbS3U0=";

/* 
 * Resource generated for file:
 *    telephone.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_telephone_width          = 16;
static const unsigned int  image_Silk_telephone_height         = 16;
static const unsigned int  image_Silk_telephone_pixel_size     = 4;
static const unsigned long image_Silk_telephone_length         = 1016;
static const unsigned long image_Silk_telephone_decoded_length = 1024;

static const unsigned char image_Silk_telephone[] = 
  "eNqlk91PkwcUh91/4N3uFi9MvPDOS5NJTDSZm0EZqOCoBPwoKEpFULAiBUrHR2nFEr5r24"
  "2PAKUWWmktlL61lIKyQlMBESXiFIL6IpEYTQx9rCRdFr30JL/k5CTPOTk5vwNs4TuUoLRv"
  "Pd8ohOR/jYpyU0CUG/1igWFEzG/2iBd0LjFLc0c8qbKIqcWdYvJlo3jkQoN46LRWjDt8Pb"
  "xtR+qPsmbvv13+Be4/WdvU2PzbTfnnVvHNiggzb3CHX+EKreAILmGfeMnt8ecUNTn5+YBs"
  "tbp3guHJRdrcjzC6pjlfc4d24SkyrQPj4DStA2HOVdmos4VJvtJBfsMQuXUuGq0Bfk+vRG"
  "2ZYCj4jC5hjpt9YU5WDtDifs6J8n5OlFn5Q2EhpdiKxvaEhAIzGWUWSgwe6ix+EjOqUPw9"
  "SqnBjVI/RHm0PhxaovfBG7rHX9EZWKHdv4Lp3jJ64SU9I/NklnSQnq9DkqPhlyQFBwo6Uy"
  "/WdLxQtvYtN9v/iXhn36Izj1JYZ+PSDSs56l6yK3uQqnowBxZR94xtZCmapg5nlge37/w1"
  "NXaHszW2DtPgQ8afrvNoZYOvo9EWwuh+THWXj+S8evv/b5hUav2pSO/54Jxaxvd4nRdr3/"
  "Jm3wIFtwK03p1BouhejbFxuZ0//CYz3m8fnsEZeo1v/j3vPka+4X3Tr5FqBzF6F5G3ONm1"
  "+4o81uNSk3djILiMwbuEMLfOp6/GRyIRggtrpKn6qbEvoDTPEHfwz6kYf07nQe+a5appgg"
  "bXM4pMY+Q13UNWL5BV6+aU2olE2cexa91Io3lu7QB74wsfxnipJuoHxzR5+jFyGkfIrveR"
  "eVPgjNZDRvUgaRV3kagcpJTaSSnp57LOwf6k4o8xPq3CjtYySW3fJJqoH9XmB1R1jaNq91"
  "PeNkKJyUvxLYHr+uHo7kNc1Nq+zP+P35NcMXsk18Dxq92bHj2a30aSzERidgsJmc0kSBuI"
  "z9ARn17LwTQt+xLL2LlLouY7f/eLPgOpG+jD";

/* 
 * Resource generated for file:
 *    text_allcaps.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_text_allcaps_width          = 16;
static const unsigned int  image_Silk_text_allcaps_height         = 16;
static const unsigned int  image_Silk_text_allcaps_pixel_size     = 2;
static const unsigned long image_Silk_text_allcaps_length         = 228;
static const unsigned long image_Silk_text_allcaps_decoded_length = 512;

static const unsigned char image_Silk_text_allcaps[] = 
  "eNr7z/B/gGH5ASCcUH6geEHuhrRv8Q/CJ/gdcN1gs8DogWYAWP5CuUG5Q8H/3Ib/DPGvw6"
  "f8Z3A9YHPgP4Nmg0IDWB6oqtgh638akBee5qfwn8HmgNEBkIxEAMyOXIeU//ENMJ7RAc0D"
  "qG5Ic4j7Hw6X1zyggCYf7xD23w8ur3BAAk0+3MH/vytcXuKCIJq83wKgmzcYOYBlCwQPcB"
  "1gKfjPMBggACJv+gM=";

/* 
 * Resource generated for file:
 *    text_bold.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_text_bold_width          = 16;
static const unsigned int  image_Silk_text_bold_height         = 16;
static const unsigned int  image_Silk_text_bold_pixel_size     = 2;
static const unsigned long image_Silk_text_bold_length         = 252;
static const unsigned long image_Silk_text_bold_decoded_length = 512;

static const unsigned char image_Silk_text_bold[] = 
  "eNr7z/CfDrA8ofx8yf+C99n1qesT3kfODxZAV1Fcn/k/az+IFTE/5L/XeXT53PrU/8lgef"
  "96v/+O/9Hl0+vj/0cD5X0F3O67/beYjy6fUB/5P/i+T73reZf/ZvsxXRhRH/zfCyxuMt/i"
  "v9p5eTQX+tf7/ncEy2sLqP3X/S9egCrvVg+0FWquzH/N/wL1qPK29Q7/9cG+ki5Q+c//nk"
  "sBWdYmwWS97n61/fL9kv3C+3n7ORX+M9AHAgDJrfx6";

/* 
 * Resource generated for file:
 *    text_italic.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_text_italic_width          = 16;
static const unsigned int  image_Silk_text_italic_height         = 16;
static const unsigned int  image_Silk_text_italic_pixel_size     = 2;
static const unsigned long image_Silk_text_italic_length         = 140;
static const unsigned long image_Silk_text_italic_decoded_length = 512;

static const unsigned char image_Silk_text_italic[] = 
  "eNr7z/CfjjC7IfVDwv/ID8EHcKmIexD5PzABl2yMQfh//w+4zQ+ZEPTfbQFueZ8Hnv9tA3"
  "DJehm4/rfBY7rjBJf/RnhMt3hg8V8Lp+lmDqb/Nf7jkjVp0D2gdkD+gOSG/3SNEQCFu/87";

/* 
 * Resource generated for file:
 *    text_underline.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_text_underline_width          = 16;
static const unsigned int  image_Silk_text_underline_height         = 16;
static const unsigned int  image_Silk_text_underline_pixel_size     = 2;
static const unsigned long image_Silk_text_underline_length         = 208;
static const unsigned long image_Silk_text_underline_decoded_length = 512;

static const unsigned char image_Silk_text_underline[] = 
  "eNr7z/CfCrA8ofx9+f/SfggvcX30/5ACNBX7S/7D2JECwefRTSjen/cfwfPajy6fuz8DSd"
  "4RQz59fyKSvAWGfML+SCR5fQz5iP2BSPJqGPL+/d7/HQMgbBUHuX50eTcF+/cW5w0V/jMo"
  "O8icF1PADCMzBf35GvsV90v3ixiQHsLa/1X+y/0X/y/0n+c/+3/m//8ZqAMBS279bg==";

/* 
 * Resource generated for file:
 *    thumb_down.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_thumb_down_width          = 16;
static const unsigned int  image_Silk_thumb_down_height         = 16;
static const unsigned int  image_Silk_thumb_down_pixel_size     = 4;
static const unsigned long image_Silk_thumb_down_length         = 648;
static const unsigned long image_Silk_thumb_down_decoded_length = 1024;

static const unsigned char image_Silk_thumb_down[] = 
  "eNqNk89r02Acxjd/9KB48g/wIHoQDwr+KXrYWRS8WC+C4BCm6MmDlwnKJqNicQGxKB2kB1"
  "c740xoWcmKISMjpZRJ6kpTUlvrYR/fd2+3poKQw3NI8nye7/N+eQNMMalpoaNCKbbrZ0bP"
  "U4lUiaapdi/jBJ/xm3vUG+BugeMOqDnfhB5h1y5hecf3FWet/hGq7atsCX+nA4Mh9AfQ60"
  "PYhVYbwe6JLKg4IeuuP8Gv98+LvqDrYJoQBIqPeoKPVEYnVJJZ7wq/JvhitUBlQ/mlR/rl"
  "7G6MbUuJbruC194z7h6msDaHlNbAMMDzRE6k1DlgJTdiW7uQ1cb8Wv0amzXVNxRez1ds+A"
  "8reweCDVrwOjvmS/YXch+gVFL73vmh2HhfOVOyTfHNFf0Wlsa87QXKL7y+2GG5rPzxvnKm"
  "zM7n4cmyzeySech/9T/hOmrnMucgK95Xni+Tg+tamrR2gfu5c4d83j1LpvyAN4ZJzvyJXu"
  "7RHPVtNOHjKmLekPTiDLeM/91H+f6YuEOnKLhzuN/FWXegWIR7yy+5kT+R6A6vNK5gWH/2"
  "2aoNj99ukC5cTMTq/kl09xWOo3b8dCHirjaT+P/R7dPolo+3Dc9e/OZ2Zi4xK5V1U8ybd3"
  "j4HG4uzidh/gLhXUyC";

/* 
 * Resource generated for file:
 *    thumb_up.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_thumb_up_width          = 16;
static const unsigned int  image_Silk_thumb_up_height         = 16;
static const unsigned int  image_Silk_thumb_up_pixel_size     = 4;
static const unsigned long image_Silk_thumb_up_length         = 680;
static const unsigned long image_Silk_thumb_up_decoded_length = 1024;

static const unsigned char image_Silk_thumb_up[] = 
  "eNqVk0FrE2EQho3aHBRP/gAPogfxoOBPsWDPAfHUigfBS1GDYGlLoaKggkJ782JoIEihVq"
  "sxJiRsWEOXhA0bsssuG3dpSipVD32czbdNDaWlPQx8y3zPzDvvfAucYDe0bhItvIthge4+"
  "5//cUUJ3z1NrW3Q3wTB/o9mPjsVrwVl0/w2eR7+GbvYoOWPHqlEMb7De+Eu4AZ0AiqbGqn"
  "f1CGxC4jSt7XOURbdjKw3tNuStV6y4Zw7W7V+k4k3ywy2ybv9Et7YIhN3oqqiLn3njD5+M"
  "Md67iX18xf6IG/WTu70t2OwpLoxC5ghC0SF5zYBMfYKscYVM7dKe76bf1xrdtVpQLqvZg5"
  "iNzn5H1ahWIVfRyZaKA361+pXMEqytidYGOK6q1RHWj1nPB9dTObMJbxcZ8CvmKJWq0h1x"
  "UT7SH/GesK6wTsy2HaVj/sUevxwk+VIUf6R/Pg+NRjx3EPeUsGO2JawlO5meZ8jDXGmZfI"
  "HB3vvzh4q3456ttvKnKft4OjvMv3MvUxBLch+gUFBMxEe9d9mmsA2ZrSZ7eDDza4hfcE6y"
  "UL1JNise1hUbeRfVqZvwTWpPze2QnoJUusuttLXvHbysJ5ipXGd66TOvF3d4Jr/g5EO4d3"
  "+bOxPfuT2eJjV+jdHHI6RmRw55x6ckkjyZuxB/H/ju/wFMvEl5";

/* 
 * Resource generated for file:
 *    tick.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_tick_width          = 16;
static const unsigned int  image_Silk_tick_height         = 16;
static const unsigned int  image_Silk_tick_pixel_size     = 4;
static const unsigned long image_Silk_tick_length         = 560;
static const unsigned long image_Silk_tick_decoded_length = 1024;

static const unsigned char image_Silk_tick[] = 
  "eNrVk0lLQlEYhtt1u/+lWTMbaILCbMA0Lbt1LZu0pE2ZV03TMqlouC2jeSRoopGKoGXXUq"
  "nfEP2JzLejYNMi0kXQ4tsczsP3nuf7DoAk/KPSrNXwdYuVzkRY9Wo1bzrWw3DAQsaXcPGw"
  "9StVfO9RG2Ye3PDcWqHb0qBoNNf2G1a1LOeNhzpMBV2YDDrRut2AYo8UeQ4RFbtjvGLLus"
  "6Zju+scknOR/JOBJwYDziifQvdkpB0KPuDvWQLOs+YZ+7GBHa3vi92Tjzx3fstGPcPweu3"
  "g91Uo8CVE8q1Z72zhouW8s7TpqcxgcNUYBjaLUWIeOpTLMgmu/YYjN3b4bnj0LyhQv6wOC"
  "SxZVKf83WcaFP0h40wX/dg9nEUHsEK45EOphM9RgQL3HcWMOtK5DlFrznWr2ysmB0lTfrC"
  "dKqPvtF7b4PLZ4ZLMEO7VhfxFBZzGdRPjoknWjEvQ/tuE9y+QThu+9G4ogDxFBZb0qnfzE"
  "k2V0pXTBeTvCpolmtBPIVFg2lUPHtC5koXjkhAPL1km9OSE9lT4onOGkhN/ov/9AZ3Rqk8";

/* 
 * Resource generated for file:
 *    time.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_time_width          = 16;
static const unsigned int  image_Silk_time_height         = 16;
static const unsigned int  image_Silk_time_pixel_size     = 4;
static const unsigned long image_Silk_time_length         = 908;
static const unsigned long image_Silk_time_decoded_length = 1024;

static const unsigned char image_Silk_time[] = 
  "eNqtk91PknEUx/uT6qJaW1fddGW5tKVuudnabKUXKgqClFiYmSWYKEGKCqbg+3QiFr4gki"
  "iKgG8g8AiYbyA+gIA+pt8e2mheOK8823f77nf2OWe/s3MAXMMVaryz+p6h67V2fpC1vzjC"
  "oeaH2JReWbCjaSro7//KvnMZq1NVNlhHWcc++wz2tl0IhYIgyQA2N6yw6jsx8i33UFmbx7"
  "2InejkC52mRgT9Htg9QXSPEWjoWUadaglytRMLjh0QdgOGpS8g4z8vPs9q5FV3TYMMKrBL"
  "QGfeQu84AacvhEAoAn/oEHZvCPJRJ/om3Vgzq6F4mxGVVr68keR/tjKH1+n31Y19qLRuJC"
  "JIknD83kac9glFzgDxkBN6iwc/FEUQl2XKk/xYW/72lscGhWYdK3Tf6MkZItEoRM0y7NJ1"
  "wkdH6NGMQecg8bHDAtusElJOGpHkta158WBgE9XtFuzGKASPTnFMJ0rLeVD0DoD5hodRgx"
  "E2kkKhyAgvYUQzJz2W5EckufHAngs8mRneCEXXOIWPDONdzad/rM5shf8EMAUo5At+weOa"
  "RFNp2n++53O222VTQ6CyYHKdxBb9YV+YwvDENNz7Iez8AYgo0Ld0AI7UiEVdHUTFqd4k38"
  "LPlk0oWTBYHKhS2eGnZxWkgPApLdof0Lyf9my5HRrDHAbqMyBgpKuSfNP7V9fbKp7E1kxt"
  "aFfP44NqDWbiABF6FpEoBQvt+R2rEHdPYUFbgfqClLiQ8+zm+R2Q8HJY36seY2WmAeOzJl"
  "TKZlBSN40igR7lEj00+inMa7kQM++jlplVftEOisqeciWs1MhAYxbdhw/3igLu5RbMaTjo"
  "qnmI+sKUw9qSzIrLbkDEzbklLE7r+FL4wNPISIkllPACxiOlkJ19G1d8r38B3koL5g==";

/* 
 * Resource generated for file:
 *    wrench.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_wrench_width          = 16;
static const unsigned int  image_Silk_wrench_height         = 16;
static const unsigned int  image_Silk_wrench_pixel_size     = 4;
static const unsigned long image_Silk_wrench_length         = 644;
static const unsigned long image_Silk_wrench_decoded_length = 1024;

static const unsigned char image_Silk_wrench[] = 
  "eNqV0s1v0nAYB3D/F/8Wo8YY48mTR89i9CBZlqUUKMUCsQwstrCDLjjXzRiGGxW1tryZVJ"
  "tVXnyDZchA0NXT4qFmX3812cWXDg5PmjT55Pl+n/wAnMAxk8vlfJIktUVRdDKZjIMpzNFk"
  "s1kfcQeDwQC2bSOdTmMWT2y73+9jNBqhVCohmUzO5AVBcNzdpmmC53nN/RePx8FxHKLR6L"
  "FdSN6f3W4X1WoViUTiZSwW02VZRqfTAcMwnj6VSp0heQ+bzSYajQbK5TIURYGmaahUKgiF"
  "Qu1/uVtrn/lI/oNJ8jr1eh2GYcD91mo16LoOVVURDAYPAoGA70/LruzyUmkE4ckQ3Mo7WJ"
  "aFYrEIlmUP3bxkp0PTdJuiqL8s49rNIcrmdyhvbHDrfcyJFiKRyI9wOHzSq2sov8tniH1K"
  "XF4d496zLyg0voG6v4PLrPXKy9LLO7ywMYTy2sbyizHSG3vIkg7rta/wL/VwkW49/J9dIH"
  "axMMSWQezzMRYLexBJjrXKBDdzPVyg3speu/1LXWwa+7/z8o8HuEvuJusT3JB6OL/gbd25"
  "eucj6bkPcYvcnHRYJfY6sWfntx9N8z6v3H5vuDda1SZ4oE5wLfMJp+ems0dziWm1yI1wbn"
  "4bp/yz2V8lKvlR";

/* 
 * Resource generated for file:
 *    zoom.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_zoom_width          = 16;
static const unsigned int  image_Silk_zoom_height         = 16;
static const unsigned int  image_Silk_zoom_pixel_size     = 4;
static const unsigned long image_Silk_zoom_length         = 800;
static const unsigned long image_Silk_zoom_decoded_length = 1024;

static const unsigned char image_Silk_zoom[] = 
  "eNqN0l1oUmEYB/AuI7qKYDdBo6vTXbXoEK1RNJtrmu5D3XKamrJlkcUiss7mJHM41sRFDe"
  "eijfKDLNxFy4kf5VxTQY9QtEFFRUEWhyDoIggOT88LRwgd4cXv5vD+n+fP+x4A2ASIDfTT"
  "bFAbYYN6rhQy8mzAwBfmNVxuVhVZvdtNg3BuI2xQYyqF9GU2oGUL86eY/D0VlfMpqdyMgs"
  "nOqNjstKq87JGbNsziXpItPlQ7S59/7UY9yILOIynalfHInRlPdznlktT0KAa0kaJfy+I5"
  "Cp1FVnQFXUaXkBo1pidlbNIlidTu13GFuT4Gz3Shq0J2SMiSDmbUmnR2MCmXlKvOl4IGPj"
  "+rIrvP/bOz0p/0GSAd4nYxlRqX8TX9/Xo+61VQwjmSuyDMGhS+GZFqaUREJZ2Smnz+vprL"
  "TveQ/mIhZxayJnQG6VBL9LqIWbK11fRf9SrxfRXk/hqRUsiRnXohK0M7Yvb238+sx/LV+c"
  "xUJ71yR1FOu2Xk/Xaio6QvUqBmks1MKf68ClsgNXQEFizNfdUzXkycNC275eXUuJRNONqZ"
  "mO04FR0WUdFrrUx6ootfe2qFLwUvfFi5BYkbMng8eLChekbi5gkaRRJOCUfuKeHo4KMjbT"
  "/jdgm8ez4G3948gO/rfngbH4Ww8TAfMhxo+N8/XbFwsUWTnuyFjy/dUH49B5+ytyHv08OY"
  "mHofON20pZ4ZT8yHNAlHJ6wvDsPaog0yHiWEB+gffu2+rfXkiUcmWuPvb4LYqBj7018xu7"
  "3ebEVQt3+br3ePw6/du7ny7S/MArkj";

/* 
 * Resource generated for file:
 *    zoom_in.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_zoom_in_width          = 16;
static const unsigned int  image_Silk_zoom_in_height         = 16;
static const unsigned int  image_Silk_zoom_in_pixel_size     = 4;
static const unsigned long image_Silk_zoom_in_length         = 804;
static const unsigned long image_Silk_zoom_in_decoded_length = 1024;

static const unsigned char image_Silk_zoom_in[] = 
  "eNqtk91rknEUx/sLut1lo4t4VjHGRj1EbRDMsNR08y3fntJNXFrZaEgDbSud5ayZi03UvV"
  "K+kBtKsNaYSurmS+gjFWsQY0URFl52/XD6/cKLUooFXXxufvw+53w5hwMA++A/QAeVJB2i"
  "onRIXS2H+xk6qGGKi6pqfkYazU4Lyb+6IZW2HFZX6CBFFxfl5sKslMj7JUTeJzbnfFI655"
  "FW0m6B9k99sVt6orCXP31vQYgQRsQVBA9xMOMW2DNuYSXp4DbkKAWpaClA0egfgbiMGEaY"
  "EEOIQYQC0Zya4NMJBzfa2P9StbggM6M/vYibNfdGzcUZ9IjuhJ1jTjp41Xq/HNIwhRkp7m"
  "34pefP/LrnSlDHpKAM98L6bTaRHOczDfkDaibnFWNfV/Ou1WoNXFyWQHBrFoRzHHhxi0Uk"
  "7NwGvzCvqOY8IpyfXfP0fc9kQEVEYFq9CnOvp8Cw1Afdzk7osuLx/e5nvRK0XzGeXzNCgt"
  "DivPNvPOArT4J90wIPX90DZ9YKx4bbGvzMZA+5MSWupFx8vL8DiNM4L2+aBdoQBc7cGMj9"
  "QugwtUKrsQVixlOy+hov75/Xpl2CSnKcR8dtZ81rI2eIVQuLwHnvpC3QPnQUPhe9sLvxAO"
  "JWPiwNnGiqrxEfO0cionE7t4rnFLdxGJy3bfAIHDYcgq9bj+HbdgDer49CpL+TCWuON+3l"
  "LmLXu1SpiQvwYdMFlbcL8DH3CAp+NdxlEzt7va1l/UlV3NYD2ysWeLcyAhm3BCI6cvdf7v"
  "OplpQHlB1f1kbZKD+5E6Da9+P3H62ystY=";

/* 
 * Resource generated for file:
 *    zoom_out.png (zlib, base64) (image file)
 */
static const unsigned int  image_Silk_zoom_out_width          = 16;
static const unsigned int  image_Silk_zoom_out_height         = 16;
static const unsigned int  image_Silk_zoom_out_pixel_size     = 4;
static const unsigned long image_Silk_zoom_out_length         = 784;
static const unsigned long image_Silk_zoom_out_decoded_length = 1024;

static const unsigned char image_Silk_zoom_out[] = 
  "eNqtk+1rUnEUx/sXgmAQQaMgbm96UdSlRwhmWdN0m3pbTklTtlxl0Ygt3BOZw7EmFjWcix"
  "zNB7JyL1o2fNicayro9UW0QUVFQbe6FcVGi+h2Oj+4QWjFgl583vw4n3O+nB8HAJbBf4AN"
  "NNBsUB9hgwa+GDIJbMAo5Id1fHaIicxcqaP/6gZ15mLIwLEBPZsfPmTLXWWorFdDZQfVts"
  "wgw2YGGG7KrTT/aS5xCyNaR/HF/HpEhViRY4gcWZN2Kx1pdx2XdMrKchQC+kjBr2exjkKO"
  "Im3IGaQFOYVokcpUv4JNOGWR8vmH+byv3oY1tUir6J4WXZLBglQlHNW2pFPOl/rFoFHIDT"
  "FkdvMvM3/mJ3kaSYZYt5RK9iqEsvx+g5DxqCmxjngnxF5N4psJYe51SKiEQ1bm565p+cyA"
  "iuSXip7le2sLfLMeh69HjLCo0sCCRAqfNm+DD+s2QKk/49Hg/6rJ/ioRDWIm7pfsBCxORu"
  "Hz3duwEB6BeZ8X3q1cW+anL9bQ05fVXMqlIP+3Gtn9u7nEfbt8FYxad9SX9pjsO2Cecim5"
  "ZK+cjdv32cY791DRdgkVPVtlS/XVCrN32uBl3gNPpy9A/JwCbjZtrSjtET+/n0YicYeMJ3"
  "uK26uFaMfej7FuGTye6IHXD6/Dmzk/PIp1Qdi0UwgZt1Qs5S5GT+7SpfoPwrP7LuAe+OB5"
  "5hLkvAbokVJPlnpbtyzbdXF7DcyNtcPsWCek3RoIN9Lv/+U+b5hpnb9hE4x3STE//cqv37"
  "iCvP8AxV+/ow==";

