/*=========================================================================

  Program:   KWWidgets
  Module:    $RCSfile: KWWidgets.rc.h,v $

  Copyright (c) Kitware, Inc.
  All rights reserved.
  See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
#define IDI_KWWidgetsICO 107
#define IDI_KWWidgetsICOSMALL 108

