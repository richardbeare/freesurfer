Tutorial 1
----------

This tutorial demonstrates how to create a very simple composite widget step 
by step. This new widget contains both a label and a checkbutton next to each
other. Selecting the checkbutton will change the background color of the label.

Build
-----

* Build the KWWidgets toolkit.
* Point CMake to the tutorial source directory, and pick a build directory
  (outside the KWWidgets toolkit build directory).
* From CMake, set KWWidgets_DIR to your KWWidgets build directory.
* From CMake, set STEP to the tutorial step you want to build.
* Configure, OK.
* Compile.
* Run KWTutorial1Launcher.


More doc to come.

