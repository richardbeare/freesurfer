KWConvertImageToHeader --zlib --base64 \
    vtkKWTkTreeCtrlTclLibrary.h \
    library/filelist-bindings.tcl \
    library/treectrl.tcl
