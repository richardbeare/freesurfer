KWConvertImageToHeader --zlib --base64 \
    vtkKWBWidgetsTclLibrary.h \
    bwminus.png \
    bwplus.png \
    bwdragfile.png \
    bwdragicon.png \
    arrow.tcl \
    combobox.tcl \
    dragsite.tcl \
    dropsite.tcl \
    dynhelp.tcl \
    entry.tcl \
    listbox.tcl \
    scrollframe.tcl \
    scrollw.tcl \
    tree.tcl \
    utils.tcl \
    widget.tcl
