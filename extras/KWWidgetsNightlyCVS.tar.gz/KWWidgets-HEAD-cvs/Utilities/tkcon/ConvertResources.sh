KWConvertImageToHeader --zlib --base64 \
    vtkKWTkconTclLibrary.h \
    tkcon.tcl
