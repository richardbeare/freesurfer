KWConvertImageToHeader --zlib --base64 \
    vtkKWTablelistTclLibrary.h \
    mwutil.tcl \
    tablelist.tcl \
    tablelistBind.tcl \
    tablelistBitmaps.tcl \
    tablelistConfig.tcl \
    tablelistEdit.tcl \
    tablelistMove.tcl \
    tablelistPublic.tcl \
    tablelistSort.tcl \
    tablelistThemes.tcl \
    tablelistUtil.tcl \
    tablelistUtil2.tcl \
    tablelistWidget.tcl