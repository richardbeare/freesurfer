KWConvertImageToHeader --zlib --base64 \
    vtkKWTkDnDTclLibrary.h \
    library/tkdnd.tcl
